// ============================================================
// 外盘网页 · 新浪行情中转 Worker（Cloudflare Worker 代码）
//
// 用途：GitHub.io 页面 → 本 Worker 中转 → 新浪 hq.sinajs.cn
//       （服务器端替请求盖上"来自新浪"的 Referer，浏览器端拿不到数据的坎就没了）
//
// 部署：登录 dash.cloudflare.com → Workers & Pages → Create Worker
//       → 在线编辑器里【全选删除】默认代码 → 粘贴本文件全部内容 → Deploy
//
// 验证：浏览器打开 https://你的worker地址/?list=hf_GC
//       应显示 var hq_str_hf_GC="..." 且为准实时数据
//
// 说明：除本段注释外，代码逻辑勿改（均已实测通过）。
//       免费额度 10 万请求/天，个人使用绰绰有余。
// ============================================================
export default {
  async fetch(request) {
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Max-Age': '86400',
      'Cache-Control': 'no-store',
    };
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }
    const url = new URL(request.url);
    const list = url.searchParams.get('list') || '';
    if (!/^[A-Za-z0-9_,\.]{1,500}$/.test(list)) {
      return new Response('bad list', { status: 400, headers: cors });
    }
    const resp = await fetch('https://hq.sinajs.cn/list=' + list, {
      headers: {
        'Referer': 'https://finance.sina.com.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36',
      },
    });
    const buf = await resp.arrayBuffer();
    const h = new Headers(cors);
    h.set('Content-Type', 'application/javascript; charset=GBK');
    return new Response(buf, { status: resp.status, headers: h });
  },
};
