---
name: overseas-futures-stats
description: 外盘涨跌统计项目的工作手册。当任务涉及本项目文件夹（E:\DwnlData\外盘涨跌统计）内的网页（index.html）、电脑 EXE、Cloudflare 中转、fetch.py 抓取脚本，或需要排查数据源与涨跌幅显示问题时使用。动手前先读项目根目录的《交接简报.md》。
---

# 外盘涨跌统计 · 项目工作手册

## 项目一句话

静态网页 + 本地 EXE，展示 25 行外盘品种涨跌幅（22 商品 + 3 美股指数）。起始价由 GitHub Actions 云端定时抓取（data.json，12 轮 + 预触发轮/天），最新价由浏览器 / 本机直连多源分级获取：**新浪准实时（经 Cloudflare 中转）> 腾讯实时直连 > TradingView 延时兜底**。

## 动手之前（必做）

1. 读项目根目录 `交接简报.md`（最新状态、资产地图、红线）
2. 读 `需求说明.md`（**用户的目的、使用场景与全部具体要求**——改任何东西前必须知道用户在乎什么）
3. 读 `网页版\README.md`（完整设计思路，用户确认版）
4. 需要更深背景时（只读）：
   `E:\DwnlData\.workbuddy\memory\` 下 MEMORY.md「外盘数据通道」节、2026-10-15.md、2026-10-16.md

## 红线

- 数据源保持低频（风控门限 1 秒 5 次 / 1 分钟 200 次；本项目用量远低）
- `E:\DwnlData\.workbuddy\` 是 WorkBuddy 工具的档案区：**只读，绝不可写**
- 改线上内容先本地验证；**上传由用户操作**；上传后 Ctrl+F5 强刷验收
- 不做未被用户要求的功能扩张

## 常见任务怎么干

- **改网页**：改 `网页版\index.html` → 本地浏览器验证 → 用户在 GitHub 网页上传（`github.com/WingTrade/futures-calc/upload/main`）→ Ctrl+F5 验收
- **改抓取脚本**：改 `网页版\fetch.py`（纯 Python 标准库，无第三方依赖）→ 上传仓库根目录；`fetch.yml` → 上传 `.github/workflows/`
- **改 EXE**：改 `电脑EXE\外盘实时出图.py` → PyInstaller 重打包（`--icon` 必须绝对路径；细节见 `电脑EXE\使用说明.md`）
- **改中转**：Cloudflare 控制台在线编辑器改 → 同步更新 `Worker备份\worker.js`
- **核实上传**：用 GitHub API 比对字节（历史上做过字节级核实，方法可复用）

## 关键环境事实（实测过，别再踩）

- 新浪 `hq.sinajs.cn`：防盗链（只认自家 Referer）+ 无 CORS → 浏览器必须中转
- `workers.dev` 国内直连被 RST（需代理）；`pages.dev` 国内可直连（主通道）
- 腾讯 `qt.gtimg.cn`：唯一可直连实时源（CORS 全开）；`hf_` 实时 / `fu` 延时 10-15 分钟
- TradingView：可直连；4 品种延时兜底（10-20 分钟）
- GitHub Actions 排队延迟约 26-36 分钟 → v1.9.2 用「预触发轮」抵偿
- 美国期货免费数据统一延时约 10 分钟（行业惯例）
