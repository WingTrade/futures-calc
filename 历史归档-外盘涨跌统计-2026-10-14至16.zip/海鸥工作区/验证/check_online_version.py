# -*- coding: utf-8 -*-
"""核实：线上 data.json 是哪个版本的 fetch.py 产出的？
判据：新版（v1.10+）每行都会带 ref_actual / gap_min 两个字段；旧版没有。
"""
import io, json, ssl, time, urllib.request

ctx = ssl._create_unverified_context()
url = 'https://wingtrade.github.io/futures-calc/data.json?t=%d' % time.time()
raw = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}),
                             timeout=25, context=ctx).read()
d = json.loads(raw.decode('utf-8'))
rows = d['rows']

print('线上 data.json：')
print('  mode        =', d.get('mode'))
print('  generated_at=', d.get('generated_at'))
print('  fetched_at  =', d.get('fetched_at'))
print()
sugar = [r for r in rows if '糖' in r['name']][0]
print('美原糖那一行（页面就是从这儿取数的）：')
for k, v in sugar.items():
    print('   %-12s %s' % (k, v))
print()
has_actual = sum(1 for r in rows if 'ref_actual' in r)
has_gap = sum(1 for r in rows if 'gap_min' in r)
print('带 ref_actual 字段的行数 = %d / %d' % (has_actual, len(rows)))
print('带 gap_min  字段的行数 = %d / %d' % (has_gap, len(rows)))
print()
if has_actual == 0:
    print('→ 判定：线上仍是【旧版 fetch.py】的产出（没有 v1.10 的新字段）。')
    print('   所以页面显示 10-16 01:00 是**旧逻辑**的结果，不是新脚本没改对。')
else:
    print('→ 判定：线上已是【新版 fetch.py】的产出。')
