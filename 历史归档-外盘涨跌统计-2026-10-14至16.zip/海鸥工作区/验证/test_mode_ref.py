# -*- coding: utf-8 -*-
"""验证「档位 → 各组参考时点」是否符合用户口径：
   用户口径 = 基准取【国内上次收盘时刻】的价（哪怕那时该外盘品种还在交易）。

直接调用交付版 fetch.py 里的判定函数（不跑主流程、不写文件），
对若干关键时刻算一遍：模式是什么、三组（M23/M01/M0230）的参考时点各是几点。
"""
import importlib.util, os
from datetime import datetime

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
spec = importlib.util.spec_from_file_location('fetchmod', os.path.join(WS, '交付', 'fetch.py'))
fm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fm)          # 只加载函数与常量；main() 受 __main__ 保护，不会执行

# 交易日/夜盘日（用今天实测的日历口径构造；真实运行时来自新浪分时）
TD = {'2026-10-13', '2026-10-14', '2026-10-15', '2026-10-16'}
ND = {'2026-10-12', '2026-10-13', '2026-10-14', '2026-10-15', '2026-10-16'}

CASES = [
    ('周四早上 08:50（夜盘后、日盘开盘前）', datetime(2026, 10, 16, 8, 50)),
    ('周四早上 10:20（10:15 小节刚收）', datetime(2026, 10, 16, 10, 20)),
    ('周四中午 12:00（11:30 午收后）', datetime(2026, 10, 16, 12, 0)),
    ('周四下午 15:10（日盘 15:00 收盘后）', datetime(2026, 10, 16, 15, 10)),
    ('周四晚上 20:50（夜盘 21:00 开盘前）', datetime(2026, 10, 16, 20, 50)),
    ('周四晚上 23:10（夜盘 23:00 收盘后）', datetime(2026, 10, 16, 23, 10)),
    ('周五凌晨 01:10（有色 01:00 收盘后）', datetime(2026, 10, 17, 1, 10)),
    ('周五凌晨 02:35（贵金属 02:30 收盘后）', datetime(2026, 10, 17, 2, 35)),
    ('周五早上 08:50（看隔夜结果）', datetime(2026, 10, 17, 8, 50)),
]

print('=' * 108)
print('档位与参考时点验证（口径：基准 = 国内上次收盘时刻的价）')
print('=' * 108)
print('%-34s %-8s %-22s %-22s %-22s' % ('时刻', '模式', 'M23 组参考', 'M01 组参考', 'M0230 组参考'))
print('-' * 108)
for label, now in CASES:
    mode = fm.decide_mode(now, TD)
    if mode == 'day':
        dc = now.replace(hour=15, minute=0, second=0, microsecond=0)
        refs = {g: dc for g in fm.GROUPS}
    elif mode in ('m1015', 'm1130'):
        hh, mm = {'m1015': (10, 15), 'm1130': (11, 30)}[mode]
        dc = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        refs = {g: dc for g in fm.GROUPS}
    else:
        refs = {g: fm.night_ref_point(g, now, TD, ND)[0] for g in fm.GROUPS}
    fmt = lambda d: d.strftime('%m-%d %H:%M') if d else '缺'
    print('%-34s %-8s %-22s %-22s %-22s' % (label, mode, fmt(refs['M23']), fmt(refs['M01']), fmt(refs['M0230'])))

print()
print('=' * 108)
print('各品种归组（决定它用哪个参考时点）')
print('=' * 108)
for g in fm.GROUPS:
    names = [v[0] for v in fm.VARIETIES if v[1] == g and '原油' not in v[0]]
    oils = [v[0] for v in fm.VARIETIES if v[1] == g and '原油' in v[0]]
    close = '%02d:%02d' % fm.GROUP_CLOSE[g]
    print('  %-6s（%s 收盘）: %s' % (g, close, '、'.join(names + (['原油×2'] if oils else []))))
print()
print('  美股三行（标准普尔/道琼工业/纳斯达克）走日K口径（最近两个收盘对比），与档位无关。')
print('  注意：日橡胶(14:50收盘)在 day 档已改为取当日收盘价；马棕油有显示窗口（10:30 前不显示该行）。')
