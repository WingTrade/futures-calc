# -*- coding: utf-8 -*-
"""实测原糖修正：构造一个"上一版 data.json"（原糖带 ref=10-15 23:00 的值），
再跑新版 fetch.py，验证：
  ① 原糖的参考时点已变成"最近一个已收盘的 23:00"（不再是自己 01:00 的收盘价）
  ② 分时表已滚出该时刻（day 档）时，能按同 ref 从上一版继承，不显示"缺"
  ③ 其他品种不受影响
"""
import io, json, os, subprocess, sys

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
PY = r'C:\Users\wing\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
D = os.path.join(WS, '验证', '原糖测试')

os.makedirs(D, exist_ok=True)
# 拷贝新版 fetch.py
s = io.open(os.path.join(WS, '交付', 'fetch.py'), encoding='utf-8').read()
io.open(os.path.join(D, 'fetch.py'), 'w', encoding='utf-8', newline='\n').write(s)

# 构造上一版：原糖按新口径标记 ref=10-15 23:00，close=21.050
prev = json.load(io.open(os.path.join(WS, '验证', '新版', 'data.json'), encoding='utf-8'))
for r in prev['rows']:
    if r['name'] == '美原糖':
        r['close'] = 21.050
        r['last'] = 21.050
        r['ref'] = '10-15 23:00'
        r['ref_actual'] = '10-15 23:00'
        r['gap_min'] = 0
        r['note'] = ''
    if r['name'] == '日橡胶':
        r['close'] = 450.100
        r['ref'] = '10-16 14:50'
        r['ref_actual'] = '10-16 14:50'
        r['gap_min'] = 0
io.open(os.path.join(D, 'data.json'), 'w', encoding='utf-8').write(json.dumps(prev, ensure_ascii=False, indent=1))
print('上一版已构造（原糖 ref=10-15 23:00 / close=21.050）')

print('跑新版 fetch.py ...')
p = subprocess.run([PY, 'fetch.py'], cwd=D, capture_output=True)
out = p.stdout.decode('utf-8', 'replace')
for line in out.splitlines():
    if any(k in line for k in ['模式', '续接', '实际取价笔', '完成', '换月']):
        print('   ' + line)

d = json.load(io.open(os.path.join(D, 'data.json'), encoding='utf-8'))
print()
print('输出中的关键行：')
print('  %-14s %-12s %-16s %-16s %-9s %s' % ('品种', 'close', 'ref', 'ref_actual', 'gap_min', 'note'))
for r in d['rows']:
    if r['name'] in ('美原糖', '日橡胶', '美黄金', '新加坡铁矿石'):
        print('  %-14s %-12s %-16s %-16s %-9s %s' % (
            r['name'], r['close'], r.get('ref'), r.get('ref_actual'), r.get('gap_min'), r.get('note')))

sugar = [r for r in d['rows'] if r['name'] == '美原糖'][0]
ok1 = str(sugar.get('ref', '')).endswith('23:00')
ok2 = sugar.get('close') is not None
ok3 = str(sugar.get('ref_actual', '')).endswith('23:00')
print()
print('判定：')
print('  %s 参考时点是 23:00（不再是自己 01:00 收盘价）' % ('PASS' if ok1 else 'FAIL'))
print('  %s 分时表滚出后按同 ref 从上一版继承到了值（close=%s）' % ('PASS' if ok2 else 'FAIL', sugar.get('close')))
print('  %s 实际取价笔也标注为 23:00' % ('PASS' if ok3 else 'FAIL'))
sys.exit(0 if (ok1 and ok2) else 1)
