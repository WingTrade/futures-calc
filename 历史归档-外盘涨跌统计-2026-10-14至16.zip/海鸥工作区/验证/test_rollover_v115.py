# -*- coding: utf-8 -*-
"""换月判据（v1.15 第二通道）测试：
 ① 回放测试 —— 用 2026-10-16 美燃油的真实数值构造，改前必须失败、改后转绿（回归用例）
 ② 不误伤回归 —— 双阈值分级、排除表、区间内、区间过窄 等边界
"""
import importlib.util, os, sys
from datetime import datetime, timedelta

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
spec = importlib.util.spec_from_file_location('fm', os.path.join(WS, '交付', 'fetch.py'))
fm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fm)

NOW = datetime(2026, 10, 16, 18, 30)
PASS = FAIL = 0


def ok(name, cond, extra=''):
    global PASS, FAIL
    print('  %s %s %s' % ('PASS' if cond else 'FAIL', name, extra))
    if cond:
        PASS += 1
    else:
        FAIL += 1


def mk(prices, last_min_ago=0):
    n = len(prices)
    end = NOW - timedelta(minutes=last_min_ago)
    return [(end - timedelta(minutes=n - 1 - i), p) for i, p in enumerate(prices)]


# HO 当段分时表（真实量级：18:26 实测 511 笔、区间 [4.567, 4.633]）
HO_BARS = mk([4.633, 4.610, 4.590, 4.575, 4.567, 4.600, 4.618, 4.596])

print('== ① 回放测试：2026-10-16 美燃油（真实事故数据）==')
close, last, ps = 4.834, 4.596, 4.654
lv, gap, why = fm.rollover_suspect_close(HO_BARS, close, ps)
ok('起始价被判定为 fix（自动修正级）', lv == 'fix', '→ %s' % lv)
ok('偏离比例 ≈ 3.87%', gap is not None and abs(gap * 100 - 3.87) < 0.1, '→ %.2f%%' % (gap * 100 if gap else -1))
ok('说明文字含区间与偏离', ('分时表区间' in why) and ('昨结' in why))
ok('对照：v1.14 通道（查最新价）在该案例不触发', fm.rollover_suspect(HO_BARS, last, NOW)[0] is False,
   '← 这就是评审指出的缺口')

print('\n== ② 不误伤回归 ==')
ok('起始价就在当段区间内 → 不判', fm.rollover_suspect_close(HO_BARS, 4.600, ps)[0] is None)
ok('跨时段继承的常规漂移（出区间但偏离 <1.5%）→ 不判',
   fm.rollover_suspect_close(mk([4.660, 4.650, 4.645, 4.655]), 4.680, 4.670)[0] is None)
lv2, gap2, _ = fm.rollover_suspect_close(mk([4.660, 4.650, 4.645, 4.655]), 4.79, 4.70)
ok('偏离 1.5%~2.5% → 只记录（watch），不自动修', lv2 == 'watch', '→ %s %.2f%%' % (lv2, (gap2 or 0) * 100))
ok('排除表命中（日橡胶）→ 不判', fm.rollover_suspect_close(HO_BARS, 4.834, ps, exclude=True)[0] is None)
ok('区间过窄 → 不判', fm.rollover_suspect_close(mk([4.6400, 4.6405, 4.6408]), 4.834, ps)[0] is None)
ok('表点数 < 3 → 不判', fm.rollover_suspect_close(mk([4.60, 4.63]), 4.834, ps)[0] is None)
ok('昨结缺失 → 不判', fm.rollover_suspect_close(HO_BARS, 4.834, None)[0] is None)
ok('起始价缺失 → 不判', fm.rollover_suspect_close(HO_BARS, None, ps)[0] is None)

print('\n== ③ 排除表内容与配置 ==')
ok('ROLLOVER_EXCLUDE 含日橡胶/铁矿/银现货',
   all(k in fm.ROLLOVER_EXCLUDE for k in ('日橡胶', '新加坡铁矿石', '伦敦银现货')))
ok('ROLLOVER_OVERRIDE 存在且为空（备用）', fm.ROLLOVER_OVERRIDE == {})

print('\n自检结果：PASS %d / FAIL %d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
