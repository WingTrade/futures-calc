/* v2.11 逻辑自检：
   a) 分时接管模块（mlActive / mlCodes / mlTag / mlTagTip / mlNote）
   b) 对产出的 index.html 做"结构断言"——延时源必须真的剔干净（用户要求只要当下的价）
   标记策略（2026-10-16 用户确认）：
     · 新鲜的分时价（差几秒~1 分钟）与快照等价 → 【不标】
     · 只有"该行确实是旧时刻的价"（该品种此刻无新成交）才标出时刻，如「分时 14:11」 */
const fs = require('fs'), vm = require('vm');

const MOD = 'E:\\DwnlData\\外盘涨跌统计\\海鸥工作区\\构建\\v211_模块.js';
const PAGE = 'E:\\DwnlData\\外盘涨跌统计\\海鸥工作区\\交付\\index.html';

let pass = 0, fail = 0;
function eq(name, got, want) {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  console.log((ok ? '  PASS ' : '  FAIL ') + name + '  got=' + JSON.stringify(got) + (ok ? '' : '  want=' + JSON.stringify(want)));
  ok ? pass++ : fail++;
}
function ok(name, cond) { eq(name, !!cond, true); }

console.log('== ① 分时接管模块 ==');
const js = fs.readFileSync(MOD, 'utf8');
const SINA_SYMS = { 'hf_RS': 1, 'hf_CT': 1, 'hf_FCPO': 1, 'hf_FEF': 1, 'hf_RSS3': 1, 'hf_HO': 1 };
const state = {
  snFail: 0, sn: {}, ml: {}, mlOn: false, mlFirst: false,
  data: { rows: [
    { name: '美黄金', code: 'hf_GC' }, { name: '原糖', code: 'hf_RS' }, { name: '棉花', code: 'hf_CT' },
    { name: '马棕油', code: 'hf_FCPO' }, { name: '铁矿', code: 'hf_FEF' }, { name: '日橡胶', code: 'hf_RSS3' },
    { name: '美燃油', code: 'hf_HO' }, { name: '标普', code: null }
  ] }
};
const ctx = {
  console, Promise, setTimeout, clearTimeout, encodeURIComponent, JSON, Math, parseInt, parseFloat, isNaN,
  String, Number, Object, Array, RegExp, Date,
  state, SINA_SYMS, render: () => {},
  pad2: n => (n < 10 ? '0' : '') + n,
  sinaCodeOf: r => (r && r.code) || null,
  hhmmOf: mn => (mn < 600 ? '0' : '') + Math.floor(mn / 60) + ':' + ((mn % 60) < 10 ? '0' : '') + (mn % 60),
  jsonpMinline: () => Promise.resolve({ data: null })
};
vm.createContext(ctx);
vm.runInContext(js, ctx);

eq('未故障时不接管', ctx.mlActive(), false);
state.snFail = 1;
state.sn = {};
eq('失败 1 次且一条数据都没有 → 立刻接管（不干等）', ctx.mlActive(), true);
state.sn = { 'hf_RS': { last: 20.9 } };
eq('失败 1 次但已有数据 → 先不接管', ctx.mlActive(), false);
state.snFail = 2;
eq('连续失败 2 次 → 接管', ctx.mlActive(), true);
eq('接管品种 = 那 6 个（美股不在内）', ctx.mlCodes(), ['hf_RS', 'hf_CT', 'hf_FCPO', 'hf_FEF', 'hf_RSS3', 'hf_HO']);

eq('新鲜分时价（1 分钟内）→ 不标', ctx.mlTag({ t: '15:51', ageMin: 1 }), '');
eq('4 分钟前 → 仍不标（用户标准：5 分钟内算当下）', ctx.mlTag({ t: '15:48', ageMin: 4 }), '');
eq('超过 5 分钟 → 标出时刻', ctx.mlTag({ t: '15:40', ageMin: 7 }), '分时 15:40');
eq('末根已 2 小时前 → 标出时刻', ctx.mlTag({ t: '14:11', ageMin: 132 }), '分时 14:11');
ok('旧末根提示含时刻与分钟', ctx.mlTagTip({ t: '14:11', ageMin: 132 }).indexOf('14:11') >= 0 &&
   ctx.mlTagTip({ t: '14:11', ageMin: 132 }).indexOf('132 分钟') >= 0);
ok('新鲜末根提示含时刻', ctx.mlTagTip({ t: '15:51', ageMin: 0 }).indexOf('15:51') >= 0);
state.snFail = 0;
eq('未接管时页脚无提示', ctx.mlNote(), '');
state.snFail = 2;
state.ml = { 'hf_RS': {}, 'hf_CT': {} };
ok('接管后页脚提示含「分时表接管」', ctx.mlNote().indexOf('分时表接管') >= 0);

console.log('\n== ② 产出页面结构断言（延时源必须剔干净）==');
const page = fs.readFileSync(PAGE, 'utf8');
eq('TX_OVERRIDE 已清空', /var TX_OVERRIDE = \{\};/.test(page), true);
ok('不再把 hf_HO 映射到 fuHO', !/TX_OVERRIDE = \{ 'hf_HO': 'fuHO' \}/.test(page));
ok('quoteOf 里已无 TradingView 分支', !/if\(sc && state\.gq\[sc\]\) return state\.gq\[sc\];\s*\/\* ③/.test(page));
ok('quoteOf 里有分时接管分支', /if\(sc && state\.ml && state\.ml\[sc\]\) return state\.ml\[sc\];/.test(page));
function stripComments(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
}
const bootStart = page.indexOf('async function boot()');
const bootSrc = stripComments(page.slice(bootStart, page.indexOf('\nboot();', bootStart)));
ok('boot 里已不再调用 refreshGlobal/scheduleGlobal', !/refreshGlobal\s*\(/.test(bootSrc) && !/scheduleGlobal\s*\(/.test(bootSrc));
const visStart = page.indexOf("document.addEventListener('visibilitychange'");
const visSrc = stripComments(page.slice(visStart));
ok('visibilitychange 里也已不再调用 refreshGlobal/scheduleGlobal', !/refreshGlobal\s*\(/.test(visSrc) && !/scheduleGlobal\s*\(/.test(visSrc));
ok('boot 里已挂分时接管', /mlTick\(\);\s*\/\* ⑬ v2\.11/.test(page) && /scheduleMl\(\);\s*\/\* ⑭ v2\.11/.test(page));
ok('落盘值标「缓存」只对非美股行', /if\(!stag && !q && r\.last != null && sinaCodeOf\(r\)\) stag = '缓存';/.test(page));
ok('补档成功不再打「即时」标记', !/mark: '即时'/.test(page));
/* 只检查【用户可见的文案】：页脚说明那一行不该再提「即时」 */
const tipStart = page.indexOf('id="tipMark"');
const tipLine = page.slice(tipStart, tipStart + 500);
ok('页脚说明已更新（不再提 ※ 与「即时」）',
   tipLine.indexOf('「起始时间」列') >= 0 && tipLine.indexOf('「即时」') < 0 && tipLine.indexOf('※') < 0);
ok('rowHtml 里「即时」死分支已清理', !/r\.mark === '即时'/.test(page));
ok('补档里含日橡胶特例（改走今天日K的收盘价）',
   /c\.name === '日橡胶' && mode === 'day'/.test(page) && /function jsonpDailyK/.test(page));
ok('补档里排除了美原糖（它的基准跟国内糖收盘时刻走）', /rows\[i\]\.name !== '美原糖'/.test(page));

/* 源链顺序：快照 → 腾讯 → 分时接管 → (null) */
const q = page.slice(page.indexOf('function quoteOf'), page.indexOf('function quoteOf') + 700);
const i1 = q.indexOf('state.sn[sc]'), i2 = q.indexOf('state.tx[rowCode(r)]'), i3 = q.indexOf('state.ml[sc]');
ok('源链顺序 = 新浪快照 → 腾讯 → 分时接管', i1 > 0 && i2 > i1 && i3 > i2);

console.log('\n自检结果：PASS ' + pass + ' / FAIL ' + fail);
process.exit(fail ? 1 : 0);
