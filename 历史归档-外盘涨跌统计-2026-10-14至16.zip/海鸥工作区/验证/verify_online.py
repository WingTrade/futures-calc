# -*- coding: utf-8 -*-
"""上传后线上核对：
 ① index.html / fetch.py 的字节与哈希是否与本地交付版一致
 ② 线上 data.json 是否已由新版 fetch.py 产出（新字段 ref_actual/gap_min）
 ③ 关键行数值是否正确（原糖 15:30、日橡胶 14:50、改名、有无换月行、有无"缺"）
"""
import hashlib, io, json, os, ssl, time, urllib.request

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
ctx = ssl._create_unverified_context()


def fetch(url, timeout=30, decode=None):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Cache-Control': 'no-cache'})
    raw = urllib.request.urlopen(req, timeout=timeout, context=ctx).read()
    return raw


def sha(b):
    return hashlib.sha256(b).hexdigest()


print('=' * 100)
print('① 文件字节核对 · %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
print('=' * 100)

for local_name, url in [
    ('index.html', 'https://wingtrade.github.io/futures-calc/index.html?t=%d' % time.time()),
    ('fetch.py', 'https://raw.githubusercontent.com/WingTrade/futures-calc/main/fetch.py?t=%d' % time.time()),
]:
    lp = os.path.join(WS, '交付', local_name)
    lb = io.open(lp, 'rb').read()
    try:
        rb = fetch(url)
    except Exception as e:
        print('  %-12s 线上拉取失败: %s' % (local_name, type(e).__name__))
        continue
    same = sha(lb) == sha(rb)
    print('  %-12s 本地 %6d 字节 %s' % (local_name, len(lb), sha(lb)[:16]))
    print('  %-12s 线上 %6d 字节 %s' % ('', len(rb), sha(rb)[:16]))
    print('  %-12s → %s' % ('', '✓ 完全一致' if same else '✗ 不一致（可能是缓存，或上传的不是这个文件）'))
    print()

print('=' * 100)
print('② 线上 data.json 是否已是新版产出')
print('=' * 100)
raw = fetch('https://wingtrade.github.io/futures-calc/data.json?t=%d' % time.time())
d = json.loads(raw.decode('utf-8'))
rows = d['rows']
has_actual = sum(1 for r in rows if 'ref_actual' in r)
has_gap = sum(1 for r in rows if 'gap_min' in r)
print('  mode         = %s' % d.get('mode'))
print('  generated_at = %s' % d.get('generated_at'))
print('  带 ref_actual 的行数 = %d / %d' % (has_actual, len(rows)))
print('  带 gap_min   的行数 = %d / %d' % (has_gap, len(rows)))
print('  → %s' % ('✓ 新版 fetch.py 已生效' if has_actual else '✗ 还是旧版产出（Actions 可能还没跑完，或跑的是旧脚本）'))
print()

print('=' * 100)
print('③ 关键行数值')
print('=' * 100)
print('%-14s %-11s %-16s %-15s %-8s %s' % ('品种名', 'close', 'ref', 'ref_actual', 'note', 'pct'))
print('-' * 100)
for r in rows:
    print('%-14s %-11s %-16s %-15s %-8s %s' % (
        r['name'], r.get('close'), r.get('ref'), r.get('ref_actual'), r.get('note') or '', r.get('pct')))

missing = [r['name'] for r in rows if r.get('pct') is None]
roll = [r['name'] for r in rows if (r.get('note') or '') == '换月']
oldname = [r['name'] for r in rows if r['name'] in ('美黄豆粉', '美黄豆油', '美国棉花', '美国天然气')]
sugar = next((r for r in rows if r['name'] == '美原糖'), None)
rub = next((r for r in rows if r['name'] == '日橡胶'), None)

print()
print('判定：')
print('  %s 25 行都有涨跌幅%s' % ('PASS' if not missing else 'FAIL', '' if not missing else ' → ' + str(missing)))
print('  %s 无旧品种名残留' % ('PASS' if not oldname else 'FAIL → ' + str(oldname)))
if sugar:
    ok = sugar.get('close') == 20.896 or (sugar.get('ref_actual') or '').endswith('15:30')
    print('  %s 美原糖: close=%s ref=%s ref_actual=%s' % ('PASS' if ok else 'FAIL',
          sugar.get('close'), sugar.get('ref'), sugar.get('ref_actual')))
if rub:
    print('      日橡胶: close=%s ref=%s ref_actual=%s' % (rub.get('close'), rub.get('ref'), rub.get('ref_actual')))
print('  %s 换月修正行: %s' % ('（正常）' if not roll else '（有）', roll or '无'))
