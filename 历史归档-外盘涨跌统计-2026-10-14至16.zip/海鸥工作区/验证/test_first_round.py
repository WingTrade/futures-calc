# -*- coding: utf-8 -*-
"""模拟"上传后第一轮"：拿【线上真实 data.json】（旧名字 + 旧格式）当上一版，
跑新版 fetch.py，检查：
  ① 原糖是否还有"缺"（v1.13 的 day 档取"15:00 之后第一笔"应当直接取到值）
  ② 四个改名品种是否正常（继承兼容旧名是否生效）
  ③ 全表是否有任何一行没涨跌幅
"""
import io, json, os, shutil, ssl, subprocess, sys, time, urllib.request

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
PY = r'C:\Users\wing\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
D = os.path.join(WS, '验证', '上线首轮模拟')
os.makedirs(D, exist_ok=True)

# ① 下载线上真实 data.json 作为"上一版"
ctx = ssl._create_unverified_context()
url = 'https://wingtrade.github.io/futures-calc/data.json?t=%d' % time.time()
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
raw = urllib.request.urlopen(req, timeout=25, context=ctx).read()
io.open(os.path.join(D, 'data.json'), 'wb').write(raw)
prev = json.loads(raw.decode('utf-8'))
print('线上上一版：mode=%s generated_at=%s 行数=%d' % (prev.get('mode'), prev.get('generated_at'), len(prev['rows'])))
print('  里面用的名字（前 5 个）:', [r['name'] for r in prev['rows'][:5]])
print('  原糖那行:', [r for r in prev['rows'] if '糖' in r['name']])

# ② 拷新版脚本并跑
shutil.copy(os.path.join(WS, '交付', 'fetch.py'), os.path.join(D, 'fetch.py'))
print()
print('跑新版 fetch.py ...')
p = subprocess.run([PY, 'fetch.py'], cwd=D, capture_output=True)
out = p.stdout.decode('utf-8', 'replace')
for line in out.splitlines():
    if any(k in line for k in ['模式', '续接', '实际取价笔', '完成', '换月', 'Error', 'Traceback']):
        print('   ' + line)

# ③ 检查
d = json.load(io.open(os.path.join(D, 'data.json'), encoding='utf-8'))
print()
print('%-14s %-12s %-16s %-14s %s' % ('品种名', 'close', 'ref', 'ref_actual', 'note'))
print('-' * 76)
for r in d['rows']:
    print('%-14s %-12s %-16s %-14s %s' % (
        r['name'], r.get('close'), r.get('ref'), r.get('ref_actual'), r.get('note') or ''))

missing = [r['name'] for r in d['rows'] if r.get('pct') is None]
sugar = [r for r in d['rows'] if r['name'] == '美原糖']
renamed = [r['name'] for r in d['rows'] if r['name'] in ('美豆粕', '美豆油', '美棉花', '美天然气')]
oldnames = [r['name'] for r in d['rows'] if r['name'] in ('美黄豆粉', '美黄豆油', '美国棉花', '美国天然气')]

print()
print('判定：')
ok1 = not missing
ok2 = bool(sugar) and sugar[0].get('close') is not None
ok3 = len(renamed) == 4 and not oldnames
print('  %s 全表都有涨跌幅（没有"缺"的行）%s' % ('PASS' if ok1 else 'FAIL', '' if ok1 else ' → ' + str(missing)))
print('  %s 原糖有值: close=%s ref=%s' % ('PASS' if ok2 else 'FAIL',
      sugar[0].get('close') if sugar else '-', sugar[0].get('ref') if sugar else '-'))
print('  %s 四个改名品种都在、旧名已消失' % ('PASS' if ok3 else 'FAIL'))
sys.exit(0 if (ok1 and ok2 and ok3) else 1)
