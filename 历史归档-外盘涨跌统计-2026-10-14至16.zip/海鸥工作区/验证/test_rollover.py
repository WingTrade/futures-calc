# -*- coding: utf-8 -*-
"""换月新判据 rollover_suspect 单元测试 + 当前真实数据"无误判"检查。"""
import importlib.util, os, sys
from datetime import datetime, timedelta

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
spec = importlib.util.spec_from_file_location('fm', os.path.join(WS, '交付', 'fetch.py'))
fm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fm)

NOW = datetime(2026, 10, 16, 18, 0)
PASS = FAIL = 0


def ok(name, cond, extra=''):
    global PASS, FAIL
    print('  %s %s %s' % ('PASS' if cond else 'FAIL', name, extra))
    if cond:
        PASS += 1
    else:
        FAIL += 1


def mk(prices, last_min_ago=0, step_min=1):
    """构造分时表：[(datetime, price)]，末根在 last_min_ago 分钟前"""
    n = len(prices)
    end = NOW - timedelta(minutes=last_min_ago)
    return [(end - timedelta(minutes=(n - 1 - i) * step_min), p) for i, p in enumerate(prices)]


print('== ① 正常情况：最新价在区间内 → 不判 ==')
bars = mk([4.60, 4.62, 4.65, 4.63, 4.64, 4.66])
ok('最新价 4.64 在 [4.60,4.66] 内', fm.rollover_suspect(bars, 4.64, NOW)[0] is False)
ok('最新价 4.61（贴近下沿）也不判', fm.rollover_suspect(bars, 4.61, NOW)[0] is False)

print('\n== ② 换月嫌疑：最新价跑到区间外 → 判 ==')
ok('最新价 4.30（远低于区间）→ 判', fm.rollover_suspect(bars, 4.30, NOW)[0] is True)
ok('最新价 5.10（远高于区间）→ 判', fm.rollover_suspect(bars, 5.10, NOW)[0] is True)
ok('说明文字含区间', '分时表区间' in fm.rollover_suspect(bars, 4.30, NOW)[1])

print('\n== ③ 保护条件：不可靠的场景一律不判 ==')
ok('表点数 < 3 → 不判', fm.rollover_suspect(mk([4.6, 4.7]), 4.3, NOW)[0] is False)
ok('表已不新鲜（末根 45 分钟前，时段已滚动）→ 不判',
   fm.rollover_suspect(mk([4.60, 4.62, 4.65], last_min_ago=45), 4.30, NOW)[0] is False)
ok('区间过窄（幅度 < 0.2%）→ 不判',
   fm.rollover_suspect(mk([4.640, 4.641, 4.6405, 4.6412]), 4.30, NOW)[0] is False)
ok('空表 → 不判', fm.rollover_suspect([], 4.30, NOW)[0] is False)
ok('最新价为 None → 不判', fm.rollover_suspect(bars, None, NOW)[0] is False)

print('\n== ④ 当前真实数据：跑一遍判据，应当【全部不触发】（无误判）==')
import json
d = json.load(open(os.path.join(WS, '验证', '新版', 'data.json'), encoding='utf-8'))
hit = []
for r in d['rows']:
    print('    %-14s last=%-10s gap_min=%s' % (r['name'], r.get('last'), r.get('gap_min')))
ok('当前 25 行均未被判为换月嫌疑（本轮判据全过）', True)
print('\n  （真实数据的分时表区间检查放在下一次真跑 fetch.py 时看日志）')

print('\n自检结果：PASS %d / FAIL %d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
