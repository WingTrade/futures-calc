/* v2.10 增量模块逻辑自检（与浏览器无关的纯逻辑部分）。
   做法：把 v210_模块.js 放进 vm，注入依赖 stub 与假时钟，逐项断言。
   标记策略（2026-10-16 用户确认）：
     · 补档算出来的值与云端逐位一致 → 【不打任何标记】（标出来只会让人怀疑数据是临时的）
     · ※ 只在"基准价实际取自某点某分"时出现（给用户反查用）
     · 美股三行走云端收盘口径，不参与补档/接管，也不打标记 */
const fs = require('fs'), vm = require('vm');
const MOD = 'E:\\DwnlData\\外盘涨跌统计\\海鸥工作区\\构建\\v210_模块.js';
const js = fs.readFileSync(MOD, 'utf8');

/* 假时钟：2026-10-16（周五）16:00 → 应有档位 day，节点 15:00 */
class FakeDate extends Date {
  constructor(...a) { if (a.length === 0) super(2026, 9, 16, 16, 0, 0); else super(...a); }
}
const TODAY = '2026-10-16';

const state = { data: { mode: 'm1130', rows: [] }, gq: {} };
const ctx = {
  console, Promise, setTimeout, clearTimeout, encodeURIComponent,
  JSON, Math, parseInt, parseFloat, isNaN, String, Number, Object, Array, RegExp,
  Date: FakeDate, state, render: () => {},
  pad2: n => (n < 10 ? '0' : '') + n,
  todayYmd: () => TODAY,
  sinaCodeOf: r => (r && r.code) || null,
  rowCode: r => (r && (r.txcode || r.code)) || null,
  localStorage: { _m: {}, getItem(k) { return this._m[k] || null; }, setItem(k, v) { this._m[k] = v; } },
  document: { createElement: () => ({ src: '', parentNode: null }), body: { appendChild() {} } },
  window: {}
};
vm.createContext(ctx);
vm.runInContext(js, ctx);

let pass = 0, fail = 0;
function eq(name, got, want) {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  console.log((ok ? '  PASS ' : '  FAIL ') + name + '  got=' + JSON.stringify(got) + (ok ? '' : '  want=' + JSON.stringify(want)));
  ok ? pass++ : fail++;
}
function ok(name, cond) { eq(name, !!cond, true); }

console.log('== ① 档位/节点判定 ==');
eq('16:00 周五 → day', ctx.expectMode(), 'day');
eq('node(day)', ctx.probeNode('day'), '15:00');
eq('node(m1015)', ctx.probeNode('m1015'), '10:15');
eq('node(m1130)', ctx.probeNode('m1130'), '11:30');
eq('node(night) = null（夜盘不补档）', ctx.probeNode('night'), null);

console.log('\n== ② 分时表解析与取价笔（真样本：原糖跨日时段）==');
const rsArr = [
  ['2026-10-15', '20.840', 'nybot', '', '15:30', '20.708'],
  ['15:31', '20.750', '0', '0', '20.700', '2026-10-15 15:31:00'],
  ['23:59', '21.100', '0', '0', '21.000', '2026-10-15 23:59:00'],
  ['00:01', '21.120', '0', '0', '21.050', '2026-10-16 00:01:00'],
  ['00:59', '21.149', '445', '0', '20.997', '2026-10-16 00:59:00']
];
const pts = ctx.buildPoints(rsArr);
eq('点数（跳过首根）', pts.length, 4);
eq('跨日推断', pts[pts.length - 1].date, '2026-10-16');
eq('取 00:59 那一笔', ctx.pickPoint(pts, TODAY, 0 * 60 + 59).price, 21.149);

console.log('\n== ③ 起始时间说真话（云端模式）==');
const r1 = { name: '美黄豆粉', close: 344.8, ref: '10-16 15:00', ref_actual: '10-16 14:46', gap_min: 14, code: 'hf_SM' };
const b1 = ctx.baseQuoteOf(r1);
eq('显示实际取价笔时刻', b1.ref, '10-16 14:46');
eq('不再打 ※（起始时间列已显示真实时刻，用户要求去掉小标）', b1.mark, '');
ok('不再有悬停偏差提示（小标与说明都已取消）', b1.refTip === '');
eq('基准价不变', b1.close, 344.8);

const r2 = { name: '美黄金', close: 4201.276, ref: '10-16 15:00', ref_actual: '10-16 15:00', gap_min: 0, code: 'hf_GC' };
const b2 = ctx.baseQuoteOf(r2);
eq('偏差 0 → 不打标记', b2.mark, '');
eq('仍显示实际取价笔（= 节点）', b2.ref, '10-16 15:00');

const r3 = { name: '美黄金', close: 4201.276, ref: '10-16 15:00', code: 'hf_GC' };
const b3 = ctx.baseQuoteOf(r3);
eq('兼容旧数据：原样显示 ref', b3.ref, '10-16 15:00');
eq('兼容旧数据：无标记', b3.mark, '');

console.log('\n== ④ 补档生效时（值同源同口径，按用户要求不打扰）==');
ctx.refLive = {
  key: TODAY + '|15:00', date: TODAY, mode: 'day', node: '15:00', done: true, ok: 22, fail: 3,
  rows: { '美黄金': 4200.5 }, actual: { '美黄金': { t: '10-16 15:00', gap: 0 } }
};
ok('补档生效（云端仍是 m1130 档）', ctx.refLiveActive());
const b4 = ctx.baseQuoteOf(r2);
eq('用补档算出的值', b4.close, 4200.5);
eq('补档成功时不打任何标记（与云端逐位一致，不打扰）', b4.mark, '');
eq('起始时间列 = 实取时刻', b4.ref, '10-16 15:00');
const b5 = ctx.baseQuoteOf({ name: '马棕油', close: 4681.2, ref: '10-16 15:00', code: 'hf_FCPO' });
eq('补档没覆盖到的行 → 空着（不用旧档的错值）', b5.close, null);
eq('补档成功时页脚也不打扰', ctx.refLiveNote(state.data), '');

console.log('\n== ④b 美股三行（无实时源）必须不受补档影响、不打标记 ==');
const bUs = ctx.baseQuoteOf({ name: '标准普尔', close: 7718.94, last: 7744.06, ref: '10-15美', code: null });
eq('补档生效时美股行仍用云端值', bUs.close, 7718.94);
eq('美股行 起始时间 原样（10-15美）', bUs.ref, '10-15美');
eq('美股行不打任何小标', bUs.mark, '');
eq('美股行提示为空', bUs.refTip, '');

console.log('\n== ④c 美原糖不参与补档（它的基准跟"国内糖收盘时刻"走，与档位无关）==');
const bRs = ctx.baseQuoteOf({ name: '美原糖', close: 21.05, ref: '10-15 23:00', ref_actual: '10-15 23:00', gap_min: 0, code: 'hf_RS' });
eq('补档生效时原糖仍用云端值', bRs.close, 21.05);
eq('原糖起始时间保持 23:00', bRs.ref, '10-15 23:00');
eq('原糖不打任何标记', bRs.mark, '');

console.log('\n== ⑤ 云端更新后自动让位 ==');
state.data.mode = 'day';
ok('云端已是当前档 → 补档自动失效', !ctx.refLiveActive());
const b6 = ctx.baseQuoteOf(r2);
eq('回到云端值', b6.close, 4201.276);
eq('标记仍为空', b6.mark, '');
state.data.mode = 'm1130';

console.log('\n== ⑥ 备用来源标记（v2.10 模块层）==');
const gq = { last: 21.13 };
state.gq['hf_RS'] = gq;
eq('TradingView 兜底 → 延', ctx.srcTag({ name: '美原糖', code: 'hf_RS' }, gq), '延');
eq('腾讯实时 → 无标记', ctx.srcTag({ name: '美黄金', code: 'hf_GC' }, { last: 4200 }), '');
eq('美燃油 fuHO 延时源 → 延', ctx.srcTag({ name: '美燃油', code: 'hf_HO', txcode: 'fuHO' }, { last: 4.6 }), '延');

console.log('\n== ⑦ 缓存与重试节流 ==');
ctx.saveProbeCache(ctx.refLive);
eq('缓存可读回', ctx.loadProbeCache().key, TODAY + '|15:00');
ctx.refLive = null;                                   /* 模拟"补档没成功"的情形 */
ctx.probeTried[TODAY + '|15:00'] = FakeDate.now();
ok('补档失败后页脚会说明一句', ctx.refLiveNote(state.data).indexOf('未取得足够数据') >= 0);

console.log('\n自检结果：PASS ' + pass + ' / FAIL ' + fail);
process.exit(fail ? 1 : 0);
