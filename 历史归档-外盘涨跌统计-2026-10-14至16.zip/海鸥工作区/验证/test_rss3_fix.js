/* 日橡胶修复的真实链路验证：
   前端补档用 jsonpDailyK 拉日K（script 注入，固定回调名 var d=），取今天那根的 close。
   这里用 node 复刻同一段逻辑（https + 同一解析方式），断言：
     ① 能拿到日K数组
     ② 最后一根是"今天"的、close 是数字
     ③ 与云端 fetch.py 取到的值一致（450.1）
     ④ 日K 那根的 open/high/low 也合理（说明确实是今天那根） */
const https = require('https');

const URL = 'https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/GlobalFuturesService.getGlobalFuturesDailyKLine?symbol=RSS3';

function get(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 20000 }, r => {
      let b = ''; r.setEncoding('utf8');
      r.on('data', d => b += d);
      r.on('end', () => resolve(b));
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}

(async () => {
  console.log('== 前端日K通道（模拟 script 注入后的 window.d）==');
  const txt = await get(URL);
  console.log('  返回长度:', txt.length, '字节');
  // 与浏览器一致的解析：固定回调名 var d=([...])
  const m = /\((\[.*\])\)/s.exec(txt);
  if (!m) { console.log('  !! 解析失败'); process.exit(1); }
  const arr = JSON.parse(m[1]);
  const last = arr[arr.length - 1];
  const today = new Date().toISOString().slice(0, 10);

  console.log('  日K 根数:', arr.length);
  console.log('  最后一根:', JSON.stringify(last));

  let pass = 0, fail = 0;
  const ok = (name, cond) => { console.log((cond ? '  PASS ' : '  FAIL ') + name); cond ? pass++ : fail++; };

  ok('能拿到日K数组', Array.isArray(arr) && arr.length > 100);
  ok('最后一根是今天（' + today + '）', last.date === today);
  ok('close 是数字', !isNaN(parseFloat(last.close)));
  ok('close = 450.1（与云端 fetch.py 一致）', Math.abs(parseFloat(last.close) - 450.1) < 0.05);
  ok('该根 open/high/low 齐全', !!last.open && !!last.high && !!last.low);
  console.log('\n  → close=' + last.close + '  open=' + last.open + '  high=' + last.high + '  low=' + last.low);
  console.log('  → 这就是日盘 14:50 的收盘价，前端取它做 day 档基准（与云端同口径）');

  console.log('\n自检结果：PASS ' + pass + ' / FAIL ' + fail);
  process.exit(fail ? 1 : 0);
})();
