# -*- coding: utf-8 -*-
"""换月新判据的真实链路验证（两轮）。

轮 1（正常）：跑真实数据 → 应当"未发现疑似换月失真"（不误判）
轮 2（构造）：把 ROLLOVER_OVERRIDE 设为 {'美燃油': True} → 应当把美燃油的基准改成"昨结算"、
              起始时间列标为「昨结 换月」、note='换月'（验证修正动作为正确）
"""
import io, json, os, shutil, subprocess, sys, time

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
PY = r'C:\Users\wing\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
SRC = os.path.join(WS, '交付', 'fetch.py')


def run(tag, patch=None, seed_from=None):
    d = os.path.join(WS, '验证', '换月测试_' + tag)
    os.makedirs(d, exist_ok=True)
    code = io.open(SRC, encoding='utf-8').read()
    if patch:
        assert patch[0] in code, '找不到要替换的配置行'
        code = code.replace(patch[0], patch[1])
        io.open(os.path.join(d, 'fetch.py'), 'w', encoding='utf-8', newline='\n').write(code)
    else:
        shutil.copy(SRC, os.path.join(d, 'fetch.py'))
    if seed_from:
        shutil.copy(seed_from, os.path.join(d, 'data.json'))
    print('--- 轮 %s ---' % tag)
    p = subprocess.run([PY, 'fetch.py'], cwd=d, capture_output=True)
    for line in p.stdout.decode('utf-8', 'replace').splitlines():
        if any(k in line for k in ['模式', '换月', '完成', 'Error', 'Traceback']):
            print('   ' + line)
    return json.load(io.open(os.path.join(d, 'data.json'), encoding='utf-8')), os.path.join(d, 'data.json')


# 轮 1：正常
d1, f1 = run('正常')
fixed1 = [r['name'] for r in d1['rows'] if (r.get('note') or '') == '换月']
print()
print('  轮1 判定：%s 被误判为换月的行数 = %d %s' % ('PASS' if not fixed1 else 'FAIL', len(fixed1), fixed1 or ''))

# 轮 2：强制覆盖一个品种
d2, f2 = run('构造', patch=('ROLLOVER_OVERRIDE = {}', "ROLLOVER_OVERRIDE = {'美燃油': True}"), seed_from=f1)
ho = [r for r in d2['rows'] if r['name'] == '美燃油']
print()
if ho:
    r = ho[0]
    ps = None
    print('  轮2 美燃油：close=%s  ref=%s  note=%s' % (r.get('close'), r.get('ref'), r.get('note')))
    ok2 = (r.get('ref') == '换月' and r.get('note') == '换月' and r.get('ref_actual') is None)
    print('  轮2 判定：%s 修正动作正确（基准->昨结、起始时间列标「换月」、说明字段置空）' % ('PASS' if ok2 else 'FAIL'))
else:
    ok2 = False
    print('  轮2 判定：FAIL 输出里找不到美燃油')

sys.exit(0 if (not fixed1 and ok2) else 1)
