# -*- coding: utf-8 -*-
"""对比 原版 fetch.py 与 v1.10 版 fetch.py 的输出：
  1) 基准价 close 必须逐行完全一致（证明"零数值改动"）
  2) 检查新版新增的 ref_actual / gap_min 是否合理
"""
import io, json, os, sys

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区\验证'
a = json.load(io.open(os.path.join(WS, '原版', 'data.json'), encoding='utf-8'))
b = json.load(io.open(os.path.join(WS, '新版', 'data.json'), encoding='utf-8'))

print('原版 generated_at =', a.get('generated_at'), '| mode =', a.get('mode'), '| rows =', len(a['rows']))
print('新版 generated_at =', b.get('generated_at'), '| mode =', b.get('mode'), '| rows =', len(b['rows']))
print()

A = {r['name']: r for r in a['rows']}
B = {r['name']: r for r in b['rows']}

print('%-14s %14s %14s %8s   %-14s %8s' % ('品种', '原版 close', '新版 close', '一致?', '实际取价笔', '偏差分'))
print('-' * 92)
same = diff = 0
for nm in [r['name'] for r in a['rows']]:
    ra, rb = A.get(nm), B.get(nm)
    if rb is None:
        print('%-14s %14s %14s %8s' % (nm, ra.get('close'), '(新版缺失)', '缺失'))
        diff += 1
        continue
    ca, cb = ra.get('close'), rb.get('close')
    ok = (ca == cb) or (ca is not None and cb is not None and abs(ca - cb) < 1e-9)
    tag = '一致' if ok else '不一致'
    if ok:
        same += 1
    else:
        diff += 1
    print('%-14s %14s %14s %8s   %-14s %8s' % (
        nm, ca, cb, tag, rb.get('ref_actual') or '—', rb.get('gap_min') if rb.get('gap_min') is not None else '—'))

print()
print('基准价 close 对比：一致 %d 行，不一致 %d 行' % (same, diff))

# 标称 ref vs 实际取价笔，逐行标注偏移
print()
print('== 「起始时间」标称 vs 实际取价笔 ==')
odd = [(r['name'], r.get('ref'), r.get('ref_actual'), r.get('gap_min')) for r in b['rows']
       if r.get('gap_min') is not None and abs(r['gap_min']) >= 3]
if odd:
    for nm, ref, act, g in sorted(odd, key=lambda x: -abs(x[3])):
        print('  %-14s 标称 %-12s 实取 %-12s 偏差 %+d 分' % (nm, ref, act, g))
else:
    print('  （本轮无 ≥3 分钟的偏移）')

# 关键字段是否齐全
missing = [r['name'] for r in b['rows'] if 'ref_actual' not in r or 'gap_min' not in r]
print()
print('新字段齐全性：', '全部行都有 ref_actual/gap_min' if not missing else ('缺字段: ' + str(missing)))
sys.exit(1 if diff else 0)
