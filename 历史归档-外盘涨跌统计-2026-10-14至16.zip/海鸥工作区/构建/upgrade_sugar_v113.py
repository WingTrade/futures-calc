# -*- coding: utf-8 -*-
"""把 build_fetch_v110.py 里原糖的处理升级为 v1.13：
   ① 删掉 6a（last_group_node）与 6c（原糖参考时点固定 23:00）两段补丁
   ② 把 6d 补丁的 new 部分换成 v1.13 版本（统一 15:00 基准；day 档取 15:00 之后的第一笔）
   ③ 版本号与说明同步
"""
import io, os, sys

P = r'E:\DwnlData\外盘涨跌统计\海鸥工作区\构建\build_fetch_v110.py'
s = io.open(P, encoding='utf-8').read()
orig = s

NEW_BODY = """        elif name == '美原糖':
            # v1.13（用户口径）：所有品种统一以"国内 15:00 收盘"为基准价。
            #   原糖自身时段 15:30 → 次日 01:00，所以 15:00 那一刻它【没有成交】。
            #   day 档（15:00 基准）：取"15:00 之后的第一笔"（≈它今天开盘的价），
            #     这样时间跨度与其他品种基本一致，而不是退到 14 小时前（今晨 01:00 的收盘价）。
            #   m1015 / m1130 / night 档：15:00 之后的价还没产生（或基准本就是 23:00），
            #     保持"取 ≤ 节点最后一笔"的通用逻辑。
            #   分时表取不到时（如次日表已滚动）交给 v1.8 继承机制按同 ref 顶住，不降级、不显示缺。
            if mode == 'day' and bars_ml:
                for _dt, _c in bars_ml:
                    if _dt >= ref_dt:
                        close, hit_dt = _c, _dt
                        break
            if close is None and bars_ml:
                try:
                    close, st, hit_dt = ref_price_from_bars(bars_ml, ref_dt, max_gap_hours=26,
                                                    now=now, allow_stale=True)
                except Exception:
                    close = None
            if close is None and secid:
                try:
                    close, st, hit_dt = ref_price_from_bars(bars_map.get(secid, []), ref_dt, now=now)
                    if st != 'ok':
                        close = None
                except Exception:
                    close = None
            if close is None:
                note = '缺'   # 下一轮/上一版按同 ref 继承
"""

# ① 删 6a
k = '# ---------- 6a.'
if k in s:
    i = s.index(k)
    j = s.index("tag='新增 last_group_node')", i) + len("tag='新增 last_group_node')")
    j = s.index('\n', j) + 1
    s = s[:i] + s[j:]
    print('已删除 6a（last_group_node）')

# ② 删 6c
k = '# ---------- 6c.'
if k in s:
    i = s.index(k)
    j = s.index("tag='美原糖参考时点固定 23:00')", i) + len("tag='美原糖参考时点固定 23:00')")
    j = s.index('\n', j) + 1
    s = s[:i] + s[j:]
    print('已删除 6c（原糖参考时点固定 23:00）')

# ③ 换 6d 的 new
k = '# ---------- 6d.'
i = s.index(k)
tag_mark = "tag='原糖取价分支简化（去日K路径）')"
ti = s.index(tag_mark, i)
seg = s[i:ti]
parts = seg.split('"""')
if len(parts) < 5:
    sys.exit('!! 6d 结构异常，parts=%d' % len(parts))
new_seg = parts[0] + '"""' + parts[1] + '"""' + parts[2] + '"""' + NEW_BODY + '"""' + parts[4]
s = s[:i] + new_seg + "tag='原糖统一 15:00 基准')" + s[ti + len(tag_mark):]
s = s.replace('# ---------- 6d. v1.12：原糖取价分支简化（删掉"取它自己 01:00 收盘价"的日K路径） ----------',
              '# ---------- 6d. v1.13：原糖 —— 统一"国内 15:00 收盘"基准（day 档取 15:00 之后第一笔） ----------')
print('已替换 6d 的 new 部分')

# ④ 版本号与说明
s = s.replace('云端抓取脚本（GitHub Actions 版 v1.12）', '云端抓取脚本（GitHub Actions 版 v1.13）')
s = s.replace('v1.12 更新（2026-10-16 · 海鸥工作区）：',
              'v1.13 更新（2026-10-16 · 海鸥工作区）：\n'
              '  - 美原糖改为与所有品种统一口径：**基准 = 国内 15:00 收盘时刻的价**。\n'
              '    原糖 15:00 那一刻没有成交（它 15:30 才开盘）→ day 档取"15:00 之后的第一笔"'
              '（≈它今天开盘价），\n'
              '    时间跨度与其他品种一致；不再退到今晨 01:00 的收盘价（跨 14 小时空档），'
              '也不再走日K。\n'
              '    分时表滚出该笔时由 v1.8 继承机制按同 ref 顶住。\n\n'
              'v1.12 更新（2026-10-16 · 海鸥工作区）：')

io.open(P, 'w', encoding='utf-8', newline='\n').write(s)
print()
print('构建脚本已更新：%d -> %d 字节' % (len(orig.encode('utf-8')), len(s.encode('utf-8'))))
print('  6a/6c 已移除:', ('# ---------- 6a.' not in s) and ('# ---------- 6c.' not in s))
print('  版本号 v1.13:', '（GitHub Actions 版 v1.13）' in s)
