# -*- coding: utf-8 -*-
"""生成「双击即看」的独立预览页（不需要任何本地服务器 / bat / 命令行）。

原理：普通页面用 fetch 读数据，而 file:// 双击打开时浏览器会禁掉 fetch（CORS 协议限制）。
      所以预览版做了两处适配：
        ① 数据内联：把 data.json 直接嵌进页面（window.__PREVIEW_DATA__）
        ② 改走 script 注入：腾讯返回 v_xxx="..."、新浪中转返回 hq_str_xxx="..."，
           本身就是 JS 赋值语句，用 <script> 标签加载即可拿全局变量（不受 CORS 限制）
      于是双击 HTML 就能看到完整效果（基准价 + 最新价 + 各种标记）。

产出：
  预览\\1-正常预览.html      看「起始时间」实际取价笔 + ※
  预览\\2-补档演示.html      data.json 改成"云端迟到" → 看绿色「即时」补档
  预览\\3-接管演示.html      中转地址改成死地址 → 看「分时」自动接管
交付版 index.html 保持原样（仍用 fetch，线上更高效），只改预览这三份。
"""
import io, json, os, sys

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
PAGE_SRC = os.path.join(WS, '交付', 'index.html')
DATA_SRC = os.path.join(WS, '验证', '新版', 'data.json')
OUT = os.path.join(WS, '预览')

page = io.open(PAGE_SRC, encoding='utf-8').read()
data = json.load(io.open(DATA_SRC, encoding='utf-8'))

SCRIPT_LOAD = """/* ---------- 预览专用：script 注入取文本（file:// 下不能 fetch 跨域） ---------- */
function scriptLoad(url, timeoutMs){
  return new Promise(function(resolve, reject){
    var s = document.createElement('script'), done = false;
    var tid = setTimeout(function(){ fin('timeout'); }, timeoutMs || 12000);
    function fin(err){
      if(done) return;
      done = true;
      clearTimeout(tid);
      try{ if(s.parentNode) s.parentNode.removeChild(s); }catch(e){}
      if(err){ reject(new Error(err)); } else { resolve(); }
    }
    s.onload = function(){ setTimeout(function(){ fin(null); }, 30); };   /* 等赋值生效 */
    s.onerror = function(){ fin('script-error'); };
    s.src = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_=' + Date.now();
    document.body.appendChild(s);
  });
}

"""


def patch(src, tag):
    n = 0

    # ① 插入内联数据（必须在主 script 之前）
    old = '<script>\n/* ====================================================================='
    if src.count(old) != 1:
        sys.exit('!! [%s] 找不到主 script 起点' % tag)
    inline = ('<script>window.__PREVIEW_DATA__='
              + json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
              + ';window.__PREVIEW_INJECT__=true;</script>\n'
              + '<script>\n/* =====================================================================')
    src = src.replace(old, inline)
    n += 1

    # ② 插入 scriptLoad
    old = '/* ---------- 本地缓存'
    if src.count(old) != 1:
        sys.exit('!! [%s] 找不到本地缓存锚点' % tag)
    src = src.replace(old, SCRIPT_LOAD + old)
    n += 1

    # ③ loadJson 优先用内联数据
    old = """async function loadJson(){
  if(jsonBusy) return false;"""
    new = """async function loadJson(){
  /* 预览版：file:// 下不能 fetch 本地文件，直接用内联数据 */
  if(window.__PREVIEW_DATA__){
    state.data = window.__PREVIEW_DATA__;
    saveCache(state.data);
    render();
    return true;
  }
  if(jsonBusy) return false;"""
    if src.count(old) != 1:
        sys.exit('!! [%s] loadJson 补丁未命中' % tag)
    src = src.replace(old, new)
    n += 1

    # ④ 腾讯最新价改 script 注入
    old = """    var resp = await fetch(TX_URL + codes.join(','), {cache:'no-store'});
    if(!resp.ok) throw new Error('HTTP '+resp.status);
    var text = await resp.text();   /* 响应头 charset=GBK，浏览器自动按 GBK 解码 */"""
    new = """    var text;
    if(window.__PREVIEW_INJECT__){
      /* 预览版：腾讯返回 v_xxx="..." 的 JS 赋值，script 注入后读全局变量 */
      await scriptLoad(TX_URL + codes.join(','));
      text = codes.map(function(cc){
        var v = window['v_' + cc];
        return (v == null) ? '' : ('v_' + cc + '="' + v + '"');
      }).join('\\n');
    }else{
      var resp = await fetch(TX_URL + codes.join(','), {cache:'no-store'});
      if(!resp.ok) throw new Error('HTTP '+resp.status);
      text = await resp.text();   /* 响应头 charset=GBK，浏览器自动按 GBK 解码 */
    }"""
    if src.count(old) != 1:
        sys.exit('!! [%s] refreshTx 补丁未命中' % tag)
    src = src.replace(old, new)
    n += 1

    # ⑤ 新浪中转最新价改 script 注入
    old = """    var text = null;
    for(var pi=0; pi<SINA_PROXIES.length; pi++){
      try{ text = await fetchSinaOnce(SINA_PROXIES[pi], need.join(',')); break; }
      catch(e){ text = null; }
    }"""
    new = """    var text = null;
    if(window.__PREVIEW_INJECT__){
      /* 预览版：中转同样返回 hq_str_xxx="..." 的 JS 赋值 */
      for(var pj=0; pj<SINA_PROXIES.length; pj++){
        try{
          await scriptLoad(SINA_PROXIES[pj] + need.join(','), SINA_TRY_TIMEOUT);
          text = need.map(function(cc){
            var v = window['hq_str_' + cc];
            return (v == null) ? '' : ('hq_str_' + cc + '="' + v + '"');
          }).join('\\n');
          if(text && text.indexOf('hq_str_') === 0) break;
          text = null;
        }catch(e){ text = null; }
      }
    }else{
      for(var pi=0; pi<SINA_PROXIES.length; pi++){
        try{ text = await fetchSinaOnce(SINA_PROXIES[pi], need.join(',')); break; }
        catch(e){ text = null; }
      }
    }"""
    if src.count(old) != 1:
        sys.exit('!! [%s] refreshSina 补丁未命中' % tag)
    src = src.replace(old, new)
    n += 1

    # ⑥ 标题标注为预览版
    src = src.replace('<title>外盘涨跌统计</title>', '<title>外盘涨跌统计（本地预览）</title>')
    n += 1
    return src, n


def write(name, content, note):
    p = os.path.join(OUT, name)
    io.open(p, 'w', encoding='utf-8', newline='\n').write(content)
    io.open(os.path.join(OUT, name.replace('.html', '.txt')), 'w', encoding='utf-8').write(note)
    print('  %-20s %d 字节' % (name, len(content.encode('utf-8'))))


print('生成双击即看的预览页：')

# ① 正常
p1, n1 = patch(page, '正常')
write('1-正常预览.html', p1,
      '【正常预览】双击本文件即可（不需要浏览器以外的任何东西）。\n\n'
      '看什么：\n'
      '  · 「起始时间」列 —— 稀疏品种显示的是"实际取到那一笔价"的时刻（如 10-16 14:46），\n'
      '    与档位节点差 ≥3 分钟时带黄色 ※，鼠标悬停看细节。\n'
      '  · 数据是真实的（实时从腾讯/新浪/新浪分时表取），不是假数据。\n\n'
      '注意：页面右上角若「新浪」灯是绿的，说明中转通道通；本文件用的是 file:// 直开，\n'
      '      走的是 script 注入方式取数，效果与线上一致。\n')

# ② 补档演示
d2 = json.loads(json.dumps(data))
d2['mode'] = 'm1130'
d2['title'] = '对比11:30涨跌统计'
d2['mode_desc'] = '隔夜'
d2['ref_desc'] = '参考: 今日 11:30'
d2['generated_at'] = '2026-10-16 13:01'
d2['demo_note'] = '演示用：故意改成"云端迟到"，触发前端翻表补档'
saved = data
data = d2
p2, n2 = patch(page, '补档演示')
data = saved
write('2-补档演示.html', p2,
      '【补档演示】data.json 被改成"云端还没更新到当前档"的样子（档位写的是 11:30 档）。\n\n'
      '看什么：页面发现云端档位落后，会自己翻新浪分时表把当前档的基准价算出来补上。\n'
      '        注意：算出来的值与云端逐位一致（同源同口径），所以【不加任何标记】——\n'
      '        算得准就不打扰你，页面上是干干净净的。\n\n'
      '对比方法：把本页和 1-正常预览 的「起始价」「涨跌幅」两列对一下，数字口径完全一致，\n'
      '          区别只是本页的档位是页面自己算的（云端那份还在排队）。\n\n'
      '这就是你的核心场景：早上 10:15 之后、Actions 还没跑完那几分钟，页面不会停在旧档。\n')

# ③ 接管演示
page3 = page
i = page3.index('var SINA_PROXIES = [')
j = page3.index('];', i) + 2
page3 = page3[:i] + "var SINA_PROXIES = [\n  'http://127.0.0.1:9/?list=',\n  'http://127.0.0.1:9/?list='\n];" + page3[j:]
p3, n3 = patch(page3, '接管演示')
write('3-接管演示.html', p3,
      '【接管演示】两条 Cloudflare 中转地址被改成必失败的地址，模拟"新浪快照通道挂掉"。\n\n'
      '看什么（打开后等 15-25 秒）：\n'
      '  1) 右上「新浪」灯变红；\n'
      '  2) 原糖 / 棉花 / 马棕油 / 铁矿 / 日橡胶 / 美燃油 六行自动改用新浪分时表接管，\n'
      '     数字仍是当下的价（与快照偏差 0.000%~0.153%）；\n'
      '     新鲜的那些【不加标记】—— 通道状态看右上角红灯就够了；\n'
      '     只有该品种此刻确实没成交时（如日橡胶），才把那一笔的时刻标出来，如「分时 16:26」；\n'
      '  3) 其余品种不受影响（走腾讯直连，照常实时）。\n\n'
      '这就是通道故障时的真实兜底表现 —— 数据不断，而且都是当下的价。\n')

io.open(os.path.join(OUT, '说明.txt'), 'w', encoding='utf-8').write(
    '这三个 HTML 都是【双击即看】的独立预览页，不需要启动任何服务、不需要命令行。\n'
    '文件里的数据是真实现取的（腾讯 / 新浪 / 新浪分时表），不是假数据。\n\n'
    '  1-正常预览.html   看「起始时间」的实际取价笔 + ※ 标记\n'
    '  2-补档演示.html   看云端迟到时页面自己补档（绿色「即时」）\n'
    '  3-接管演示.html   看新浪通道挂掉时自动用分时表接管（「分时」标记）\n\n'
    '同名的 .txt 文件是每个页面的说明。\n'
    '如果双击后浏览器里什么都不显示，请截图发我。\n')

print('完成 → ' + OUT)
