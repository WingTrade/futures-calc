# -*- coding: utf-8 -*-
"""完全绕开 pip：走 PyPI 官方 JSON 接口拿 wheel 直链，urllib 下载，zipfile 解压。

（本环境 pip 的 install 与 download 都在"解包 wheel"一步被拒；但普通 HTTP 下载与本地解压正常。）
"""
import io, json, os, shutil, ssl, sys, urllib.request, zipfile

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
TARGET = os.path.join(WS, '.pytools')
WHL = os.path.join(WS, '.whl')
PKGS = ['pyinstaller', 'pyinstaller-hooks-contrib', 'altgraph', 'pefile',
        'pywin32-ctypes', 'packaging', 'setuptools']

ctx = ssl._create_unverified_context()
# 清掉上一轮 pip 留下的坏文件
for d in (TARGET, WHL):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs(TARGET, exist_ok=True)
os.makedirs(WHL, exist_ok=True)

HDRS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 'Accept': 'application/json, */*'}


def get(url, timeout=90):
    return urllib.request.urlopen(urllib.request.Request(url, headers=HDRS), timeout=timeout, context=ctx).read()


def pick(files):
    """优先级：py3-none-any > cp312-win_amd64 > 任意 win_amd64 > 任意 none-any"""
    def score(fn):
        if fn.endswith('py3-none-any.whl'):
            return 0
        if 'cp312' in fn and 'win_amd64' in fn:
            return 1
        if 'win_amd64' in fn:
            return 2
        if fn.endswith('none-any.whl'):
            return 3
        return 9
    cands = [f for f in files if f['filename'].endswith('.whl')]
    if not cands:
        return None
    cands.sort(key=lambda f: score(f['filename']))
    return cands[0] if score(cands[0]['filename']) < 9 else None


done, failed = [], []
for pkg in PKGS:
    try:
        meta = json.loads(get('https://pypi.org/pypi/%s/json' % pkg).decode('utf-8'))
        f = pick(meta.get('urls') or [])
        if not f:
            failed.append((pkg, 'no suitable wheel'))
            print('  跳过 %-26s 没有合适的 wheel' % pkg)
            continue
        url = f['url']
        fp = os.path.join(WHL, f['filename'])
        io.open(fp, 'wb').write(get(url))
        if not zipfile.is_zipfile(fp):
            failed.append((pkg, 'not a zip'))
            print('  失败 %-26s 下载内容不是 zip（%d 字节）' % (pkg, os.path.getsize(fp)))
            continue
        with zipfile.ZipFile(fp) as z:
            z.extractall(TARGET)
        done.append(pkg)
        print('  装上 %-26s %-46s %d KB' % (pkg, f['filename'], os.path.getsize(fp) // 1024))
    except Exception as e:
        failed.append((pkg, type(e).__name__))
        print('  失败 %-26s %s %s' % (pkg, type(e).__name__, str(e)[:80]))

print('\n成功 %d / %d' % (len(done), len(PKGS)))
sys.path.insert(0, TARGET)
try:
    import PyInstaller
    print('PyInstaller 就绪，版本:', PyInstaller.__version__)
    print('OK')
except Exception as e:
    print('仍不可用:', type(e).__name__, str(e)[:150])
    sys.exit(1)
