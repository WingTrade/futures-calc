# -*- coding: utf-8 -*-
"""① 同步上传说明里的改名示例 ② 检查成品里是否还有旧名残留。"""
import io, os

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
OLD = ['美黄豆粉', '美黄豆油', '美国棉花', '美国天然气']

# ① 上传说明
p = os.path.join(WS, '交付', '上传说明.md')
s = io.open(p, encoding='utf-8').read()
before = sum(s.count(x) for x in OLD)
s = s.replace('如美黄豆粉 `10-16 14:46`', '如美豆粕 `10-16 14:46`')
s = s.replace('（美黄豆粉、日橡胶这类稀疏品种最明显）', '（美豆粕、日橡胶这类稀疏品种最明显）')
io.open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('上传说明：旧名 %d → %d' % (before, sum(s.count(x) for x in OLD)))

# ② 成品检查
print()
print('成品里旧名残留检查：')
for f in ['交付/fetch.py', '交付/index.html', '交付/上传说明.md', '诊断页/外盘体检.html']:
    fp = os.path.join(WS, f.replace('/', os.sep))
    if not os.path.exists(fp):
        print('  %-22s （不存在）' % f)
        continue
    t = io.open(fp, encoding='utf-8').read()
    bad = [x for x in OLD if x in t]
    newok = [x for x in ['美豆粕', '美豆油', '美棉花', '美天然气'] if x in t]
    print('  %-22s 旧名残留: %-28s 新名: %s' % (f, str(bad) if bad else '无', newok))
