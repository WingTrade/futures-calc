/* =====================================================================
   v2.11 增量模块：分时接管（让那 6 个品种在任何情况下都有【当下】的价）
   ---------------------------------------------------------------------
   需求约束（用户明确）：只要当下的最新价，与基准价做涨跌统计。差几秒可以，
                        差 10 分钟以上不要 —— 所以延时行情一律不用。

   问题：原糖 / 棉花 / 马棕油 / 铁矿 / 日橡胶 / 美燃油 全项目只有新浪一家源，
        而新浪快照（hq.sinajs.cn）有防盗链 + 无 CORS，必须过 Cloudflare 中转（单点）。
        原本以为的 TradingView 兜底在国内直连根本不通（实测 30 秒超时，无代理环境）。

   解法：新浪【分时表】接口 stock2.finance.sina.com.cn 可直连（实测 56-102ms）：
         · 不需要 Referer（快照接口必须要）
         · 支持 JSONP → 浏览器 <script> 注入即可，绕开 CORS
         · 表里最后一笔 = 该品种最新成交价，对活跃品种就是当前这一分钟
           （实测与快照价一致：原糖 / 棉花 0.000%）
         · 与起始价【同源同口径】（都是新浪），不存在跨源混算

   策略：① 主路（中转快照）正常 → 照旧，零额外开销
         ② 主路连续失败 → 自动接管：首轮全拉把 6 行填满，之后轮转（每轮 2 个品种）
         ③ 主路恢复 → 立即停用，不浪费流量
         ④ 某品种此刻确实没有新成交（如日橡胶）→ 不装成当下价，
            在行上直接标出那笔的时刻（「分时 14:11」），让你一眼判断

   代价：接管期分时表 1.6KB~36KB/品种，约 3-5KB/s；只在通道故障时发生。
   ===================================================================== */
var ML_URL = 'https://stock2.finance.sina.com.cn/futures/api/openapi.php/GlobalFuturesService.getGlobalFuturesMinLine?symbol=';
var ML_TICK_MS = 15000;     /* 接管期检查节奏（毫秒） */
var ML_PER_TICK = 2;        /* 每轮拉几个品种（6 个品种 → 每个约 45 秒刷新一次） */
var ML_TIMEOUT = 12000;     /* 单个品种超时（毫秒） */
var ML_STALE_MIN = 5;       /* 末根距现在超过这么多分钟 → 行上直接标出时刻
                               （用户标准：滞后 1 分钟可接受，但不能超过 5 分钟还装成当下的价） */
var mlBusy = false, mlTimer = null, mlCursor = 0;

/* 接管是否启用：
   ① 快照通道连续失败 2 次 → 接管；
   ② 刚打开页面就完全没拿到新浪数据（失败 1 次且一条都没有）→ 立刻接管，不干等。 */
function mlActive(){
  var f = state.snFail || 0;
  if(f >= 2) return true;
  return f >= 1 && !Object.keys(state.sn || {}).length;
}

/* 需要接管的品种（= 走新浪快照的那 6 个） */
function mlCodes(){
  var rows = (state.data && state.data.rows) || [], out = [], seen = {};
  for(var i=0;i<rows.length;i++){
    var c = sinaCodeOf(rows[i]);
    if(c && SINA_SYMS[c] && !seen[c]){ seen[c] = 1; out.push(c); }
  }
  return out;
}

/* 拉一个品种的分时表，取最后一笔 = 最新成交价；同时算出它距现在多少分钟 */
async function mlFetch(code){
  var sym = code.indexOf('hf_') === 0 ? code.slice(3) : code;
  var res = await jsonpMinline(sym);              /* 复用 v2.10 的 JSONP 拉取 */
  var arr = res.data && res.data.result && res.data.result.data && res.data.result.data.minLine_1d;
  var pts = buildPoints(arr);                      /* 复用 v2.10 的解析（含跨日推断） */
  if(!pts.length) return null;
  var p = pts[pts.length - 1];
  var v = p.price;
  if(code === 'hf_HG') v = v / 100;                /* 美铜：接口为美分/磅（同云端口径） */
  var ageMin = null;
  try{
    /* 距今多少分钟：只看"时分"，不依赖新浪给的日期标签
       （不同品种的日期标签语义不一致：有的是时段开始日、有的是交易归属日，
        例如日橡胶的表首根标 2026-10-16 / 16:13，末根 14:11 其实属于次日归属，
        按标签推会算成"未来"→ 误判成 0 分钟，把 1 小时前的价当当下价）。 */
    var nd = new Date();
    ageMin = (nd.getHours() * 60 + nd.getMinutes()) - p.min;
    if(ageMin < -5) ageMin += 1440;   /* 末根时间"看上去在未来" → 其实是昨天(或本时段前一日)那一笔 */
    if(ageMin < 0) ageMin = 0;
  }catch(e){}
  return { last: v, t: hhmmOf(p.min), date: p.date, ageMin: ageMin, ts: Date.now() };
}

/* 接管行的标记：新鲜的分时价与快照只差几秒，**不标**；
   只有"这行的价确实是旧时刻的"（该品种此刻无新成交）才把时刻摆出来，不装成当下价。 */
function mlTag(m){
  if(!m) return '';
  if(m.ageMin != null && m.ageMin > ML_STALE_MIN && m.t) return '分时 ' + m.t;
  return '';
}
function mlTagTip(m){
  if(!m) return '此价取自新浪分时表末根（与起始价同源同口径）';
  var base = '此价取自新浪分时表末根（与起始价同源同口径，约 1 分钟粒度）';
  if(m.ageMin != null && m.ageMin > ML_STALE_MIN){
    return base + '；该品种此刻无新成交，这一笔是 ' + m.t + ' 的（距今约 ' + m.ageMin + ' 分钟）';
  }
  return base + '；该笔时刻 ' + (m.t || '—') + '（距今约 ' + (m.ageMin == null ? '?' : m.ageMin) + ' 分钟）';
}

async function mlTick(){
  if(mlBusy) return;
  /* 状态迁移：进入 / 退出接管期 */
  if(mlActive()){
    if(!state.mlOn){ state.mlOn = true; state.mlFirst = false; }   /* 新一轮故障：重新全拉一次 */
  }else{
    if(state.mlOn){ state.mlOn = false; }
    return;
  }
  if(!state.data) return;
  var codes = mlCodes();
  if(!codes.length) return;
  mlBusy = true;
  try{
    if(state.mlFirst !== true){
      state.mlFirst = true;
      for(var i=0;i<codes.length;i++){                            /* 首轮全拉：尽快把 6 行填满 */
        var r0 = await mlFetch(codes[i]);
        if(r0){ state.ml[codes[i]] = r0; render(); }              /* 拉到一个刷一次，用户不必等全齐 */
      }
    }else{
      for(var k=0;k<ML_PER_TICK;k++){                             /* 之后轮转，控制流量 */
        var c = codes[mlCursor % codes.length];
        mlCursor++;
        var r1 = await mlFetch(c);
        if(r1){ state.ml[c] = r1; render(); }
      }
    }
    state.mlOk = Date.now();
    state.mlFail = 0;
  }catch(e){
    state.mlFail = (state.mlFail || 0) + 1;
  }finally{
    mlBusy = false;
  }
}
function scheduleMl(){
  clearTimeout(mlTimer);
  mlTimer = setTimeout(function(){ mlTick().then(scheduleMl); }, ML_TICK_MS);
}

/* 接管状态提示（页脚用） */
function mlNote(){
  if(!mlActive()) return '';
  var n = 0;
  for(var k in state.ml) if(state.ml.hasOwnProperty(k)) n++;
  return '｜新浪快照通道异常，已自动改用同源分时表接管（' + n + ' 个品种，滞后约 1 分钟）';
}
