# -*- coding: utf-8 -*-
"""绕开 pip：从清华镜像手动下载 wheel 并用 zipfile 解压安装 PyInstaller 到工作区。

为什么不用 pip：本环境里 pip 在"解压 wheel 到临时目录"这一步被拒
（OSError [Errno 13] Permission denied），权限修复后仍复现。改用 urllib 下载 + zipfile 解压，
完全不经过 pip 的解包流程。
"""
import io, os, re, ssl, sys, urllib.request, zipfile

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
TARGET = os.path.join(WS, '.pytools')
CACHE = os.path.join(WS, '.whl')
MIRROR = 'https://pypi.tuna.tsinghua.edu.cn/simple/{pkg}/'
PKGS = ['pyinstaller', 'pyinstaller-hooks-contrib', 'altgraph', 'pefile',
        'pywin32-ctypes', 'packaging', 'setuptools']

ctx = ssl._create_unverified_context()
os.makedirs(TARGET, exist_ok=True)
os.makedirs(CACHE, exist_ok=True)


def get(url, timeout=60):
    return urllib.request.urlopen(
        urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=timeout, context=ctx).read()


def pick_whl(html, pkg):
    """挑一个合适的 wheel：优先 py3-none-any，其次带 cp312/win_amd64 的"""
    hrefs = re.findall(r'href="([^"]+\.whl)[^"]*"', html)
    cands = []
    for h in hrefs:
        name = h.split('/')[-1].split('#')[0]
        if '(py3-none-any)' in h or 'py3-none-any' in name:
            cands.append((0, h, name))
        elif 'win_amd64' in name and ('cp312' in name or 'py3' in name):
            cands.append((1, h, name))
    if not cands:
        return None, None
    cands.sort(key=lambda x: x[0])
    _, url, name = cands[0]
    if url.startswith('../../'):
        url = 'https://pypi.tuna.tsinghua.edu.cn/' + url.lstrip('./')
    return url, name


installed = 0
for pkg in PKGS:
    try:
        html = get(MIRROR.format(pkg=pkg)).decode('utf-8', 'replace')
        url, name = pick_whl(html, pkg)
        if not url:
            print('  跳过 %-26s（找不到合适 wheel）' % pkg)
            continue
        fp = os.path.join(CACHE, name)
        if not os.path.exists(fp):
            io.open(fp, 'wb').write(get(url))
        with zipfile.ZipFile(fp) as z:
            z.extractall(TARGET)
        print('  装上 %-26s（%s）' % (pkg, name))
        installed += 1
    except Exception as e:
        print('  失败 %-26s %s %s' % (pkg, type(e).__name__, str(e)[:70]))

print()
sys.path.insert(0, TARGET)
try:
    import PyInstaller
    print('PyInstaller 就绪，版本:', PyInstaller.__version__)
    print('OK')
except Exception as e:
    print('PyInstaller 仍不可用:', type(e).__name__, str(e)[:100])
    sys.exit(1)
