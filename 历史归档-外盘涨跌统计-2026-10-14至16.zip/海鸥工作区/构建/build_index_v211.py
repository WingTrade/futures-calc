# -*- coding: utf-8 -*-
"""构建 index.html v2.11（在 v2.10 产物上再打补丁）。

v2.11 做两件事：
  ① 剔掉所有延时行情源（腾讯 fuHO 延时 10-15 分钟、TradingView 延时 10-20 分钟）
     —— 用户要求"只要当下的最新价，差几秒可以，差 10 分钟以上不要"。
  ② 新增「分时接管」：新浪快照通道（中转）故障时，自动改用**可直连的新浪分时表末根**
     —— 对活跃品种就是当前这一分钟的成交价（与起始价同源同口径）；
     若该品种此刻确实没有新成交，就把那一笔的时刻直接标在行上，不装成当下价。

输入：交付\\历史\\index-v210.html（固定存档，保证可复现）
输出：交付\\index.html
任何一处补丁未命中 → 报错退出。
"""
import io, os, sys

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
SRC = os.path.join(WS, '交付', '历史', 'index-v210.html')
DST = os.path.join(WS, '交付', 'index.html')
MOD = os.path.join(WS, '构建', 'v211_模块.js')

src = io.open(SRC, encoding='utf-8').read()
applied = []


def rep(old, new, expect=1, tag=''):
    global src
    n = src.count(old)
    if n != expect:
        print('!! 补丁未命中(%d!=%d) [%s]' % (n, expect, tag))
        print('   >>> ' + old[:150].replace('\n', '\\n'))
        sys.exit(2)
    src = src.replace(old, new)
    applied.append(tag)


# ---------- 1. 版本注释 ----------
rep(
"""   外盘涨跌统计 · 前端 v2.10（2026-10-16 · 海鸥工作区）
   v2.10：""",
"""   外盘涨跌统计 · 前端 v2.11（2026-10-16 · 海鸥工作区）
   v2.11：① 剔掉所有延时行情源 —— 腾讯 fuHO（延时 10-15 分钟）与 TradingView
            （延时 10-20 分钟）不再使用（用户要求：只要当下的价，差 10 分钟以上不要）。
          ② 新增「分时接管」——新浪快照通道（Cloudflare 中转）故障时，自动改用
            **可直连的新浪分时表末根**：活跃品种即当前这一分钟的成交价，与起始价
            同源同口径；该品种此刻确实无新成交时，把那一笔的时刻直接标在行上。
            来源：stock2.finance.sina.com.cn（实测 56-102ms 可直连、不需 Referer、
            支持 JSONP），主路恢复后立即停用。
   v2.10：""",
    tag='版本注释')

# ---------- 2. 插入 v2.11 模块 ----------
rep(
"""/* ---------- 状态 ---------- */""",
io.open(MOD, encoding='utf-8').read() + """/* ---------- 状态 ---------- */""",
    tag='插入 v2.11 模块')

# ---------- 3. state 增加接管字段 ----------
rep(
"""var state = { data:null, tx:null, txTime:'', txDate:'', txFail:0, sn:{}, snTime:'', snDate:'', snFail:0, gq:{},
              sse:null, sseLive:null, sseTryAt:0, sseErr:'' };""",
"""var state = { data:null, tx:null, txTime:'', txDate:'', txFail:0, sn:{}, snTime:'', snDate:'', snFail:0, gq:{},
              ml:{}, mlOn:false, mlFirst:false, mlFail:0, mlOk:0,
              sse:null, sseLive:null, sseTryAt:0, sseErr:'' };""",
    tag='state 增加接管字段')

# ---------- 4. 停用腾讯延时行情 fuHO ----------
rep(
"""/* 腾讯代码例外表：默认与新浪 hf_ 代码一致，个别品种不同。
   美燃油：腾讯无 hf_HO 实时源，须用 fuHO（延时行情，约 10-15 分钟） */
var TX_OVERRIDE = { 'hf_HO': 'fuHO' };""",
"""/* 腾讯代码例外表：默认与新浪 hf_ 代码一致，个别品种不同。
   v2.11：不再使用腾讯 fuHO —— 它是延时行情（约 10-15 分钟），
          用户要求"只要当下的价，差 10 分钟以上不要"。美燃油改由新浪通道覆盖，
          通道异常时由分时表末根接管（两者都是当下价）。 */
var TX_OVERRIDE = {};""",
    tag='停用腾讯延时源')

# ---------- 5. quoteOf：去掉 TradingView，加入分时接管 ----------
rep(
"""  var t = state.tx && state.tx[rowCode(r)];                 /* ② 腾讯（实时；美燃油为 fuHO 延时备份） */
  if(t) return t;
  if(sc && state.gq[sc]) return state.gq[sc];               /* ③ TradingView（延时，兜底） */
  return null;""",
"""  var t = state.tx && state.tx[rowCode(r)];                 /* ② 腾讯 hf_（实时，滞后几秒） */
  if(t) return t;
  if(sc && state.ml && state.ml[sc]) return state.ml[sc];    /* ③ v2.11 新浪分时表末根（直连接管，与起始价同源） */
  /* v2.11: 不再回落到 TradingView —— 它延时 10-20 分钟，不符合"要当下的价" */
  return null;""",
    tag='quoteOf 去延时源加接管')

# ---------- 6. srcTag / srcTagTip ----------
rep(
"""function srcTag(r, q){
  if(!q) return '';
  var sc = sinaCodeOf(r);
  if(sc && state.gq && state.gq[sc] && q === state.gq[sc]) return '延';
  if(rowCode(r) === 'fuHO') return '延';
  return '';
}""",
"""function srcTag(r, q){
  if(!q) return '';
  var sc = sinaCodeOf(r);
  if(sc && state.ml && state.ml[sc] && q === state.ml[sc]) return mlTag(state.ml[sc]);  /* v2.11 分时接管 */
  if(sc && state.gq && state.gq[sc] && q === state.gq[sc]) return '延时';
  if(rowCode(r) === 'fuHO') return '延时';
  return '';
}
/* 备用来源说明（鼠标悬停可见） */
function srcTagTip(tag, r, q){
  if(tag && tag.indexOf('分时') === 0){
    var sc = sinaCodeOf(r);
    return mlTagTip(sc && state.ml ? state.ml[sc] : null);
  }
  if(tag === '延时') return '此价来自延时源（约 10-15 分钟延时）';
  if(tag === '缓存') return '实时通道都没拿到价，此价来自云端落盘值（较旧，仅供参照）';
  return '该行最新价来自备用数据源';
}""",
    tag='srcTag 支持分时接管')

# ---------- 7. rowHtml 备用源标记 ----------
rep(
"""  var src = r.src ? '<span class="mk mk-src" title="该行最新价来自延时数据源">'+r.src+'</span>' : '';""",
"""  var src = r.src ? '<span class="mk mk-src" title="'+(r.srcTip||srcTagTip(r.src))+ '">'+r.src+'</span>' : '';""",
    tag='备用源标记带提示')

# ---------- 8. render：传 srcTip + 落盘值标「缓存」 ----------
rep(
"""    var tr = document.createElement('tr');
    tr.innerHTML = rowHtml({name:r.name, close:bq.close, last:last, chg:chg, pct:pct,
                            flag:r.flag, ref:bq.ref, mark:bq.mark, markTip:bq.markTip,
                            refTip:bq.refTip, src:srcTag(r, q)});
    tb.appendChild(tr);""",
"""    var stag = srcTag(r, q);
    /* v2.11: 只有"本该有实时价"的行才标「缓存」；
       美股三行是收盘口径（早上 9 点前看时早已收盘，不存在时效问题），不标任何小标 */
    if(!stag && !q && r.last != null && sinaCodeOf(r)) stag = '缓存';
    var tr = document.createElement('tr');
    tr.innerHTML = rowHtml({name:r.name, close:bq.close, last:last, chg:chg, pct:pct,
                            flag:r.flag, ref:bq.ref, mark:bq.mark, markTip:bq.markTip,
                            refTip:bq.refTip, src:stag, srcTip:srcTagTip(stag, r, q)});
    tb.appendChild(tr);""",
    tag='render 传 srcTip 与缓存标记')

# ---------- 9. 页脚提示 ----------
rep(
"""  document.getElementById('refDesc').textContent = (d.ref_desc || '') + refLiveNote(d);""",
"""  document.getElementById('refDesc').textContent = (d.ref_desc || '') + refLiveNote(d) + mlNote();""",
    tag='页脚接管提示')

# ---------- 10. boot：停 TradingView 轮询，挂分时接管 ----------
rep(
"""  refreshGlobal();                 /* ⑦ 延时备份（TradingView，立即拉一次） */
  scheduleGlobal();                /* ⑧ 之后每 60 秒刷一次 */""",
"""  /* v2.11: TradingView 轮询已停用（延时 10-20 分钟，不符合"要当下的价"）
     refreshGlobal();
     scheduleGlobal(); */""",
    tag='boot 停 TV 轮询')

rep(
"""  probeTick();                     /* ⑪ v2.10: 云端档位落后时，本页自己翻分时表补档 */
  scheduleProbe();                 /* ⑫ v2.10: 之后每 60 秒检查一次是否需要补档 */
}""",
"""  probeTick();                     /* ⑪ v2.10: 云端档位落后时，本页自己翻分时表补档 */
  scheduleProbe();                 /* ⑫ v2.10: 之后每 60 秒检查一次是否需要补档 */
  mlTick();                        /* ⑬ v2.11: 新浪快照通道异常时，用分时表接管那 6 个品种 */
  scheduleMl();                    /* ⑭ v2.11: 之后每 15 秒检查一次 */
}""",
    tag='boot 挂分时接管')

# ---------- 11. 切回前台 ----------
rep(
"""    loadJson();
    refreshTx();
    refreshSina();
    refreshGlobal();
    sseTick();
    probeTick();
    scheduleFast();
    scheduleSina();
    scheduleGlobal();
    scheduleSse();
    scheduleProbe();""",
"""    loadJson();
    refreshTx();
    refreshSina();
    /* v2.11: refreshGlobal(); 已停用（延时源） */
    sseTick();
    probeTick();
    mlTick();
    scheduleFast();
    scheduleSina();
    scheduleSse();
    scheduleProbe();
    scheduleMl();""",
    tag='visibilitychange 挂分时接管')

# ---------- 12. 切后台停接管定时 ----------
rep(
"""    clearTimeout(probeTimer); probeTimer = null;
  }else{""",
"""    clearTimeout(probeTimer); probeTimer = null;
    clearTimeout(mlTimer); mlTimer = null;
  }else{""",
    tag='后台停接管定时')

# ---------- 14. 清掉 rowHtml 里「即时」的死分支（补档已不打标记） ----------
rep(
"""  var mark = '';
  if(r.mark === '即时'){
    mark = '<span class="mk mk-live" title="云端档位尚未更新，此基准价由本页即时从分时表现算">即时</span>';
  }else if(r.mark){
    mark = '<span class="mk mk-lag" title="'+(r.markTip||'')+'">'+r.mark+'</span>';
  }""",
"""  /* v2.11: 补档成功不再打标记 —— 值同样源同口径、与云端逐位一致，
     标出来只会让人以为"这个数是临时的"。只有真需要提醒时才标记（旧时刻 / 缓存）。 */
  var mark = r.mark ? '<span class="mk mk-lag" title="'+(r.markTip||'')+'">'+r.mark+'</span>' : '';""",
    tag='清理「即时」死分支')

# ---------- 13. 页脚说明 ----------
rep(
"""  <div class="tip" id="tipMark">「起始时间」= 该品种实际取到那一笔价的时刻（与档位节点不同时打 ※，悬停看细节）·「即时」= 云端尚未更新，本页已自行补算 ·「延」= 该行用的是延时源</div>""",
"""  <div class="tip" id="tipMark">「起始时间」列 = 该品种实际取到那一笔价的时刻（成交稀疏的品种会比整点早或晚几分钟，属正常）·只有"这行的价确实是旧时刻的"才标出时刻（如「分时 14:11」）·三条实时路都没拿到时标「缓存」</div>""",
    tag='页脚说明')

# ---------- 校验 ----------
checks = {
    'mlTick': 1, 'scheduleMl': 1, 'srcTagTip': 2, 'mlNote': 2, 'ML_PER_TICK': 1,
    'function quoteOf': 1, 'function srcTag': 1, 'gq[sc]': 2,
}
ok = True
for k, v in checks.items():
    if src.count(k) < v:
        print('!! 关键符号不足: %s (实际 %d, 期望 >=%d)' % (k, src.count(k), v))
        ok = False
if not ok:
    sys.exit(3)
if 'fuHO' in src.split('TX_OVERRIDE = {};')[1].split('/* ----------')[0]:
    print('!! TX_OVERRIDE 未清空')
    sys.exit(4)

io.open(DST, 'w', encoding='utf-8', newline='\n').write(src)
print('已生成: %s' % DST)
print('补丁数: %d' % len(applied))
for a in applied:
    print('  - ' + a)
print('字节: %d -> %d' % (len(io.open(SRC, encoding='utf-8').read().encode('utf-8')), len(src.encode('utf-8'))))
