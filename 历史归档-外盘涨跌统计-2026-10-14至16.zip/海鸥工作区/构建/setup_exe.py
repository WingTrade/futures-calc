# -*- coding: utf-8 -*-
"""把电脑 EXE 的脚本同步到 v1.5（不动项目原文件，改工作区副本）。

同步点：
  ① 「起始时间」列改读 ref_actual（实际取价笔，与网页版一致），缺失时回落 ref
  ② 版本号与说明更新
"""
import io, os, shutil

SRC = r'E:\DwnlData\外盘涨跌统计\电脑EXE\外盘实时出图.py'
WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
D = os.path.join(WS, '构建', 'exe_v15')
os.makedirs(D, exist_ok=True)
DST = os.path.join(D, '外盘实时出图.py')

shutil.copy(SRC, DST)
s = io.open(DST, encoding='utf-8').read()

# ① 起始时间列：优先 ref_actual（实际取价笔）
old = """        out_rows.append({'name': SHORT_NAMES.get(nm, nm), 'close': close, 'last': last,
                         'chg': chg, 'pct': pct, 'ref': r.get('ref')})"""
new = """        out_rows.append({'name': SHORT_NAMES.get(nm, nm), 'close': close, 'last': last,
                         'chg': chg, 'pct': pct,
                         # v1.5: 「起始时间」列显示【实际取到那一笔价】的时刻（与网页版一致）；
                         #       云端 data.json 的 ref_actual 缺失时回落标称档位 ref
                         'ref': r.get('ref_actual') or r.get('ref')})"""
assert old in s, '未找到 out_rows 组装处'
s = s.replace(old, new)

# ② 版本号与说明
s = s.replace('外盘实时出图（双击版）· v1.4', '外盘实时出图（双击版）· v1.5')
anchor = 'v1.4：马棕油（BMD）显示窗口'
if anchor in s:
    s = s.replace(anchor,
                  'v1.5：「起始时间」列改显示【实际取到那一笔价】的时刻（读 data.json 的 ref_actual，'
                  '与网页版一致）——稀疏品种会显示如 14:46、美原糖 15:30、日橡胶 14:50；\n'
                  '      换月时显示「换月」；不再有任何小标。\n'
                  'v1.4：马棕油（BMD）显示窗口', 1)

io.open(DST, 'w', encoding='utf-8', newline='\n').write(s)
print('已生成 v1.5 副本：', DST)
print('  含 ref_actual:', 'ref_actual' in s)
print('  版本号:', [x for x in s.split('\n') if '双击版' in x][:1])
