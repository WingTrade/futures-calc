# -*- coding: utf-8 -*-
"""生成「补档演示」用的 data.json：故意把档位/时间改成"云端迟到"的样子，
用来触发前端翻表补档（这样用户不等到明天早上也能验收这个功能）。"""
import io, json, os

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
src = os.path.join(WS, '验证', '新版', 'data.json')
dst = os.path.join(WS, '预览', '补档演示', 'data.json')

d = json.load(io.open(src, encoding='utf-8'))
d['mode'] = 'm1130'
d['title'] = '对比11:30涨跌统计'
d['mode_desc'] = '隔夜'
d['ref_desc'] = '参考: 今日 11:30'
d['generated_at'] = '2026-10-16 13:01'
d['demo_note'] = '演示用：故意把档位/时间改成云端迟到的样子，用来触发前端翻表补档'

os.makedirs(os.path.dirname(dst), exist_ok=True)
io.open(dst, 'w', encoding='utf-8').write(json.dumps(d, ensure_ascii=False, indent=1))
print('已生成: ' + dst)
print('  mode=%s  generated_at=%s  rows=%d' % (d['mode'], d['generated_at'], len(d['rows'])))
print('  （当前应有档位由页面时钟决定；若现在是 15:00-23:00，应有档位=day，与 m1130 不同 → 触发补档）')
