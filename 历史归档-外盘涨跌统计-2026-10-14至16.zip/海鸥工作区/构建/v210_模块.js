/* =====================================================================
   v2.10 增量模块
     ① 起始时间说真话   ② 最新价来源标记   ③ 前端翻表补档
   ---------------------------------------------------------------------
   原理：起始价不是"守着节点抓"的，而是【事后从当日分时表里挑 ≤ 节点的那一笔】。
   云端 fetch.py 就是这么算的。只要交易时段没切换，本页用同一张表、同一套挑法，
   就能算出与云端逐位一致的基准价（已实测对账）。
   用途：云端（GitHub Actions）有 26-36 分钟排队延迟，开盘前页面可能还停在旧档 ——
        此时本页自己把这一档补上（值同源同口径、与云端逐位一致，所以【不加任何标记】）；
        data.json 一更新就自动切回云端值。
   安全性：只在"云端档位落后且已迟到"时触发；成功率低于一半就整体放弃、维持原样；
          夜盘档（各组节点不同）不补；云端一旦切到当前档，以云端为准。
   ===================================================================== */
var PROBE_MINLINE = 'https://stock2.finance.sina.com.cn/futures/api/openapi.php/GlobalFuturesService.getGlobalFuturesMinLine?symbol=';
var PROBE_MS = 60000;            /* 补档检查间隔（毫秒） */
var PROBE_TIMEOUT = 12000;       /* 单个品种分时请求超时（毫秒） */
var PROBE_LAG_MIN = 10;          /* 云端数据"迟到"判据：距今超过这么多分钟才考虑补档 */
var PROBE_CACHE_KEY = 'waiPanRefLiveV1';
var PROBE_MIN_OK_RATE = 0.5;     /* 补档成功率低于此值 → 放弃补档，维持云端值 */
var PROBE_RETRY_MS = 5 * 60000;  /* 同一档补档失败后的重试间隔 */

var refLive = null;              /* 补档结果 {key,date,mode,node,rows:{名:价},actual:{名:{t,gap}},ok,fail,done,ts} */
var probeBusy = false, probeTimer = null, probeTried = {};
var probeSeq = 0;

/* 当前"应有"档位（与云端 fetch.py decide_mode 同规则；周末按夜盘） */
function expectMode(){
  var d = new Date(), wd = d.getDay(), t = d.getHours()*60 + d.getMinutes();
  if(wd === 0 || wd === 6) return 'night';
  if(t >= 15*60 && t < 23*60) return 'day';
  if(t >= 10*60+15 && t < 11*60+30) return 'm1015';
  if(t >= 11*60+30 && t < 15*60) return 'm1130';
  return 'night';
}
/* 补档只做白天三档（全品种统一节点）；夜盘各组节点不同（23:00/01:00/02:30），不补 */
function probeNode(mode){
  if(mode === 'm1015') return '10:15';
  if(mode === 'm1130') return '11:30';
  if(mode === 'day')   return '15:00';
  return null;
}
function probeKey(date, node){ return date + '|' + node; }
function hhmmOf(min){ return pad2(Math.floor(min/60)) + ':' + pad2(min % 60); }

/* JSONP：新浪分时接口支持 callback → 用 <script> 注入即可取（无需 CORS、无需中转） */
function jsonpMinline(sym){
  return new Promise(function(resolve){
    var cb = 'wpRef' + (probeSeq++) + '_' + Date.now();
    var s = document.createElement('script'), done = false;
    var tid = setTimeout(function(){ fin(null, 'timeout'); }, PROBE_TIMEOUT);
    function fin(o, err){
      if(done) return;
      done = true;
      clearTimeout(tid);
      try{ if(s.parentNode) s.parentNode.removeChild(s); }catch(e){}
      try{ delete window[cb]; }catch(e){ window[cb] = undefined; }
      resolve({ data:o, err:err });
    }
    window[cb] = function(o){ fin(o, null); };
    s.onerror = function(){ fin(null, 'script-error'); };
    s.src = PROBE_MINLINE + encodeURIComponent(sym) + '&callback=' + cb + '&_=' + Date.now();
    document.body.appendChild(s);
  });
}
/* 日K JSONP（固定回调名 var d=）——仅日橡胶的补档特例用：
   它 14:50 就收盘，分时表在收盘前常常已无成交（或已切到夜盘时段），
   而"今天日K那根的收盘价"就是 14:50 的收盘价（夜盘 16:00 开盘后也不变）。 */
var PROBE_DAILYK = 'https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/GlobalFuturesService.getGlobalFuturesDailyKLine?symbol=';
function jsonpDailyK(sym){
  return new Promise(function(resolve, reject){
    var s = document.createElement('script'), done = false;
    var tid = setTimeout(function(){ fin('timeout'); }, PROBE_TIMEOUT);
    function fin(err){
      if(done) return;
      done = true;
      clearTimeout(tid);
      try{ if(s.parentNode) s.parentNode.removeChild(s); }catch(e){}
      if(err){ reject(new Error(err)); } else { resolve(window.d); }
    }
    s.onload = function(){ setTimeout(function(){ fin(null); }, 30); };
    s.onerror = function(){ fin('script-error'); };
    s.src = PROBE_DAILYK + encodeURIComponent(sym) + '&_=' + Date.now();
    document.body.appendChild(s);
  });
}

/* 分时表 → [{date,min,price}]（时间倒退视为跨日） */
function buildPoints(arr){
  var out = [], prev = -1, cur = null;
  if(!arr || !arr.length) return out;
  for(var i=0;i<arr.length;i++){
    var e = arr[i];
    if(!e || e.length < 2) continue;
    var tk = String(e[0]);
    if(!/^\d{2}:\d{2}$/.test(tk)) continue;
    var mn = parseInt(tk.slice(0,2),10)*60 + parseInt(tk.slice(3,5),10);
    var price = parseFloat(e[1]);
    if(isNaN(price)) continue;
    if(prev >= 0 && mn < prev){
      var d = new Date(cur + 'T00:00:00');
      d.setDate(d.getDate()+1);
      cur = d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate());
    }else if(cur === null){
      cur = String((arr[0] && arr[0][0]) || '').slice(0,10);
    }
    prev = mn;
    out.push({date:cur, min:mn, price:price});
  }
  return out;
}
/* 取 ≤ 目标（日期 ≤ 目标日 且 分钟 ≤ 目标分钟）的最后一笔 —— 与云端同规则 */
function pickPoint(pts, dateKey, targetMin){
  var best = null;
  for(var i=0;i<pts.length;i++){
    var p = pts[i];
    if(p.date > dateKey) break;
    if(p.date === dateKey && p.min > targetMin) break;
    best = p;
  }
  return best;
}

/* ---------- 缓存与状态判定 ---------- */
function loadProbeCache(){
  try{
    var o = JSON.parse(localStorage.getItem(PROBE_CACHE_KEY) || 'null');
    if(o && o.key && o.rows && o.done) return o;
  }catch(e){}
  return null;
}
function saveProbeCache(o){ try{ localStorage.setItem(PROBE_CACHE_KEY, JSON.stringify(o)); }catch(e){} }

/* 补档是否正在生效（= 展示应以本页现算值为准） */
function refLiveActive(){
  if(!refLive || !refLive.done) return false;
  var mode = expectMode(), node = probeNode(mode);
  if(!node) return false;
  if(refLive.key !== probeKey(todayYmd(), node)) return false;
  if(state.data && state.data.mode === mode) return false;   /* 云端已切到当前档 → 以云端为准 */
  return true;
}
/* 是否需要发起补档：云端档位 ≠ 应有档位，且云端数据已"迟到" */
function probeNeeded(){
  var d = state.data;
  if(!d || !d.rows) return false;
  var mode = expectMode(), node = probeNode(mode);
  if(!node) return false;
  if(d.mode === mode) return false;
  var ga = String(d.generated_at || '');
  if(ga.slice(0,10) !== todayYmd()) return false;             /* 云端数据不是今天的 → 可能休市，不乱补 */
  var t = Date.parse(ga.replace(' ', 'T') + ':00');
  if(isNaN(t)) return false;
  if((Date.now() - t) < PROBE_LAG_MIN * 60000) return false;  /* 还没迟到 */
  return true;
}

/* ---------- 补档主流程 ---------- */
async function probeRun(mode, node, date, key){
  probeBusy = true;
  var rows = (state.data && state.data.rows) || [];
  var targetMin = parseInt(node.slice(0,2),10)*60 + parseInt(node.slice(3,5),10);
  var out = { key:key, date:date, mode:mode, node:node, rows:{}, actual:{}, ok:0, fail:0, done:false, ts:Date.now() };
  var cand = [];
  for(var i=0;i<rows.length;i++){
    var sc = sinaCodeOf(rows[i]);
    /* v2.12: 美原糖不参与补档 —— 它的基准是"国内糖最近一次收盘时刻（23:00）"的价，
       与当前档位（10:15/11:30/15:00）无关，云端那份本来就是对的。 */
    if(sc && rows[i].name !== '美原糖') cand.push({ name:rows[i].name, code:sc });
  }
  for(var j=0;j<cand.length;j++){
    var c = cand[j];
    var sym = c.code.indexOf('hf_') === 0 ? c.code.slice(3) : c.code;
    /* v2.11: 日橡胶特例 —— 日盘 14:50 收盘，分时表在收盘前常已无成交
       （实测最后一笔只到 14:11），或已切到夜盘时段（取不到 ≤ 节点的笔）。
       直接取"今天日K那根的收盘价" = 14:50 的收盘价（与云端同一口径）。 */
    if(c.name === '日橡胶' && mode === 'day'){
      try{
        var dk = await jsonpDailyK('RSS3');
        var bar = (dk && dk.length) ? dk[dk.length - 1] : null;
        if(bar && bar.date === date){
          var cv = parseFloat(bar.close);
          if(!isNaN(cv)){
            out.rows[c.name] = cv;
            out.actual[c.name] = { t: date.slice(5) + ' 14:50', gap: 0 };
            out.ok++;
            continue;
          }
        }
      }catch(e){ /* 拿不到就落回下面的分时逻辑 */ }
    }
    try{
      var res = await jsonpMinline(sym);
      var arr = res.data && res.data.result && res.data.result.data && res.data.result.data.minLine_1d;
      var pts = buildPoints(arr);
      var hit = pickPoint(pts, date, targetMin);
      if(!hit){ out.fail++; continue; }
      var v = hit.price;
      if(c.code === 'hf_HG') v = v / 100;                       /* 美铜：接口为美分/磅（与云端同口径） */
      out.rows[c.name] = v;
      out.actual[c.name] = { t: hit.date.slice(5) + ' ' + hhmmOf(hit.min), gap: targetMin - hit.min };
      out.ok++;
    }catch(e){
      out.fail++;
    }
  }
  probeBusy = false;
  var total = out.ok + out.fail;
  if(total && (out.ok / total) >= PROBE_MIN_OK_RATE){
    out.done = true;
    refLive = out;
    saveProbeCache(out);
  }else{
    probeTried[key] = Date.now();                               /* 成功率太低：本轮放弃，过一会儿再试 */
  }
  render();
}

async function probeTick(){
  if(probeBusy) return;
  if(!state.data) return;
  var mode = expectMode(), node = probeNode(mode);
  if(!node) return;                                             /* 夜盘档不补 */
  var key = probeKey(todayYmd(), node);
  if(!refLive || refLive.key !== key){
    var c = loadProbeCache();
    if(c && c.key === key) refLive = c;                          /* 命中缓存（同一档不必重拉） */
  }
  if(refLive && refLive.key === key){ render(); return; }
  if(!probeNeeded()) return;
  if(probeTried[key] && (Date.now() - probeTried[key]) < PROBE_RETRY_MS) return;
  await probeRun(mode, node, todayYmd(), key);
}
function scheduleProbe(){
  clearTimeout(probeTimer);
  probeTimer = setTimeout(function(){ probeTick().then(scheduleProbe); }, PROBE_MS);
}

/* ---------- 展示层：基准价来源 / 起始时间说真话 / 延时标记 ---------- */
/* 基准价 ① 本页即时补档（整档统一，避免同一张表混源） ② 云端 data.json */
function baseQuoteOf(r){
  /* 美股三行（标普/道指/纳指）没有实时源：它们是"最近两个收盘价对比"的收盘口径，
     全天固定，不随盘中波动，也不参与补档/接管 —— 永远用云端值，且不打任何标记。 */
  if(!sinaCodeOf(r)){
    return { close: r.close, ref: r.ref_actual || r.ref, mark: '', markTip: '', refTip: '' };
  }
  if(refLiveActive()){
    var v = refLive.rows[r.name];
    /* v2.12: 美原糖不参与补档（它的基准跟着国内糖的收盘时刻走，与档位无关）→ 用云端值 */
    if(v == null && r.name === '美原糖'){
      return { close: r.close, ref: r.ref_actual || r.ref, mark: '', markTip: '', refTip: '' };
    }
    var a = refLive.actual[r.name];
    var refTxt = a ? a.t : ((refLive.date || '').slice(5) + ' ' + refLive.node);
    /* 补档算出来的基准价与云端逐位一致（同源同口径），所以【不做任何标记】——
       标出来只会让人怀疑"这个数是不是临时的"。只有"算不出来"的情况才需要说明。 */
    return { close: (v == null ? null : v), ref: refTxt, mark: '', markTip: '', refTip: '' };
  }
  /* v2.13（用户要求）：取消 ※ 小标与悬停说明 ——「起始时间」列已经把真实取价笔显示出来了，
     看着时间就能明白，不需要额外小标。豆粕这类成交稀疏是正常现象（可容错），
     原糖这类"节点时刻还没开盘"也同样：时间列显示 15:30 一看就懂。 */
  return { close: r.close, ref: r.ref_actual || r.ref, mark: '', markTip: '', refTip: '' };
}
/* 最新价来源标记：延时源（TradingView 兜底 / 美燃油 fuHO） */
function srcTag(r, q){
  if(!q) return '';
  var sc = sinaCodeOf(r);
  if(sc && state.gq && state.gq[sc] && q === state.gq[sc]) return '延';
  if(rowCode(r) === 'fuHO') return '延';
  return '';
}
/* 页脚补充提示：只在"补档没能拿到数据"时说一句（算得准就不打扰） */
function refLiveNote(d){
  var mode = expectMode(), node = probeNode(mode);
  if(node && !refLiveActive() && probeTried[probeKey(todayYmd(), node)]){
    return '｜云端 ' + mode + ' 档尚未更新，本页补算未取得足够数据（部分行暂空）';
  }
  return '';
}
