# -*- coding: utf-8 -*-
"""构建 fetch.py v1.10（对 网页版\\fetch.py 精确打补丁）。

原则：只新增两个【说明性】字段，不改动任何数值口径。
  ref_actual = 该行基准价实际取自哪一笔分时的时刻
  gap_min    = 该笔时刻与本档位标称节点的分钟差

任何一处补丁未命中 → 报错退出，绝不产出半成品。
所有补丁片段一律用 "..." 双三引号包裹，避免单引号转义歧义。
"""
import io, os, py_compile, re, sys

ROOT = r'E:\DwnlData\外盘涨跌统计'
SRC = os.path.join(ROOT, '网页版', 'fetch.py')
DST = os.path.join(ROOT, '海鸥工作区', '交付', 'fetch.py')

src = io.open(SRC, encoding='utf-8').read()
orig = src
applied = []


def rep(old, new, expect=1, tag=''):
    global src
    n = src.count(old)
    if n != expect:
        print('!! 补丁未命中(%d!=%d) [%s]' % (n, expect, tag))
        print('   >>> ' + old[:140].replace('\n', '\\n'))
        sys.exit(2)
    src = src.replace(old, new)
    applied.append(tag)


def rex(pattern, new, expect=None, tag=''):
    global src
    matches = re.findall(pattern, src)
    if not matches or (expect is not None and len(matches) != expect):
        print('!! 正则命中数不符(%d) [%s]' % (len(matches), tag))
        sys.exit(2)
    src = re.sub(pattern, new, src)
    applied.append('%s x%d' % (tag, len(matches)))


# ---------- 1. 头部版本说明 ----------
rep(
"""外盘涨跌统计 · 云端抓取脚本（GitHub Actions 版 v1.9.2）
======================================================
v1.9.2 更新（2026-10-16）：
""",
"""外盘涨跌统计 · 云端抓取脚本（GitHub Actions 版 v1.15）
======================================================
  - 换月检测补第二通道（v1.15，采纳同行评审）：
      · v1.14 只查【最新价】是否跑出当段分时表区间 —— 覆盖"分时表与快照切合约不同步"的瞬间；
        但真实事故（10-16 美燃油）不是这样：两个源**都已切到新合约**，失真的是【起始价】
        —— 它跨过换月线后被"续接继承"钉成了老合约价（close=4.834 / last=4.596 / 昨结 4.654），
        所以每轮都不触发。经复核，该案例属实。
      · 新增通道2 `rollover_suspect_close()`：起始价跑出当段表区间、且明显偏离昨结算。
        双阈值分级：偏离 >= 2.5% → 自动修正（roll='fix'）；1.5%~2.5% → 只记录嫌疑
        （roll='watch'，不动数值，避免把"跨时段继承的正确值"改错）。留痕字段：roll / roll_gap。
      · 新增 ROLLOVER_EXCLUDE：日橡胶 / 新加坡铁矿石 / 伦敦银现货 不参与通道2
        （它们的起始价有专门来源，不是当段分时表）。

  - 换月检测判据重写（v1.14）：
      · 新判据：**最新价是否跑到【当段分时表】的价格区间之外**（±0.5% 容差）。
        同一段分时表必然是同一个合约 → 最新价理应落在它的 [min,max] 内；
        跑出去就说明两个数据源切合约不同步 = 换月。
      · 为什么废掉旧判据：新浪日K在换月点附近【自身数据矛盾】（实测布伦特 10-02 那根
        "低>开"、伦铝 10-09 那根"高<开"），拿它当区间不可靠；而且"最近 2 根"
        会把换月前那根【老合约】包进来、把区间撑宽 → 系统性漏检（回测 2/4 漏检）。
      · 新增手工覆盖表 ROLLOVER_OVERRIDE（自动检测失灵时按品种强制按换月处理）。
      · 修正动作不变：参考价 := 昨结算；起始时间列标「昨结 换月」。
      · 保护：分时表点数 < 3、区间幅度 < 0.2%、或表末根距今 > 30 分钟（时段已滚动）时不判。

v1.13 更新（2026-10-16 · 海鸥工作区）：
  - 美原糖改为与所有品种统一口径：**基准 = 国内 15:00 收盘时刻的价**。
    原糖 15:00 那一刻没有成交（它 15:30 才开盘）→ day 档取"15:00 之后的第一笔"（≈它今天开盘价），
    时间跨度与其他品种一致；不再退到今晨 01:00 的收盘价（跨 14 小时空档），也不再走日K。
    分时表滚出该笔时由 v1.8 继承机制按同 ref 顶住。

v1.12 更新（2026-10-16 · 海鸥工作区）：
  - 美原糖基准修正（用户口径）：基准取【国内对应品种最近一次收盘时刻】的价，不跟外盘自己的收盘走。
    国内糖（郑糖）收盘时刻：日盘 15:00、夜盘 23:00；原糖自身时段 15:30 → 次日 01:00，
    所以白档（10:15/11:30/15:00）它一律没有价 → 统一退到"最近一个已收盘的 23:00"。
    **删掉**原来"退到它自己 01:00 收盘的日K价"那条路径（那是外盘自己的收盘时刻，不是国内的，用户否掉）。
    原糖在分时表取不到时由 v1.8 继承机制按同 ref 顶住。
    记住这条总口径：**基准 = 国内最近一次对应品种收盘时刻的价**；只有外盘在那个时刻已经收盘
    （如日胶 14:50 收、节点 15:00）才用它自己的收盘价顶上。
  - 品种改名（用户要求，只改显示名，新浪/东财代码一律不动）：
      美黄豆粉 → 美豆粕、美黄豆油 → 美豆油、美国棉花 → 美棉花、美国天然气 → 美天然气
    前端匹配表（NAME2CODE）已同步。改名后第一轮会与上一版名字对不上，
    等于放弃一次继承机会；若恰逢"该品种本轮取不到价"，会显示一次"缺"，下一轮即恢复。

v1.11 更新（2026-10-16 · 海鸥工作区）：
  - 日橡胶基准修正：day 档（15:00 基准）改用"今天日K那根的收盘价"（= 日盘 14:50 收盘价）。
    该品种 14:50 收盘且成交极稀疏，分时表在收盘前常已无成交（实测最后一笔只到 14:11），
    原规则会取到 14:11 的价；而日K"今天"那根的 close 才是真实收盘价（夜盘 16:00 开盘后也不变）。
    「起始时间」列随之如实显示 14:50。仅此一品种、仅 day 档改动，其余数值口径不变。

v1.10 更新（2026-10-16 · 海鸥工作区）：
  - 新增两个【说明性】字段，数值口径零改动（close/last/chg/pct 与 v1.9.2 完全一致）：
      ref_actual = 该行基准价实际取自哪一笔分时的时刻，如 "10-16 10:23"
      gap_min    = 该笔时刻与本档位标称节点相差的分钟数，如 67
    背景：稀疏品种（美豆粕 / 伦锡 / 伦铅 / 天然气…）在档位节点附近没有成交，
    实际取的是更早的最后一笔，而页面「起始时间」列显示的是标称节点 ——
    看起来精确、实际模糊，拿它去分钟图上反查会对不上。这两个字段供前端如实显示。
  - 继承（v1.8 续接）、换月修正行过渡继承（v1.9.1）时一并继承这两个字段；
    换月修正行置空（修正值来自"昨结算"，不对应任何一笔分时）。
  - 文件末尾新增一行统计打印，便于日志里直接看到偏移情况。

v1.9.2 更新（2026-10-16）：
""",
    tag='头部版本说明')

# ---------- 2. ref_price_from_bars 返回"价 + 状态 + 取价笔时刻" ----------
rep(
"""    if best is None:
        return None, 'missing'
    if (ref_dt - best[0]) > timedelta(hours=max_gap_hours):
        if allow_stale:
            return best[1], 'ok'
        feed_live = bars and (now or now_cn()) - bars[-1][0] <= timedelta(hours=8)
        if not feed_live:
            return None, 'stale'
    return best[1], 'ok'
""",
"""    if best is None:
        return None, 'missing', None
    if (ref_dt - best[0]) > timedelta(hours=max_gap_hours):
        if allow_stale:
            return best[1], 'ok', best[0]          # v1.10: 一并返回取价笔时刻
        feed_live = bars and (now or now_cn()) - bars[-1][0] <= timedelta(hours=8)
        if not feed_live:
            return None, 'stale', None
    return best[1], 'ok', best[0]                   # v1.10: 一并返回取价笔时刻
""",
    tag='ref_price_from_bars 返回值')

rep(
"""def ref_price_from_bars(bars, ref_dt, max_gap_hours=14, now=None, allow_stale=False):
    \"\"\"从 [(datetime, price)] 里找 <= ref_dt 的最后一根。""",
"""def ref_price_from_bars(bars, ref_dt, max_gap_hours=14, now=None, allow_stale=False):
    \"\"\"从 [(datetime, price)] 里找 <= ref_dt 的最后一根。
    v1.10: 返回值增加第三项 = 该笔的 datetime（取价笔时刻），供"实际取价笔"字段使用。""",
    tag='ref_price_from_bars docstring')

# ---------- 3. 所有调用点接收第三项 ----------
rex(r'close, st = ref_price_from_bars\(', 'close, st, hit_dt = ref_price_from_bars(',
    expect=9, tag='调用点接收 hit_dt')

# ---------- 4. 行循环开头初始化 ----------
rep(
"""        last, flag = None, False
""",
"""        last, flag = None, False
        hit_dt = None   # v1.10: 本行基准价实际取自哪一笔（datetime）；不适用/取不到时 None
""",
    tag='循环内 hit_dt 初始化')

# ---------- 5. 原糖 日K 兜底路径：取价笔 = 该日K次日 01:00 收盘 ----------
rep(
"""                        if mode != 'night' and d_str:
                            rd = datetime.strptime(d_str, '%Y-%m-%d') + timedelta(days=1)
                            ref_text = f'{rd:%m-%d} 01:00'
""",
"""                        if mode != 'night' and d_str:
                            rd = datetime.strptime(d_str, '%Y-%m-%d') + timedelta(days=1)
                            ref_text = f'{rd:%m-%d} 01:00'
                            hit_dt = rd.replace(hour=1)   # v1.10: = 日K次日的 01:00 收盘（原糖时段收盘点）
""",
    tag='原糖日K路径 hit_dt')



# ---------- 6d. v1.13：原糖 —— 统一"国内 15:00 收盘"基准（day 档取 15:00 之后第一笔） ----------
rep(
"""        elif name == '美原糖':
            # v1.5: 原糖时段 15:30 → 次日 01:00。
            # day 模式（时段已开盘/进行中）：参考 = 前一（时段）01:00 收盘价（日K"昨天"根，
            # 排除"今天"根——它含 15:30 起进行中的夜盘，会随时间漂移），并同步修正标签为该收盘时刻。
            # 夜盘模式（8:50/12:50，时段已收盘未开）：参考 = 前一晚 23:00（minline 内），逻辑不变。
            if bars_ml:
                try:
                    close, st, hit_dt = ref_price_from_bars(bars_ml, ref_dt, max_gap_hours=26,
                                                    now=now, allow_stale=True)
                except Exception:
                    close = None
            if close is None:
                try:
                    d_str, c2 = sina_dailyk_closed_bar('RS', now, exclude_today=True)
                    if c2 is not None:
                        close = c2
                        # 参考的准确时点 = 该日K次日的 01:00（北京），与日K数据保持一致（跨周末自动正确）
                        if mode != 'night' and d_str:
                            rd = datetime.strptime(d_str, '%Y-%m-%d') + timedelta(days=1)
                            ref_text = f'{rd:%m-%d} 01:00'
                            hit_dt = rd.replace(hour=1)   # v1.10: = 日K次日的 01:00 收盘（原糖时段收盘点）
                except Exception:
                    close = None
            if close is None and secid:
                try:
                    close, st, hit_dt = ref_price_from_bars(bars_map.get(secid, []), ref_dt, now=now)
                    if st != 'ok':
                        close = None
                except Exception:
                    close = None
            # v1.7: 分时路径下同步修正标签——原糖时段 15:30 → 次日 01:00，白天/day 档
            #       实际取价笔为上一时段 01:00 收盘，标签同步为该真实时刻
            if close is not None and mode != 'night' and ref_text is None and bars_ml:
                _lb = None
                for _dt, _c in bars_ml:
                    if _dt <= ref_dt:
                        _lb = _dt
                    else:
                        break
                if _lb is not None and (ref_dt - _lb) > timedelta(hours=1):
                    ref_text = f'{_lb:%m-%d %H:%M}'
            if close is None:
                note = '缺'""",
"""        elif name == '美原糖':
            # v1.13（用户口径）：所有品种统一以"国内 15:00 收盘"为基准价。
            #   原糖自身时段 15:30 → 次日 01:00，所以 15:00 那一刻它【没有成交】。
            #   day 档（15:00 基准）：取"15:00 之后的第一笔"（≈它今天开盘的价），
            #     这样时间跨度与其他品种基本一致，而不是退到 14 小时前（今晨 01:00 的收盘价）。
            #   m1015 / m1130 / night 档：15:00 之后的价还没产生（或基准本就是 23:00），
            #     保持"取 ≤ 节点最后一笔"的通用逻辑。
            #   分时表取不到时（如次日表已滚动）交给 v1.8 继承机制按同 ref 顶住，不降级、不显示缺。
            if mode == 'day' and bars_ml:
                for _dt, _c in bars_ml:
                    if _dt >= ref_dt:
                        close, hit_dt = _c, _dt
                        break
            if close is None and bars_ml:
                try:
                    close, st, hit_dt = ref_price_from_bars(bars_ml, ref_dt, max_gap_hours=26,
                                                    now=now, allow_stale=True)
                except Exception:
                    close = None
            if close is None and secid:
                try:
                    close, st, hit_dt = ref_price_from_bars(bars_map.get(secid, []), ref_dt, now=now)
                    if st != 'ok':
                        close = None
                except Exception:
                    close = None
            if close is None:
                note = '缺'   # 下一轮/上一版按同 ref 继承
""",
    tag='原糖统一 15:00 基准')

# ---------- 6b. 日橡胶：day 档用"今天日K的收盘价"（= 14:50 收盘价） ----------
rep(
"""        elif name == '日橡胶':
            # v1.4: 日橡胶夜盘 16:00 开盘后旧时段被顶掉（同"开盘点效应"）
            # → 用日K"今天"那根兜底（= 当日日盘收盘价，14:00 收盘后不再变）
            if bars_ml:""",
"""        elif name == '日橡胶':
            # v1.11: 日盘 14:50 收盘。day 档（15:00 基准）改用"今天日K那根的收盘价"：
            #   该品种成交极稀疏，分时表在收盘前常已无成交（实测最后一笔只到 14:11），
            #   而日K"今天"那根的 close 就是 14:50 的收盘价，且夜盘 16:00 开盘后也不再变。
            #   （用户实测：新浪行情页显示的是 14:50 的数据，即收盘价。）
            if mode == 'day':
                try:
                    _rd, _rc = sina_dailyk_closed_bar('RSS3', now, exclude_today=False)
                    if _rc is not None and _rd == now.date().isoformat():
                        close = _rc
                        ref_text = f'{now:%m-%d} 14:50'          # 语义即"日盘 14:50 收盘"
                        hit_dt = now.replace(hour=14, minute=50, second=0, microsecond=0)
                except Exception:
                    close = None
            if close is None and bars_ml:""",
    tag='日橡胶 day 档用日K收盘价')

# ---------- 6. 铁矿石 日K兜底：取价笔 = 该时段起点 ----------
rep(
"""                try:
                    close, ref_show = fef_ref_from_dailyk(ref_dt)
                except Exception:
                    close, ref_show = None, None
""",
"""                try:
                    close, ref_show = fef_ref_from_dailyk(ref_dt)
                    hit_dt = ref_show   # v1.10: 该值取自日K的时段起点
                except Exception:
                    close, ref_show = None, None
""",
    tag='铁矿日K路径 hit_dt')

# ---------- 7. 行组装：写入两个新字段 ----------
rep(
"""        rows.append({
            'name': name, 'close': close, 'last': last, 'chg': chg, 'pct': pct,
            'flag': flag, 'note': note, 'code': sina_code,
            'ref': ref_text if ref_text is not None else (f'{ref_show:%m-%d %H:%M}' if ref_show else None),
        })
""",
"""        # v1.10: 记录"实际取价笔时刻"与"页面显示的起始时刻和它的差"（纯说明用途，不参与任何计算）
        _ref_actual = f'{hit_dt:%m-%d %H:%M}' if hit_dt is not None else None
        # 偏差基准 = 本行「起始时间」列最终显示的那个时刻（优先 ref_text 修正值，其次档位节点 ref_show）
        _nominal = ref_show if ref_text is None else None
        if ref_text is not None and hit_dt is not None:
            _m = re.match(r'^(\\d{2})-(\\d{2}) (\\d{2}):(\\d{2})$', ref_text)
            if _m:
                try:
                    _cand = hit_dt.replace(month=int(_m.group(1)), day=int(_m.group(2)),
                                           hour=int(_m.group(3)), minute=int(_m.group(4)),
                                           second=0, microsecond=0)
                    if (_cand - hit_dt).days > 180:
                        _cand = _cand.replace(year=_cand.year - 1)
                    elif (hit_dt - _cand).days > 180:
                        _cand = _cand.replace(year=_cand.year + 1)
                    _nominal = _cand
                except ValueError:
                    _nominal = None
        _gap_min = None
        if hit_dt is not None and _nominal is not None:
            _gap_min = int(round((_nominal - hit_dt).total_seconds() / 60.0))
        rows.append({
            'name': name, 'close': close, 'last': last, 'chg': chg, 'pct': pct,
            'flag': flag, 'note': note, 'code': sina_code,
            'ref': ref_text if ref_text is not None else (f'{ref_show:%m-%d %H:%M}' if ref_show else None),
            'ref_actual': _ref_actual,   # v1.10: 实际取价笔时刻，如 "10-16 10:23"
            'gap_min': _gap_min,         # v1.10: 与「起始时间」列显示时刻的分钟差，如 67
        })
""",
    tag='行组装新字段')

# ---------- 8. 继承（v1.8 续接）一并继承说明字段 ----------
rep(
"""        row['close'] = p['close']
        if row['last'] is None:
            row['last'] = p.get('last')
""",
"""        row['close'] = p['close']
        row['ref_actual'] = p.get('ref_actual')   # v1.10: 说明字段一并继承，保持口径一致
        row['gap_min'] = p.get('gap_min')
        if row['last'] is None:
            row['last'] = p.get('last')
""",
    tag='v1.8 继承带字段')

# ---------- 9. 换月修正行：说明字段置空 ----------
rep(
"""        row['ref'] = '昨结 换月'
        row['note'] = '换月'
""",
"""        row['ref'] = '昨结 换月'
        row['note'] = '换月'
        row['ref_actual'] = None   # v1.10: "昨结算"不对应任何一笔分时，说明字段置空
        row['gap_min'] = None
""",
    tag='换月修正行置空')

# ---------- 10. 美股防回退：说明字段一并回退 ----------
rep(
"""            row['ref'], row['chg'], row['pct'] = p.get('ref'), p.get('chg'), p.get('pct')
            row['note'] = '防退'
""",
"""            row['ref'], row['chg'], row['pct'] = p.get('ref'), p.get('chg'), p.get('pct')
            row['ref_actual'], row['gap_min'] = p.get('ref_actual'), p.get('gap_min')
            row['note'] = '防退'
""",
    tag='美股防回退带字段')

# ---------- 11. 结尾打印：实际取价笔偏移统计 ----------
rep(
"""    ok_n = sum(1 for r in rows if r['pct'] is not None)
    print(f'完成: {ok_n}/{len(rows)} 个品种有涨跌幅, 耗时 {time.time() - t0:.0f} 秒')
""",
"""    # v1.10: 顺带把"实际取价笔"的偏移情况打到日志里，方便一眼看出稀疏品种
    _gaps = [(r['name'], r['gap_min']) for r in rows if r.get('gap_min') is not None]
    if _gaps:
        _off = [(n, g) for n, g in _gaps if abs(g) >= 3]
        _msg = f'实际取价笔: {len(_gaps)} 行有记录'
        if _off:
            _msg += f', 其中偏离标称节点 >=3 分钟 {len(_off)} 行: ' + \\
                    ', '.join(f'{n}{g:+d}分' for n, g in sorted(_off, key=lambda x: -abs(x[1]))[:8])
        print(_msg)

    ok_n = sum(1 for r in rows if r['pct'] is not None)
    print(f'完成: {ok_n}/{len(rows)} 个品种有涨跌幅, 耗时 {time.time() - t0:.0f} 秒')
""",
    tag='结尾偏移统计')

# ---------- 17. v1.13：品种改名（用户要求，只改显示名，代码/代码位不动） ----------
rep(
"""    ('美国天然气',    'M23',   '102.NG00Y',  'hf_NG'),""",
"""    ('美天然气',      'M23',   '102.NG00Y',  'hf_NG'),""",
    tag='改名 美国天然气→美天然气')
rep(
"""    ('美黄豆粉',     'M23',   '103.ZM00Y',  'hf_SM'),""",
"""    ('美豆粕',       'M23',   '103.ZM00Y',  'hf_SM'),""",
    tag='改名 美黄豆粉→美豆粕')
rep(
"""    ('美黄豆油',     'M23',   '103.ZL00Y',  'hf_BO'),""",
"""    ('美豆油',       'M23',   '103.ZL00Y',  'hf_BO'),""",
    tag='改名 美黄豆油→美豆油')
rep(
"""    ('美国棉花',     'M23',   '108.CT00Y',  'hf_CT'),""",
"""    ('美棉花',       'M23',   '108.CT00Y',  'hf_CT'),""",
    tag='改名 美国棉花→美棉花')

# ---------- 18. v1.13：改名对照表（仅用于继承兼容，保证改名后第一轮不出现"缺"） ----------
rep(
"""VARIETIES = [""",
"""# v1.13: 品种改名对照（旧名 → 新名）。**只用于继承上一版 data.json 时兼容旧名**，
#   保证改名后的第一轮照样能继承到值，不会出现一次"缺"。
NAME_ALIAS_MAP = {
    '美黄豆粉': '美豆粕',
    '美黄豆油': '美豆油',
    '美国棉花': '美棉花',
    '美国天然气': '美天然气',
}

VARIETIES = [""",
    tag='新增 NAME_ALIAS_MAP')

# ---------- 19. v1.13：继承时同时按新名注册上一版的旧名行 ----------
rep(
"""        if _r.get('ref'):
            prev_by_key[(_r.get('name'), _r.get('ref'))] = _r
        prev_by_name.setdefault(_r.get('name'), _r)""",
"""        if _r.get('ref'):
            prev_by_key[(_r.get('name'), _r.get('ref'))] = _r
            # v1.13: 上一版里的"旧名 + 同 ref"行，也注册到新名下 → 改名后第一轮照样能继承
            _nn = NAME_ALIAS_MAP.get(_r.get('name'))
            if _nn:
                prev_by_key.setdefault((_nn, _r.get('ref')), _r)
        prev_by_name.setdefault(_r.get('name'), _r)
        _nn2 = NAME_ALIAS_MAP.get(_r.get('name'))
        if _nn2:
            prev_by_name.setdefault(_nn2, _r)""",
    tag='继承兼容旧名')

# ---------- 20. v1.14：换月检测新判据（分时表同段一致性） ----------
rep(
"""VARIETIES = [""",
"""# v1.14: 手工换月覆盖表 {品种名: True} —— 自动检测失灵时，把品种名填进来即可强制按换月处理
#   （基准 := 昨结算，起始时间列标「昨结 换月」）。
ROLLOVER_OVERRIDE = {}

VARIETIES = [""",
    tag='新增 ROLLOVER_OVERRIDE')

rep(
"""def sina_dailyk_highlow_range(""",
"""def rollover_suspect(bars, last, now, tol=0.005, min_span=0.002, max_age_min=30):
    \"\"\"v1.14: 换月嫌疑判定 —— 最新价是否跑到【当段分时表】的价格区间之外。

    原理（物理必然）：同一段分时表 = 同一个合约，所以"当前所有成交价"必然落在
    该分时表的 [min, max] 之内。若"最新价"跑出去了，说明参考价所在的数据源与
    最新价所在的数据源切合约不同步 —— 这就是换月。

    为什么不用日K区间（v1.9 的老判据）：
      · 新浪日K在换月点附近【自身数据矛盾】（实测：布伦特 10-02 那根"低>开"，
        伦铝 10-09 那根"高<开"），拿它当区间不可靠；
      · 且"最近 2 根"会把换月前那根【老合约】包进来，区间被撑宽 → 系统性漏检。

    返回 (是否可疑, 说明文字)。\"\"\"
    if not bars or last is None or len(bars) < 3:
        return False, ''
    lo = min(p for _dt, p in bars)
    hi = max(p for _dt, p in bars)
    if hi <= 0 or (hi - lo) / hi < min_span:
        return False, ''            # 区间过窄（表刚重置 / 极稀疏）→ 不可靠，不判
    last_dt = bars[-1][0]
    age_min = (now - last_dt).total_seconds() / 60.0
    if age_min > max_age_min:
        return False, ''            # 表本身已经"不新鲜"（如时段已滚动）→ 不是换月，不判
    if lo * (1 - tol) <= last <= hi * (1 + tol):
        return False, ''
    return True, '最新价 %s 落在分时表区间 [%s, %s] 之外' % (last, lo, hi)

def sina_dailyk_highlow_range(""",
    tag='新增 rollover_suspect')

rep(
"""        code = row.get('code')
        if not code or row.get('close') is None or code not in sina_map:
            continue
        ps = sina_map[code].get('prev_settle')
        if not ps or ps <= 0:
            continue
        close = row['close']
        if abs(close - ps) / ps <= 0.02:
            continue                                     # 条件①未命中
        sym = code[3:] if code.startswith('hf_') else code
        rng = sina_dailyk_highlow_range(sym, 2)
        if not rng:
            continue                                     # 取不到日K → 不冒险，跳过
        lo, hi = rng
        if code in SINA_CENT_TO_DOLLAR:                  # 口径统一（美铜日K为美分）
            lo, hi = lo / 100.0, hi / 100.0
        if lo * 0.995 <= close <= hi * 1.005:
            continue                                     # 条件②未命中（在正常区间内）
        row['close'] = ps""",
"""        code = row.get('code')
        if not code or row.get('close') is None:
            continue
        # v1.14：判据改为"分时表同段一致性"（不再看日K，也不再依赖 2% 阈值）
        sym = code[3:] if code.startswith('hf_') else code
        suspect, why = rollover_suspect(ml_by_sym.get(sym) or [], row.get('last'), now)
        if not suspect and row['name'] in ROLLOVER_OVERRIDE:
            suspect, why = True, '手工覆盖表指定'
        ps = (sina_map.get(code) or {}).get('prev_settle')
        if not suspect or not ps or ps <= 0:
            continue
        close = row['close']
        row['close'] = ps""",
    tag='换月检测新判据')

rep(
"""        print(f"换月修正: {row['name']} 参考价 {close} -> 昨结 {ps}")""",
"""        print(f"换月修正: {row['name']} 参考价 {close} -> 昨结 {ps}（{why}）")""",
    tag='换月打印带原因')

rep(
"""    # 显示假跌 -4.9%，实际约 -1.3%）。双条件同时满足才修正（防误伤正常大波动日）：""",
"""    # 显示假跌 -4.9%，实际约 -1.3%）。v1.14 起判据已重写（见 rollover_suspect）：""",
    tag='换月注释更新')

# ---------- 21. v1.15：起始价（close）的换月判据 —— 覆盖"跨换月线被继承钉住" ----------
rep(
"""ROLLOVER_OVERRIDE = {}""",
"""ROLLOVER_OVERRIDE = {}

# v1.15: 明确【不参与】"起始价换月检测"的品种 —— 它们的起始价有专门来源，不是当段分时表：
#   日橡胶（day 档取当天日K收盘价）、新加坡铁矿石（可能走日K兜底）、伦敦银现货（可能走 5 日线兜底）。
#   少了这张表，它们会被误判成换月。
ROLLOVER_EXCLUDE = {
    '日橡胶': True,
    '新加坡铁矿石': True,
    '伦敦银现货': True,
}""",
    tag='新增 ROLLOVER_EXCLUDE')

rep(
"""def sina_dailyk_highlow_range(""",
"""def rollover_suspect_close(bars, close, ps, exclude=False,
                           tol=0.005, min_span=0.002, fix_pct=0.025, watch_pct=0.015):
    \"\"\"v1.15: 【起始价 close】的换月嫌疑判定 —— 覆盖"参考价跨换月线被继承钉住"这一真实机制。

    为什么要补这条（v1.14 的缺口）：
      v1.14 只检查【最新价】是否跑出当段分时表区间，覆盖的是"分时表与快照切合约不同步"的瞬间。
      但真实事故（2026-10-16 美燃油）不是这样：表和新快照**都已经切到新合约**，
      失真的是【起始价】—— 它跨过换月线后被"续接继承"机制钉成了老合约价
      （close=4.834 老合约、last=4.596 新合约、昨结 ps=4.654），于是每轮都不触发。

    close 正常时有三种来源，都不该"既跑出当段表区间、又远离当前合约的昨结算"：
      · 取自当段分时表 → 必在区间内；
      · 特判规则（日胶日K / 铁矿 / 银现货 5 日线）→ 这些品种已在 ROLLOVER_EXCLUDE 里排除；
      · 跨时段继承 → 继承的是【同一合约】的历史价，与昨结算的差就是真实隔夜波动（通常 <1.5%）。
    只有"继承来的老合约价"会同时满足：跑出区间 + 明显远离昨结算。

    双阈值分级（避免把正确的继承值改错）：
      · 偏离 >= 2.5% → 'fix'   自动修正（高置信度，如美燃油案例 3.87%）
      · 偏离 1.5%~2.5% → 'watch' 只记录嫌疑、不动数值（供观察，零风险）
    返回 (级别, 偏离比例, 说明文字)。\"\"\"
    if exclude or not bars or close is None or ps is None or ps <= 0 or len(bars) < 3:
        return None, None, ''
    lo = min(p for _dt, p in bars)
    hi = max(p for _dt, p in bars)
    if hi <= 0 or (hi - lo) / hi < min_span:
        return None, None, ''          # 区间过窄 → 不可靠
    if lo * (1 - tol) <= close <= hi * (1 + tol):
        return None, None, ''          # 起始价就在当段区间内 → 正常
    gap = abs(close - ps) / ps
    if gap >= fix_pct:
        return 'fix', gap, '起始价 %s 跑出分时表区间 [%s, %s] 且偏离昨结 %s 达 %.2f%%' % (
            close, lo, hi, ps, gap * 100)
    if gap >= watch_pct:
        return 'watch', gap, '起始价 %s 跑出分时表区间 [%s, %s]、偏离昨结 %.2f%%（只记录不发动作）' % (
            close, lo, hi, gap * 100)
    return None, None, ''

def sina_dailyk_highlow_range(""",
    tag='新增 rollover_suspect_close')

rep(
"""        code = row.get('code')
        if not code or row.get('close') is None:
            continue
        # v1.14：判据改为"分时表同段一致性"（不再看日K，也不再依赖 2% 阈值）
        sym = code[3:] if code.startswith('hf_') else code
        suspect, why = rollover_suspect(ml_by_sym.get(sym) or [], row.get('last'), now)
        if not suspect and row['name'] in ROLLOVER_OVERRIDE:
            suspect, why = True, '手工覆盖表指定'
        ps = (sina_map.get(code) or {}).get('prev_settle')
        if not suspect or not ps or ps <= 0:
            continue
        close = row['close']""",
"""        code = row.get('code')
        if not code or row.get('close') is None:
            continue
        sym = code[3:] if code.startswith('hf_') else code
        bars_row = ml_by_sym.get(sym) or []
        ps = (sina_map.get(code) or {}).get('prev_settle')

        # 通道1（v1.14）：最新价跑出当段分时表区间 → 两源切合约不同步
        suspect, why = rollover_suspect(bars_row, row.get('last'), now)
        level = 'fix' if suspect else None

        # 通道2（v1.15）：起始价跑出区间 + 明显偏离昨结 → 跨换月线被继承钉住
        if level != 'fix':
            lv2, gap2, why2 = rollover_suspect_close(
                bars_row, row.get('close'), ps,
                exclude=bool(ROLLOVER_EXCLUDE.get(row['name'])))
            if lv2:
                level, why = lv2, why2
                row['roll_gap'] = round(gap2 * 100, 2)

        # 手工覆盖
        if not level and row['name'] in ROLLOVER_OVERRIDE:
            level, why = 'fix', '手工覆盖表指定'

        if level == 'watch':
            row['roll'] = 'watch'      # 只留痕，不动数值（零风险观察档）
            month_watch += 1
            print('换月观察: %s（%s）' % (row['name'], why))
            continue
        if level != 'fix':
            continue
        if not ps or ps <= 0:
            continue
        close = row['close']""",
    tag='换月检测双通道')

rep(
"""    month_fix = 0
    for row in rows:
        code = row.get('code')
        if not code or row.get('close') is None:
            continue
        sym = code[3:] if code.startswith('hf_') else code
        bars_row = ml_by_sym.get(sym) or []""",
"""    month_fix = 0
    month_watch = 0
    for row in rows:
        code = row.get('code')
        if not code or row.get('close') is None:
            continue
        sym = code[3:] if code.startswith('hf_') else code
        bars_row = ml_by_sym.get(sym) or []""",
    tag='换月计数器')

rep(
"""        row['gap_min'] = None
        if row['last'] is not None:""",
"""        row['gap_min'] = None
        row['roll'] = 'fix'
        if row['last'] is not None:""",
    tag='换月行打 roll 标')

rep(
"""    if month_fix:
        print(f'换月检测: {month_fix} 行已修正')
    else:
        print('换月检测: 未发现疑似换月失真')""",
"""    if month_fix or month_watch:
        print(f'换月检测: {month_fix} 行已修正, {month_watch} 行只记录')
    else:
        print('换月检测: 未发现疑似换月失真')""",
    tag='换月汇总打印')

# ---------- 22. v1.15.1：换月标注只显示「换月」（用户要求，不写"昨结"） ----------
rep(
"""        row['ref'] = '昨结 换月'""",
"""        row['ref'] = '换月'   # v1.15.1: 用户要求——「起始时间」列只显示"换月"两个字""",
    tag='换月标注改为「换月」')

rep(
"""      · 修正动作不变：参考价 := 昨结算；起始时间列标「昨结 换月」。""",
"""      · 修正动作不变：参考价 := 昨结算；起始时间列标「换月」。""",
    tag='注释同步（换月标注）')

# ---------- 校验 ----------
left = src.count('close, st = ref_price_from_bars(')
if left:
    print('!! 仍有 %d 处旧调用未改' % left)
    sys.exit(3)
if 'ref_actual' not in src or 'gap_min' not in src:
    print('!! 字段未写入')
    sys.exit(4)

os.makedirs(os.path.dirname(DST), exist_ok=True)
io.open(DST, 'w', encoding='utf-8', newline='\n').write(src)
py_compile.compile(DST, doraise=True)

print('已生成: %s' % DST)
print('补丁数: %d' % len(applied))
for a in applied:
    print('  - ' + a)
print('语法编译: OK')
