# -*- coding: utf-8 -*-
"""构建 index.html v2.10（对 网页版\\index.html 精确打补丁）。

三件事：
  ① 起始时间说真话 —— 「起始时间」列显示该行【实际取价笔】的时刻（云端新增 ref_actual 字段），
     与档位节点不同时打 ※ 并在悬停显示细节；没有新字段时（云端还没换脚本）行为与 v2.9 完全一致。
  ② 最新价来源标记 —— 用 TradingView 延时兜底 / 美燃油 fuHO 延时源的行，涨跌幅后标「延」。
  ③ 前端翻表补档 —— 云端档位落后（Actions 排队）时，页面自己用 JSONP 拉新浪分时表现算基准价，
     标「即时」；data.json 一更新自动切回云端值。仅白天三档（10:15/11:30/15:00），夜盘不补。

原则：除上述增量外，与 v2.9 逐字节一致；任何一处补丁未命中 → 报错退出，不产出半成品。
"""
import io, os, py_compile, re, sys

ROOT = r'E:\DwnlData\外盘涨跌统计'
SRC = os.path.join(ROOT, '网页版', 'index.html')
DST = os.path.join(ROOT, '海鸥工作区', '交付', 'index.html')
JS_SRC = os.path.join(ROOT, '海鸥工作区', '构建', 'v210_模块.js')

src = io.open(SRC, encoding='utf-8').read()
orig = src
applied = []


def rep(old, new, expect=1, tag=''):
    global src
    n = src.count(old)
    if n != expect:
        print('!! 补丁未命中(%d!=%d) [%s]' % (n, expect, tag))
        print('   >>> ' + old[:140].replace('\n', '\\n'))
        sys.exit(2)
    src = src.replace(old, new)
    applied.append(tag)


# ---------- 1. 头部版本注释 ----------
rep(
"""   外盘涨跌统计 · 前端 v2.9（2026-10-16）
   v2.9：""",
"""   外盘涨跌统计 · 前端 v2.10（2026-10-16 · 海鸥工作区）
   v2.10：三处增量（其余与 v2.9 一致）：
     ① 「起始时间」说真话：显示该行【实际取到那一笔价】的时刻（云端 data.json 新增 ref_actual /
        gap_min 字段）。此前显示的是档位节点（如 11:30），但稀疏品种实际取的是更早的最后一笔
        （美豆粕 14:46、日橡胶 14:11…），拿去分钟图上反查会对不上。只显示真实时刻，不加小标。
        兼容：云端未换脚本时没有这两个字段 → 行为与 v2.9 完全相同。
     ② 最新价来源标记：走 TradingView 延时兜底、或美燃油（腾讯只有延时源 fuHO）的行，
        涨跌幅后标「延」，避免把 10-20 分钟的延时数据当成实时看。
     ③ 前端翻表补档：起始价从来不是"守着节点抓"的，而是事后从当日分时表里挑 ≤ 节点的那一笔
        （云端 fetch.py 就是这么干的）。所以时段未切换时，页面自己用 JSONP（script 注入，
        无需 CORS / 无需中转）拉同一张表，就能算出与云端逐位一致的基准价。
        用途：GitHub Actions 排队 26-36 分钟，页面在 10:30 开盘前可能还停在旧档 ——
        此时前端自己补上（值同源同口径、与云端逐位一致，所以不加任何标记）；
        data.json 一更新就自动切回云端值（数字一致）。
        仅白天三档（10:15 / 11:30 / 15:00）补；夜盘各组节点不同，不补。
   v2.9：""",
    tag='头部版本注释')

# ---------- 2. CSS 增加标记样式 ----------
rep(
"""  .tip{margin-top:4px; text-align:center; font-size:11px; color:#aab; contain:inline-size; width:100%;}""",
"""  .tip{margin-top:4px; text-align:center; font-size:11px; color:#aab; contain:inline-size; width:100%;}
  /* v2.10: 行内小标记（即时 / 实取 / 延时来源） */
  .mk{font-size:10px; line-height:1; padding:1px 3px; border-radius:3px; margin-left:3px; display:inline-block;}
  .mk-live{background:#E8F5E9; color:#0B8043; border:1px solid #A5D6A7;}
  .mk-lag{background:#FFF8E1; color:#8D6E00; border:1px solid #FFE082;}
  .mk-src{background:#FBE9E7; color:#C0392B; border:1px solid #F7C1BB;}""",
    tag='CSS 标记样式')

# ---------- 3. 页脚说明补一行 ----------
rep(
"""  <div class="tip">双绿灯，全部品种均为实时；红灯异常时，部分品种降级为延时</div>""",
"""  <div class="tip">双绿灯，全部品种均为实时；红灯异常时，部分品种降级为延时</div>
  <div class="tip" id="tipMark">「起始时间」= 该品种实际取到那一笔价的时刻（与档位节点不同时打 ※，悬停看细节）·「即时」= 云端尚未更新，本页已自行补算 ·「延」= 该行用的是延时源</div>""",
    tag='页脚说明')

# ---------- 4. 插入 v2.10 主模块（放在状态声明之前） ----------
rep(
"""/* ---------- 状态 ---------- */""",
io.open(JS_SRC, encoding='utf-8').read() + """/* ---------- 状态 ---------- */""",
    tag='插入 v2.10 模块')

# ---------- 5. rowHtml 支持标记 ----------
rep(
"""function rowHtml(r){
  var nm = SHORT_NAMES[r.name] || r.name;
  var flag = r.flag ? ' ※' : '';
  return '<td class="name">'+nm+'</td>'+
    '<td class="'+(r.close==null?'miss':'')+'">'+fmt2(r.close)+'</td>'+
    '<td class="'+(r.last==null?'miss':'')+'">'+fmt2(r.last)+'</td>'+
    '<td class="'+cls(r.chg)+'">'+fmt2(r.chg,true)+'</td>'+
    '<td class="'+cls(r.pct)+'">'+fmtPct(r.pct)+flag+'</td>'+
    '<td class="ref">'+(r.ref||'—')+'</td>';
}""",
"""function rowHtml(r){
  var nm = SHORT_NAMES[r.name] || r.name;
  var flag = r.flag ? ' ※' : '';
  var src = r.src ? '<span class="mk mk-src" title="该行最新价来自延时数据源">'+r.src+'</span>' : '';
  var mark = '';
  if(r.mark === '即时'){
    mark = '<span class="mk mk-live" title="云端档位尚未更新，此基准价由本页即时从分时表现算">即时</span>';
  }else if(r.mark){
    mark = '<span class="mk mk-lag" title="'+(r.markTip||'')+'">'+r.mark+'</span>';
  }
  var refCell = '<td class="ref"'+(r.refTip?' title="'+r.refTip+'"':'')+'>'+(r.ref||'—')+mark+'</td>';
  return '<td class="name">'+nm+'</td>'+
    '<td class="'+(r.close==null?'miss':'')+'">'+fmt2(r.close)+'</td>'+
    '<td class="'+(r.last==null?'miss':'')+'">'+fmt2(r.last)+'</td>'+
    '<td class="'+cls(r.chg)+'">'+fmt2(r.chg,true)+'</td>'+
    '<td class="'+cls(r.pct)+'">'+fmtPct(r.pct)+flag+src+'</td>'+
    refCell;
}""",
    tag='rowHtml 支持标记')

# ---------- 6. render 循环体改用 baseQuoteOf ----------
rep(
"""    var q = quoteOf(r);                          /* 腾讯实时 或 TradingView 延时 */
    var last = (q && q.last!=null) ? q.last : r.last;
    var chg = r.chg, pct = r.pct;
    if(q && r.close!=null && last!=null && r.close>0){
      chg = last - r.close;                      /* 前端即时重算：最新价 - 起始价 */
      pct = chg / r.close * 100;
    }
    var tr = document.createElement('tr');
    tr.innerHTML = rowHtml({name:r.name, close:r.close, last:last, chg:chg, pct:pct, flag:r.flag, ref:r.ref});
    tb.appendChild(tr);""",
"""    var q = quoteOf(r);                          /* 腾讯实时 或 TradingView 延时 */
    var last = (q && q.last!=null) ? q.last : r.last;
    /* v2.10: 基准价 = 云端值（默认）或本页即时现算值（云端档位落后时） */
    var bq = baseQuoteOf(r);
    var chg = r.chg, pct = r.pct;
    if(q && bq.close!=null && last!=null && bq.close>0){
      chg = last - bq.close;                     /* 前端即时重算：最新价 - 起始价 */
      pct = chg / bq.close * 100;
    }
    var tr = document.createElement('tr');
    tr.innerHTML = rowHtml({name:r.name, close:bq.close, last:last, chg:chg, pct:pct,
                            flag:r.flag, ref:bq.ref, mark:bq.mark, markTip:bq.markTip,
                            refTip:bq.refTip, src:srcTag(r, q)});
    tb.appendChild(tr);""",
    tag='render 循环体')

# ---------- 7. 页脚补充补档提示 ----------
rep(
"""  document.getElementById('refDesc').textContent = d.ref_desc || '';""",
"""  document.getElementById('refDesc').textContent = (d.ref_desc || '') + refLiveNote(d);""",
    tag='页脚补档提示')

# ---------- 8. boot 挂上补档循环 ----------
rep(
"""  sseTick();                       /* ⑨ 上证指数临时行：窗口内立即检查一次（窗口外零开销） */
  scheduleSse();                   /* ⑩ 之后每 15 秒检查（含窗口进出判定） */
}""",
"""  sseTick();                       /* ⑨ 上证指数临时行：窗口内立即检查一次（窗口外零开销） */
  scheduleSse();                   /* ⑩ 之后每 15 秒检查（含窗口进出判定） */
  probeTick();                     /* ⑪ v2.10: 云端档位落后时，本页自己翻分时表补档 */
  scheduleProbe();                 /* ⑫ v2.10: 之后每 60 秒检查一次是否需要补档 */
}""",
    tag='boot 挂补档')

# ---------- 9. 切回前台时也检查补档 ----------
rep(
"""    sseTick();
    scheduleFast();
    scheduleSina();
    scheduleGlobal();
    scheduleSse();""",
"""    sseTick();
    probeTick();
    scheduleFast();
    scheduleSina();
    scheduleGlobal();
    scheduleSse();
    scheduleProbe();""",
    tag='visibilitychange 挂补档')

# ---------- 10. 切后台时停掉补档定时 ----------
rep(
"""    clearTimeout(sseTimer); sseTimer = null;
  }else{""",
"""    clearTimeout(sseTimer); sseTimer = null;
    clearTimeout(probeTimer); probeTimer = null;
  }else{""",
    tag='后台停补档定时')

# ---------- 11. v2.12：品种改名（与 fetch.py 同步：美豆粕/美豆油/美棉花/美天然气） ----------
rep(
"""  '美燃油':'hf_HO','美国天然气':'hf_NG',
  '美大豆':'hf_S','美黄豆粉':'hf_SM','美黄豆油':'hf_BO',
  '美原糖':'hf_RS','美国棉花':'hf_CT','马棕油':'hf_FCPO',""",
"""  '美燃油':'hf_HO','美天然气':'hf_NG',
  '美大豆':'hf_S','美豆粕':'hf_SM','美豆油':'hf_BO',
  '美原糖':'hf_RS','美棉花':'hf_CT','马棕油':'hf_FCPO',""",
    tag='改名（前端匹配表 NAME2CODE）')

rep(
"""  'hf_CT':   'ICEUS:CT1!',    /* 美国棉花   ~10 分钟 */""",
"""  'hf_CT':   'ICEUS:CT1!',    /* 美棉花   ~10 分钟 */""",
    tag='改名（TV 符号注释）')

# ---------- 12. v2.13：取消 ※ 小标（用户要求：有「起始时间」列就够，不需要额外提示） ----------
rep(
"""  var flag = r.flag ? ' ※' : '';""",
"""  var flag = '';   /* v2.13: 取消 ※ 小标 ——「起始时间」列已显示真实取价笔，用户要求去掉 */""",
    tag='取消 flag ※ 小标')

# ---------- 校验 ----------
for must in ['baseQuoteOf', 'probeTick', 'expectMode', 'jsonpMinline', 'PROBE_MINLINE', 'refLiveNote', 'srcTag']:
    if must not in src:
        print('!! 缺少关键符号: ' + must)
        sys.exit(3)
if 'function rowHtml(r){' not in src:
    print('!! rowHtml 异常')
    sys.exit(4)

os.makedirs(os.path.dirname(DST), exist_ok=True)
io.open(DST, 'w', encoding='utf-8', newline='\n').write(src)

print('已生成: %s' % DST)
print('补丁数: %d' % len(applied))
for a in applied:
    print('  - ' + a)
print('字节: %d -> %d' % (len(orig.encode('utf-8')), len(src.encode('utf-8'))))
