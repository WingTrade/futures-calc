# -*- coding: utf-8 -*-
"""用 pip download（只下载，不解压）拿到 wheel，再用 zipfile 解压到工作区。

背景：本环境 pip install 在"解压 wheel"一步被拒；而 pip download 只写文件、不进入解包流程。
"""
import os, subprocess, sys, zipfile

PY = r'C:\Users\wing\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
WHL = os.path.join(WS, '.whl')
TARGET = os.path.join(WS, '.pytools')
os.makedirs(WHL, exist_ok=True)
os.makedirs(TARGET, exist_ok=True)

env = dict(os.environ)
env['TEMP'] = env['TMP'] = env['TMPDIR'] = os.path.join(WS, '.tmppip')
os.makedirs(env['TEMP'], exist_ok=True)

print('--- pip download（只下载）---')
p = subprocess.run([PY, '-m', 'pip', 'download', '--dest', WHL,
                    '-i', 'https://pypi.tuna.tsinghua.edu.cn/simple',
                    '--trusted-host', 'pypi.tuna.tsinghua.edu.cn',
                    '--disable-pip-version-check', '--no-cache-dir',
                    'pyinstaller'], capture_output=True, env=env)
out = (p.stdout + p.stderr).decode('utf-8', 'replace')
for line in out.splitlines():
    if any(k in line for k in ('Saved', 'Downloading', 'ERROR', 'error', 'denied', 'Successfully')):
        print('   ' + line[:150])

whls = [f for f in os.listdir(WHL) if f.endswith('.whl')]
print('\n  下载到 %d 个 wheel:' % len(whls))
for f in sorted(whls):
    print('   ', f)

print('\n--- 手动解压到 .pytools ---')
n = 0
for f in whls:
    try:
        with zipfile.ZipFile(os.path.join(WHL, f)) as z:
            z.extractall(TARGET)
        n += 1
    except Exception as e:
        print('   解压失败 %s: %s' % (f, str(e)[:70]))
print('   解压完成 %d/%d' % (n, len(whls)))

sys.path.insert(0, TARGET)
try:
    import PyInstaller
    print('\nPyInstaller 就绪，版本:', PyInstaller.__version__)
    print('OK')
except Exception as e:
    print('\n仍不可用:', type(e).__name__, str(e)[:120])
    sys.exit(1)
