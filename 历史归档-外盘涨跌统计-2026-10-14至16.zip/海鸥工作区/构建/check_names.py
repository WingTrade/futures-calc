# -*- coding: utf-8 -*-
"""看新抓取的 data.json：品种名是否已改好、有没有"缺"的行。"""
import io, json, os

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
d = json.load(io.open(os.path.join(WS, '验证', '新版', 'data.json'), encoding='utf-8'))
print('mode = %s   generated_at = %s   行数 = %d' % (d.get('mode'), d.get('generated_at'), len(d['rows'])))
print()
print('%-14s %-12s %-16s %-14s %s' % ('品种名', 'close', 'ref', 'ref_actual', 'note'))
print('-' * 78)
for r in d['rows']:
    print('%-14s %-12s %-16s %-14s %s' % (
        r['name'], r.get('close'), r.get('ref'), r.get('ref_actual'), r.get('note') or ''))
print()
missing = [r['name'] for r in d['rows'] if r.get('pct') is None]
print('没有涨跌幅的行：', missing or '无')
old = [r['name'] for r in d['rows'] if r['name'] in ('美黄豆粉', '美黄豆油', '美国棉花', '美国天然气')]
print('仍是旧名的行：', old or '无')
