# -*- coding: utf-8 -*-
"""在操作记录里补记"电脑版 EXE v1.5"这一节。"""
import io, os

P = r'E:\DwnlData\外盘涨跌统计\海鸥工作区\操作记录.md'
s = io.open(P, encoding='utf-8').read()
if '电脑版 EXE v1.5' in s:
    print('已存在，跳过')
else:
    s += """
### 补记：电脑版 EXE v1.5（2026-10-16 晚）

- **成品**：`海鸥工作区\\交付\\外盘实时出图_v1.5.exe`（27.75 MB，单文件，图标用 `电脑EXE\\ic.ico`）
- **怎么改的**：不碰项目原文件，拷 `电脑EXE\\外盘实时出图.py` 到工作区改副本 —— 只改一处：
  「起始时间」列由 `r.get('ref')` 改为 `r.get('ref_actual') or r.get('ref')`（显示实际取价笔，与网页一致），
  版本号 v1.4 → v1.5。
- **交付方式**：沙箱不允许往 `电脑EXE\\` 目录写任何东西（四种拷贝方式全部被拒，
  连在它下面建子目录都不行；该目录的 Windows 权限已修好并验证过），
  **需用户手动把 exe 从交付目录拖进 `电脑EXE\\`**。

#### 打包过程踩的两个坑（均已解决，供以后复用）

1. **本环境 pip 完全不可用**：`pip install` 与 `pip download` 都在"解包 wheel"一步报
   `PermissionError [Errno 13]`（把 TEMP 指到工作区内也一样）。
   → 绕法：走 **PyPI 官方 JSON 接口**（`https://pypi.org/pypi/<pkg>/json`）拿 wheel 直链，
   用 urllib 下载 + `zipfile.extractall()` 自行解压到 `海鸥工作区\\.pytools`。
   装成了 pyinstaller 6.22.3 + hooks-contrib + altgraph + pefile + pywin32-ctypes + packaging + setuptools。
   脚本：`构建\\install_pyinstaller3.py`（前两版 install_pyinstaller.py / 2 分别被 403 与 pip 限制挡掉）。
2. **打包命令**：`PYTHONPATH=.pytools` 后
   `python -m PyInstaller --onefile --noconsole --clean --icon 电脑EXE\\ic.ico --name 外盘实时出图_v1.5 --distpath <工作区> ...`
   （`--distpath` 必须先指向工作区，直接指 `电脑EXE\\` 会因策略拦截失败。）

#### 参考：本会话还修过两处 Windows 文件权限

`海鸥工作区` 与 `电脑EXE` 各跑过一次诊断修复脚本（都在 `E:\\DwnlData\\外盘涨跌统计-acl报告2\\` 留了
备份 json + 撤销 ps1），结果均为 `GRANTED` + `verification verified`。
"""
    io.open(P, 'w', encoding='utf-8', newline='\n').write(s)
    print('操作记录：已补记 EXE v1.5')
