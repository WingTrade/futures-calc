# -*- coding: utf-8 -*-
"""把 exe 拷到 电脑EXE 目录：多种方式逐个试，找出这个环境里能通的那条。"""
import os, shutil, subprocess, sys

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
SRC = os.path.join(WS, '构建', 'exe_v15', 'dist', '外盘实时出图_v1.5.exe')
DIR = r'E:\DwnlData\外盘涨跌统计\电脑EXE'
DST = os.path.join(DIR, '外盘实时出图_v1.5.exe')

print('源文件:', os.path.exists(SRC), os.path.getsize(SRC) // 1024, 'KB')
print('目标目录存在:', os.path.isdir(DIR))
print('目标目录可写(当前用户):', os.access(DIR, os.W_OK))

# 方式 1：普通 copy
try:
    shutil.copyfile(SRC, DST)
    print('方式1 shutil.copyfile: 成功', os.path.getsize(DST) // 1024, 'KB')
    sys.exit(0)
except Exception as e:
    print('方式1 shutil.copyfile: 失败', type(e).__name__, str(e)[:90])

# 方式 2：先建空文件再写内容
try:
    with open(SRC, 'rb') as f:
        data = f.read()
    with open(DST, 'wb') as f:
        f.write(data)
    print('方式2 手工写入: 成功', os.path.getsize(DST) // 1024, 'KB')
    sys.exit(0)
except Exception as e:
    print('方式2 手工写入: 失败', type(e).__name__, str(e)[:90])

# 方式 3：写到子目录再移
try:
    sub = os.path.join(DIR, 'v15')
    os.makedirs(sub, exist_ok=True)
    tmp = os.path.join(sub, 'a.exe')
    shutil.copyfile(SRC, tmp)
    os.replace(tmp, DST)
    print('方式3 子目录+移动: 成功', os.path.getsize(DST) // 1024, 'KB')
    sys.exit(0)
except Exception as e:
    print('方式3 子目录+移动: 失败', type(e).__name__, str(e)[:90])

# 方式 4：cmd copy
r = subprocess.run(['cmd', '/c', 'copy', '/Y', SRC, DST], capture_output=True)
print('方式4 cmd copy: rc=%s %s' % (r.returncode, r.stdout.decode('gbk', 'replace').strip()[:120]))
if os.path.exists(DST):
    sys.exit(0)
sys.exit(1)
