# -*- coding: utf-8 -*-
"""生成三个本地预览目录（都用交付版 v2.11 的 index.html）：
  预览\\正常      —— 正常形态：看「起始时间」实际取价笔 + ※
  预览\\补档演示  —— data.json 改成"云端迟到"，看「即时」补档
  预览\\接管演示  —— 把中转地址改成死地址，模拟新浪通道故障，看「分时」自动接管
数据用 验证\\新版\\data.json（真实抓取结果，带 ref_actual / gap_min 新字段）。
"""
import io, json, os

WS = r'E:\DwnlData\外盘涨跌统计\海鸥工作区'
PAGE = io.open(os.path.join(WS, '交付', 'index.html'), encoding='utf-8').read()
DATA = json.load(io.open(os.path.join(WS, '验证', '新版', 'data.json'), encoding='utf-8'))

DEAD_PROXY = "var SINA_PROXIES = [\n  'http://127.0.0.1:9/?list=',\n  'http://127.0.0.1:9/?list='\n];"


def write_dir(name, page, data, note=None):
    d = os.path.join(WS, '预览', name)
    os.makedirs(d, exist_ok=True)
    io.open(os.path.join(d, 'index.html'), 'w', encoding='utf-8', newline='\n').write(page)
    io.open(os.path.join(d, 'data.json'), 'w', encoding='utf-8').write(
        json.dumps(data, ensure_ascii=False, indent=1))
    if note:
        io.open(os.path.join(d, '说明.txt'), 'w', encoding='utf-8').write(note)
    print('  %-10s %s' % (name, d))


print('生成预览：')

# ① 正常
write_dir('正常', PAGE, DATA,
          '正常预览：看「起始时间」列显示的是实际取到那一笔价的时刻（稀疏品种带 ※）。\n'
          '这一份 data.json 是真实抓取结果，带 ref_actual / gap_min 新字段。\n')

# ② 补档演示：把 data.json 改成"云端迟到"
d2 = json.loads(json.dumps(DATA))
d2['mode'] = 'm1130'
d2['title'] = '对比11:30涨跌统计'
d2['mode_desc'] = '隔夜'
d2['ref_desc'] = '参考: 今日 11:30'
d2['generated_at'] = '2026-10-16 13:01'
d2['demo_note'] = '演示用：故意改成"云端迟到"，触发前端翻表补档'
write_dir('补档演示', PAGE, d2,
          '补档演示：data.json 被改成"云端还没更新到当前档"的样子。\n'
          '页面会自己翻新浪分时表，把这一档的基准价补上，相关行出现绿色「即时」。\n')

# ③ 接管演示：中转地址改成死地址
if 'var SINA_PROXIES = [' not in PAGE:
    raise SystemExit('!! 未找到 SINA_PROXIES')
i = PAGE.index('var SINA_PROXIES = [')
j = PAGE.index('];', i) + 2
page3 = PAGE[:i] + DEAD_PROXY + PAGE[j:]
write_dir('接管演示', page3, DATA,
          '接管演示：把两条 Cloudflare 中转地址改成了必失败的地址，模拟"新浪快照通道挂掉"。\n'
          '预期表现：\n'
          '  1) 页面右上「新浪」灯变红；\n'
          '  2) 约 15 秒后，原糖/棉花/马棕油/铁矿/日橡胶/美燃油 六行自动分时表接管，\n'
          '     行尾出现「分时」标记（如该品种此刻无新成交，会直接标出时刻，如「分时 14:11」）；\n'
          '  3) 其余品种不受影响（走腾讯直连，照常实时）。\n'
          '这就是通道故障时的真实兜底表现 —— 数据不会断。\n')

print('完成')
