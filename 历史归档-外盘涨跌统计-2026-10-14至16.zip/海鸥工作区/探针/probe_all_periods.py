# -*- coding: utf-8 -*-
"""逐品种盘查：交易时段 vs 我们的 6 个基准节点（10:15 / 11:30 / 15:00 / 23:00 / 01:00 / 02:30）。

采集：
  ① 分时表：当前时段的首根时刻（≈开盘）、末根时刻（最后成交）、点数、表标注日期
  ② 日K：最后 3 根（date / open / high / low / close）
  ③ 用"末根时刻 vs 现在"判断此刻是否还在交易

用途：找出"在某个节点时刻其实已收盘"的品种 —— 它们的基准价应当用当日收盘价（日K），
      而不是分时表里更早的某一笔（日橡胶就是这类，14:50 收盘、分时最后成交只到 14:11）。
显式禁用代理（国内直连环境）。
"""
import json, re, ssl, time, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))

ML = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
      'GlobalFuturesService.getGlobalFuturesMinLine?symbol={sym}')
DK = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/'
      'GlobalFuturesService.getGlobalFuturesDailyKLine?symbol={sym}')

# 品种 → 新浪 symbol（与 fetch.py 的 hf_ 代码对应）
SYMS = [
    ('WTI原油', 'CL'), ('布伦特原油', 'OIL'), ('美黄金', 'GC'), ('美白银', 'SI'), ('伦敦银现货', 'XAG'),
    ('伦铝', 'AHD'), ('伦锌', 'ZSD'), ('伦镍', 'NID'), ('伦锡', 'SND'), ('美铜', 'HG'),
    ('伦铜', 'CAD'), ('伦铅', 'PBD'), ('美燃油', 'HO'), ('美国天然气', 'NG'), ('美大豆', 'S'),
    ('美黄豆粉', 'SM'), ('美黄豆油', 'BO'), ('美原糖', 'RS'), ('美国棉花', 'CT'), ('马棕油', 'FCPO'),
    ('新加坡铁矿石', 'FEF'), ('日橡胶', 'RSS3'),
]


def get(url, timeout=25):
    r = NOPROXY.open(urllib.request.Request(url, headers={'User-Agent': UA}), timeout=timeout)
    return r.read().decode('utf-8', errors='replace')


def minline(sym):
    try:
        o = json.loads(get(ML.format(sym=sym)))
        arr = ((o.get('result') or {}).get('data') or {}).get('minLine_1d') or []
        if not arr:
            return None, None, 0, None
        day = arr[0][0] if isinstance(arr[0], list) else None
        first = last = None
        for i, e in enumerate(arr):
            if i == 0 or not isinstance(e, list) or len(e) < 2:
                continue
            tk = str(e[0])
            if re.match(r'^\d{2}:\d{2}$', tk):
                if first is None:
                    first = tk
                last = tk
        return first, last, len(arr), day
    except Exception:
        return None, None, 0, None


def dailyk(sym):
    try:
        t = get(DK.format(sym=sym))
        m = re.search(r'\((\[.*\])\)', t, re.S)
        return json.loads(m.group(1)) if m else []
    except Exception:
        return []


def to_min(hhmm):
    if not hhmm or not re.match(r'^\d{2}:\d{2}$', str(hhmm)):
        return None
    return int(hhmm[:2]) * 60 + int(hhmm[3:5])


now = time.localtime()
now_min = now.tm_hour * 60 + now.tm_min
today = time.strftime('%Y-%m-%d', now)

print('=' * 132)
print('逐品种盘查 · 本地时间 %s · 我们的节点：10:15 / 11:30 / 15:00 / 23:00 / 01:00 / 02:30' % time.strftime('%Y-%m-%d %H:%M:%S', now))
print('=' * 132)
print('%-12s %-8s %-8s %-7s %-9s %-30s %-12s %s' % ('品种', '表中首根', '末根', '点数', '表标注日', '日K今天 O/H/L/C', '日K前收', '此刻是否在交易'))
print('-' * 132)

rows = []
for name, sym in SYMS:
    f, l, n, day = minline(sym)
    dk = dailyk(sym)
    bar_today = None
    prev_close = None
    for k in reversed(dk):
        if k.get('date') == today and bar_today is None:
            bar_today = k
        elif bar_today is not None and prev_close is None:
            prev_close = k.get('close')
            break
    if bar_today is None and dk:
        prev_close = dk[-1].get('close')

    lm = to_min(l)
    age = None
    if lm is not None:
        age = now_min - lm
        if age < -5:
            age += 1440
    live = '在交易' if (age is not None and age <= 10) else ('已收盘(最后成交 %s)' % l if l else '无数据')

    ohlt = '-'
    if bar_today:
        ohlt = '%s/%s/%s/%s' % (bar_today.get('open'), bar_today.get('high'), bar_today.get('low'), bar_today.get('close'))

    print('%-12s %-8s %-8s %-7s %-9s %-30s %-12s %s' % (
        name, f or '-', l or '-', n, day or '-', ohlt, prev_close or '-', live))
    rows.append({'name': name, 'sym': sym, 'first': f, 'last': l, 'n': n, 'day': day,
                 'bar_today': bar_today, 'prev_close': prev_close, 'age': age})
    time.sleep(0.35)

print()
print('=' * 132)
print('关键判断：哪些品种在 15:00 可能已收盘（→ 基准应改用当日收盘价）')
print('=' * 132)
for r in rows:
    lm = to_min(r['last'])
    if lm is None:
        continue
    # 若该品种最后成交时刻早于 15:00（且表标注日=今天），说明它 15:00 时已无成交
    if lm < 15 * 60:
        print('  %-12s 最后成交 %s（早于 15:00）→ 15:00 档的基准实际取自该笔；'
              '日K今天 close=%s 是否更权威需判断' % (
                  r['name'], r['last'], (r['bar_today'] or {}).get('close', '-')))
print()
print('（注：此刻"末根早于 15:00"也可能是该品种已进入新时段/收盘，需结合它自己的交易时段判断）')
