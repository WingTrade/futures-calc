# -*- coding: utf-8 -*-
"""探针 2：逐品种检查新浪分时接口的覆盖与时段边界，判断「浏览器现算基准价」可行性。
只读、低频（每品种 1 次请求）。
"""
import json, re, sys, time, urllib.request, urllib.error

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
OPEN = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
        'GlobalFuturesService.getGlobalFuturesMinLine?symbol={sym}&callback=var%20d=')
FIVE = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
        'GlobalFuturesService.getGlobalFutures5MLine?symbol={sym}')

# 22 个商品（网页行的 code 去掉 hf_ 前缀）；美股 3 行另走日K，不在本次范围
SYMS = ['CL', 'OIL', 'GC', 'SI', 'XAG', 'AHD', 'ZSD', 'NID', 'SND', 'HG',
        'CAD', 'PBD', 'HO', 'NG', 'S', 'SM', 'BO', 'RS', 'CT', 'FCPO', 'FEF', 'RSS3']


def get(url, timeout=20):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', errors='replace')


def points(sym):
    """返回 (日期, [(HH:MM, price)], 首根原始, 末根原始)"""
    txt = get(OPEN.format(sym=sym))
    m = re.search(r'\((\{.*\})\)', txt, re.S)
    if not m:
        return None, [], None, None
    obj = json.loads(m.group(1))
    data = (obj.get('result') or {}).get('data') or {}
    arr = data.get('minLine_1d')
    if not isinstance(arr, list) or not arr:
        return None, [], None, None
    day = arr[0][0] if isinstance(arr[0], list) else None
    out = []
    for i, e in enumerate(arr):
        if not isinstance(e, list) or len(e) < 2:
            continue
        if i == 0:
            continue
        tk = str(e[0])
        if not re.match(r'^\d{2}:\d{2}$', tk):
            continue
        try:
            out.append((tk, float(e[1])))
        except (ValueError, IndexError):
            continue
    return day, out, arr[0][:10], arr[-1][:10]


print('sym    | day        | 首分钟 | 末分钟 | 点数 | 06:00有 | 10:15有 | 15:00有 | 23:00有 | 01:00有 | 02:30有 | 末价')
print('-' * 150)
summary = []
for sym in SYMS:
    try:
        day, pts, first, last = points(sym)
    except Exception as e:
        print(f'{sym:<6} | FAIL {type(e).__name__}: {e}')
        continue
    if day is None:
        print(f'{sym:<6} | 无 minLine_1d 数据')
        summary.append((sym, None))
        continue
    d = dict(pts)

    def has(t):
        return '有' if t in d else '   '
    print(f'{sym:<6} | {day:<10} | {pts[0][0] if pts else "-":<6} | {pts[-1][0] if pts else "-":<6} | '
          f'{len(pts):>4} | {has("06:00"):<7} | {has("10:15"):<7} | {has("15:00"):<7} | '
          f'{has("23:00"):<7} | {has("01:00"):<7} | {has("02:30"):<7} | {pts[-1][1] if pts else "-"}')
    summary.append((sym, (day, pts[0][0] if pts else None, pts[-1][0] if pts else None, len(pts))))
    time.sleep(0.4)

print()
print('== 5MLine 抽查（上海5日线的替代源是否可用）==')
for sym in ('XAG', 'FEF', 'PBD'):
    try:
        txt = get(FIVE.format(sym=sym))
        o = json.loads(txt)
        arr = ((o.get('result') or {}).get('data') or {}).get(sym)
        if isinstance(arr, list):
            days = [x[0][0] if isinstance(x, list) and x and isinstance(x[0], list) else None for x in arr]
            sizes = [len(x) for x in arr if isinstance(x, list)]
            print(f'{sym}: 天数={len(arr)} 日期={days[:3]}...{days[-3:] if days else ""} 每天点数={sizes[:10]}')
        else:
            print(f'{sym}: 无数据 arr={type(arr)}')
    except Exception as e:
        print(f'{sym}: FAIL {type(e).__name__}: {e}')
    time.sleep(0.4)
print('== done ==')
