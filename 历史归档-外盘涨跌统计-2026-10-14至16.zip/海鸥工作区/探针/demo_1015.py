# -*- coding: utf-8 -*-
"""现场演示：从「分时表」里捞出 10:15 那一笔，与你上午 10:37 的云端记录逐行对账。

说明：新浪分时接口每次返回的是【当个交易时段内从开盘到现在的逐分钟价格序列】，
      不是单个即时价。所以「起始价」不需要在 10:15 那一刻守着抓——
      只要时段没切换，之后任意时刻都能回表里查到 10:15 那一笔。
"""
import json, re, ssl, urllib.request

ctx = ssl._create_unverified_context()
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'}
OPEN = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
        'GlobalFuturesService.getGlobalFuturesMinLine?symbol={sym}')
SYM = {'WTI原油': 'CL', '布伦特原油': 'OIL', '美黄金': 'GC', '美白银': 'SI', '伦敦银现货': 'XAG',
       '伦铝': 'AHD', '伦锌': 'ZSD', '伦镍': 'NID', '伦锡': 'SND', '美铜': 'HG', '伦铜': 'CAD',
       '伦铅': 'PBD', '美燃油': 'HO', '美国天然气': 'NG', '美大豆': 'S', '美黄豆粉': 'SM',
       '美黄豆油': 'BO', '美原糖': 'RS', '美国棉花': 'CT', '马棕油': 'FCPO',
       '新加坡铁矿石': 'FEF', '日橡胶': 'RSS3'}
CENT = {'hf_HG'}


def get(u):
    return urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=25, context=ctx).read().decode('utf-8', 'replace')


def table(sym):
    """把分时表拉成 [(HH:MM, 价)]，同时把首根样本留出来给用户看"""
    t = get(OPEN.format(sym=sym))
    s = t.strip().lstrip('﻿')
    if s.startswith('{'):
        o = json.loads(s)
    else:
        m = re.search(r'\(\s*(\{.*\})\s*\)', t, re.S)
        if not m:
            return [], None
        o = json.loads(m.group(1))
    arr = ((o.get('result') or {}).get('data') or {}).get('minLine_1d')
    if not isinstance(arr, list):
        return [], None
    pts = []
    for i, e in enumerate(arr):
        if i == 0 or not isinstance(e, list) or len(e) < 2:
            continue
        tk = str(e[0])
        if not re.match(r'^\d{2}:\d{2}$', tk):
            continue
        try:
            pts.append((tk, float(e[1])))
        except (ValueError, IndexError):
            pass
    return pts, arr


print('=' * 108)
print('第 0 步：先看这张「表」长什么样（以美黄金 GC 为例，只截 10:13~10:17 附近）')
print('=' * 108)
pts, raw = table('GC')
if raw:
    print('  表头第一行（带日期/交易所/开盘）:', raw[0][:6])
    near = [(t, p) for t, p in pts if '10:1' in t]
    print('  10:10~10:19 的逐分钟价:', near[:12])
    print('  表的规模: 共 %d 笔（%s ~ %s）' % (len(pts), pts[0][0], pts[-1][0]))

print()
print('=' * 108)
print('第 1 步：拿你上午 10:37 那份云端记录（10:15 档）当参照')
print('=' * 108)
loc = json.load(open(r'E:\DwnlData\外盘涨跌统计\网页版\data.json', encoding='utf-8'))
print('  本地 data.json: generated_at =', loc.get('generated_at'), '| mode =', loc.get('mode'), '| 起始时间列 =', loc['rows'][0].get('ref'))
remote = {r['name']: r for r in loc['rows']}

print()
print('=' * 108)
print('第 2 步：我现在（下午）重新回表里查 10:15 那一笔 —— 不是倒推，是查表')
print('=' * 108)
print(f'{"品种":<12}{"上午10:37云端记的":>16}{"现在回表查到的":>16}{"表里那一行":>12}{"偏差":>8}   一样吗')
print('-' * 108)
same = diff = none = 0
for name, sym in SYM.items():
    r = remote.get(name)
    if not r or r.get('close') is None:
        continue
    key = str(r.get('ref', ''))[-5:]              # '10:15' 或 '00:59'
    pts, _ = table(sym)
    hit = None
    for t, p in pts:
        if t <= key:
            hit = (t, p)
        else:
            break
    val = hit[1] if hit else None
    if val is not None and r['code'] in CENT:
        val = val / 100.0
    if val is None:
        none += 1
        tag = '表里没有'
    elif abs(val - r['close']) < 1e-6:
        same += 1
        tag = '一模一样'
    else:
        diff += 1
        tag = '不一样'
    hh = key[:2]
    gap = (int(key[:2]) * 60 + int(key[3:5])) - (int(hit[0][:2]) * 60 + int(hit[0][3:5])) if hit else None
    print(f'{name:<12}{r["close"]:>16.4f}{(val if val is not None else float("nan")):>16.4f}'
          f'{(hit[0] if hit else "-"):>12}{(str(gap) + " 分" if gap is not None else "-"):>8}   {tag}')

print()
print(f'统计：一模一样 {same} 行，不一样 {diff} 行，表里查不到 {none} 行')
print()
print('结论：云端 fetch.py 干的就是这件事——拉这张表，挑 ≤ 10:15 的最后一笔。')
print('      我在浏览器/本机用同一个接口、同一个挑法，所以数字能逐位对上。')
print('      区别只是「谁去拉」——云端定时拉，还是你打开页面时拉。')
