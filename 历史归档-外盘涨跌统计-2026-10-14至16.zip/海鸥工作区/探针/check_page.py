# -*- coding: utf-8 -*-
"""体检页静态自检：抽出 <script> 供 node --check，并核对关键实现是否齐全。"""
import io, os, re, sys, tempfile

path = sys.argv[1] if len(sys.argv) > 1 else r'E:\DwnlData\外盘涨跌统计\诊断页\外盘体检.html'
s = open(path, encoding='utf-8').read()
blocks = re.findall(r'<script>(.*?)</script>', s, re.S)
out = os.path.join(tempfile.gettempdir(), 'tijian_extract.js')
with io.open(out, 'w', encoding='utf-8') as f:
    f.write('\n'.join(blocks))
print('script blocks =', len(blocks), ' js bytes =', sum(len(b) for b in blocks))
print('extracted ->', out)
keys = ['jsonpMinline', 'buildPoints', 'refTarget', 'pick(', 'expectMode', 'minLine_1d',
        'sina-hq.pages.dev', 'forexfutures', 'qt.gtimg.cn', 'scanner.tradingview.com',
        'ifzq.gtimg.cn', 'Access-Control', 'hg_HG']
for k in keys:
    print(('  OK   ' if k in s else '  MISS '), k)
