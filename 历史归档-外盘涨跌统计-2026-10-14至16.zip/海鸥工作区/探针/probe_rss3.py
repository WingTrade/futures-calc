# -*- coding: utf-8 -*-
"""查日橡胶（RSS3）到底哪个接口有更接近 15:00 的价。
用户在新浪页面 https://finance.sina.com.cn/futures/quotes/RSS3.shtml 上看到 14:50 的数据，
而我们现用的分时接口只到 14:11 → 说明有别的接口更新。逐个查。
显式禁用代理（国内直连环境）。
"""
import json, re, time, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def get(url, headers=None, timeout=20):
    h = {'User-Agent': UA}
    if headers:
        h.update(headers)
    r = NOPROXY.open(urllib.request.Request(url, headers=h), timeout=timeout)
    return r.read()


print('=' * 100)
print('① 新浪快照 hq.sinajs.cn/list=hf_RSS3（我们主路用的就是这个，带 Referer）')
print('=' * 100)
try:
    txt = get('https://hq.sinajs.cn/list=hf_RSS3', {'Referer': 'https://finance.sina.com.cn'}).decode('gbk', 'replace')
    print('  原始:', txt.strip())
    m = re.search(r'"([^"]*)"', txt)
    if m:
        f = m.group(1).split(',')
        for i, v in enumerate(f):
            if v:
                print('   f[%d] = %s' % (i, v))
except Exception as e:
    print('  失败:', type(e).__name__, str(e)[:80])
time.sleep(0.4)

print()
print('=' * 100)
print('② 新浪日K（取"今天"那根 = 当日收盘价）')
print('=' * 100)
try:
    url = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/'
           'GlobalFuturesService.getGlobalFuturesDailyKLine?symbol=RSS3')
    t = get(url).decode('utf-8', 'replace')
    m = re.search(r'\((\[.*\])\)', t, re.S)
    if m:
        arr = json.loads(m.group(1))
        print('  日K 共 %d 根，最后 5 根：' % len(arr))
        for k in arr[-5:]:
            print('   ', k)
except Exception as e:
    print('  失败:', type(e).__name__, str(e)[:80])
time.sleep(0.4)

print()
print('=' * 100)
print('③ 我们现在用的分时接口（末 6 笔）')
print('=' * 100)
try:
    url = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
           'GlobalFuturesService.getGlobalFuturesMinLine?symbol=RSS3')
    o = json.loads(get(url).decode('utf-8', 'replace'))
    arr = ((o.get('result') or {}).get('data') or {}).get('minLine_1d') or []
    print('  首根:', arr[0][:8] if arr else None)
    print('  末 6 笔:')
    for e in arr[-6:]:
        print('   ', e)
    print('  总点数:', len(arr))
except Exception as e:
    print('  失败:', type(e).__name__, str(e)[:80])
time.sleep(0.4)

print()
print('=' * 100)
print('④ 5 分钟线 / 其他口径')
print('=' * 100)
for nm, u in [('5MLine RSS3', 'https://stock2.finance.sina.com.cn/futures/api/openapi.php/GlobalFuturesService.getGlobalFutures5MLine?symbol=RSS3'),
              ('日K(jsonp) RSS3 · 只列 date/close', None)]:
    if u:
        try:
            b = get(u).decode('utf-8', 'replace')
            print('  %s -> %s' % (nm, b[:200]))
        except Exception as e:
            print('  %s 失败 %s' % (nm, type(e).__name__))
        time.sleep(0.3)

print()
print('=' * 100)
print('⑤ 新浪行情页面用的是什么接口（抓源码找线索）')
print('=' * 100)
try:
    html = get('https://finance.sina.com.cn/futures/quotes/RSS3.shtml').decode('gbk', 'replace')
    hits = set()
    for pat in [r'hq\.sinajs\.cn[^\'"\s<>]*', r'stock2\.finance\.sina[^\'"\s<>]*',
                r'GlobalFutures[A-Za-z]*', r'InnerFutures[A-Za-z]*', r'openapi\.php[^\'"\s<>]*',
                r'[a-z0-9.]*sina[a-z0-9.]*/[^\'"\s<>]*\.js']:
        for mm in re.findall(pat, html):
            hits.add(mm)
    for h in sorted(hits)[:30]:
        print('  ', h)
    print('  （页面长度 %d 字节）' % len(html))
except Exception as e:
    print('  失败:', type(e).__name__, str(e)[:80])
