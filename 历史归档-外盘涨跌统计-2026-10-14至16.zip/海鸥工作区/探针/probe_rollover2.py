# -*- coding: utf-8 -*-
"""换月检测判据回测：现有方案 vs 我的改法。

关键物理事实：**参考价（某时刻的价）必然落在"那一天那根日K"的 [low, high] 内**
—— 同一合约、同一天，这是必然的。所以"参考价是否落在对应那天日K区间内"
是判定【合约口径是否一致】的充分证据。

现有方案用的是【最近 2 根日K的并集区间】→ 换月当天会把【老合约那根】也包进来，
区间被撑宽 → 老合约的价当然落在里面 → **漏检**。

回测：对每个真实跳空点，看"老合约的价"落在哪：
  · 落在【最近2根并集】内 → 现有方案会漏检（✗）
  · 落在【跳空后那1根】内   → 我的改法也会漏检（✗）
  · 都不落在 → 两个方案都能检出（✓）
"""
import json, re, ssl, time, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
OPENER = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
DK = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/'
      'GlobalFuturesService.getGlobalFuturesDailyKLine?symbol={sym}')

CASES = [
    ('美国天然气', 'NG', '2026-10-13', '真换月？大跳空 +10.48%'),
    ('美燃油', 'HO', '2026-10-15', '用户碰到的案例（-3.23%）'),
    ('布伦特原油', 'OIL', '2026-10-02', '大跳空 -5.23%'),
    ('伦铝', 'AHD', '2026-10-09', '跳空 +2.73%'),
    ('日橡胶', 'RSS3', '2026-09-24', '对照组：真实行情下跌 -2.95%（非换月）'),
]


def dk(sym):
    t = OPENER.open(urllib.request.Request(DK.format(sym=sym), headers={'User-Agent': UA}),
                    timeout=25).read().decode('utf-8', 'replace')
    m = re.search(r'\((\[.*\])\)', t, re.S)
    return json.loads(m.group(1)) if m else []


def inrange(x, lo, hi, tol=0.005):
    return lo * (1 - tol) <= x <= hi * (1 + tol)


print('=' * 112)
print('换月检测判据回测 · 本地时间 %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
print('=' * 112)
for name, sym, date, note in CASES:
    arr = dk(sym)
    idx = next((i for i, r in enumerate(arr) if r.get('date') == date), None)
    if idx is None or idx < 2 or idx + 1 >= len(arr):
        print('%-12s %s → 日K里找不到该日期，跳过' % (name, date))
        continue
    before = arr[idx - 1]          # 老合约那根
    cur = arr[idx]                 # 跳空后（新合约）第一根
    nxt = arr[idx + 1]

    old_price = float(before['close'])            # 模拟"老合约的参考价"
    lo2 = min(float(cur['low']), float(nxt['low']))
    hi2 = max(float(cur['high']), float(nxt['high']))
    lo1, hi1 = float(cur['low']), float(cur['high'])

    hit_old = inrange(old_price, lo2, hi2)        # 落在"最近2根并集"→ 现有方案漏检
    hit_new = inrange(old_price, lo1, hi1)        # 落在"跳空后1根"→ 我的改法也漏检

    print()
    print('%s（%s）  %s' % (name, date, note))
    print('  老合约那根 %s:  O=%s H=%s L=%s C=%s' % (before['date'], before['open'], before['high'], before['low'], before['close']))
    print('  新合约首根 %s:  O=%s H=%s L=%s C=%s' % (cur['date'], cur['open'], cur['high'], cur['low'], cur['close']))
    print('  模拟参考价（老合约价）= %s' % old_price)
    print('  现有方案 区间=最近2根并集 [%.4f, %.4f] → 参考价在内? %s → %s'
          % (lo2, hi2, '是' if hit_old else '否', '❌漏检' if hit_old else '✓可检出'))
    print('  我的改法 区间=当天那1根   [%.4f, %.4f] → 参考价在内? %s → %s'
          % (lo1, hi1, '是' if hit_new else '否', '❌漏检' if hit_new else '✓可检出'))
    time.sleep(0.3)

print()
print('=' * 112)
print('说明：对照组（日橡胶，真实行情非换月）应当"两个方案都不触发"才安全 ——')
print('      因为它的参考价来自当天同一合约，必然落在当天日K区间内。')
print('=' * 112)
