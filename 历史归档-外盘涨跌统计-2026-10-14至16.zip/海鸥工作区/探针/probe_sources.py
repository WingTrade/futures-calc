# -*- coding: utf-8 -*-
"""数据源探针：验证「浏览器能否直连/JSONP 拿到起始价与最新价」。
只读请求，低频（每个端点 1 次），不改任何线上内容。
"""
import json, re, sys, urllib.request, urllib.error

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'


def probe(name, url, headers=None, show=260):
    h = {'User-Agent': UA}
    if headers:
        h.update(headers)
    try:
        req = urllib.request.Request(url, headers=h)
        with urllib.request.urlopen(req, timeout=20) as r:
            body = r.read()
            hd = {k.lower(): v for k, v in r.headers.items()}
            txt = body.decode('gbk', errors='replace') if 'sinajs' in url else body.decode('utf-8', errors='replace')
            interesting = {k: v for k, v in hd.items()
                           if k.startswith('access-control') or k in ('content-type', 'cache-control',
                                                                      'content-length', 'server', 'x-cache')}
            print(f'--- {name}')
            print(f'    HTTP {r.status}  len={len(body)}  headers={interesting}')
            print(f'    body[:{show}]={txt[:show]!r}')
            return txt
    except urllib.error.HTTPError as e:
        print(f'--- {name}')
        print(f'    HTTPError {e.code}  headers={{k.lower():v for k,v in dict(e.headers).items() if k.lower().startswith("access-control")}}')
        return None
    except Exception as e:
        print(f'--- {name}')
        print(f'    FAIL {type(e).__name__}: {e}')
        return None


SINA_HQ = 'https://hq.sinajs.cn/list=hf_GC'
SINA_ML = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
           'GlobalFuturesService.getGlobalFuturesMinLine?symbol=GC&callback=var%20d=')
SINA_ML_NOCB = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
                'GlobalFuturesService.getGlobalFuturesMinLine?symbol=GC')
SINA_5D = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
           'GlobalFuturesService.getGlobalFutures5MLine?symbol=GC')
SINA_DAILYK = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/'
               'GlobalFuturesService.getGlobalFuturesDailyKLine?symbol=GC')
SINA_US = ('https://stock2.finance.sina.com.cn/usstock/api/jsonp.php/var%20d=/'
           'US_MinKService.getDailyK?symbol=.INX')
TX = 'https://qt.gtimg.cn/q=hf_GC,hf_HO'
TX_MIN = 'https://web.ifzq.gtimg.cn/appstock/app/minute/query?code=sh000001'

if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'
    print('== 探针开始 ==')
    if which in ('all', 'sina'):
        print('\n### 1. 新浪 hq.sinajs.cn 快照（无 Referer → 防盗链预期拒绝）')
        probe('hq.sinajs.cn 无 Referer', SINA_HQ)
        probe('hq.sinajs.cn 带 Referer', SINA_HQ, {'Referer': 'https://finance.sina.com.cn'})
    if which in ('all', 'ml'):
        print('\n### 2. 新浪 stock2 分时 JSONP（浏览器 script 注入路线的关键）')
        t = probe('GlobalFuturesMinLine 带 callback（无 Referer）', SINA_ML)
        probe('GlobalFuturesMinLine 无 callback（无 Referer）', SINA_ML_NOCB)
        if t:
            m = re.search(r'\((\{.*\})\)', t, re.S)
            if m:
                try:
                    o = json.loads(m.group(1))
                    d = (o.get('result') or {}).get('data') or {}
                    arr = d.get('minLine_1d')
                    print(f'    parsed keys={list(o.keys())} data.keys={list(d.keys())}')
                    if isinstance(arr, list):
                        print(f'    minLine_1d len={len(arr)} first={arr[0][:8] if arr and isinstance(arr[0], list) else arr[:1]}')
                        print(f'    minLine_1d last={arr[-1][:8] if isinstance(arr[-1], list) else arr[-1]}')
                except Exception as e:
                    print(f'    parse-fail {type(e).__name__}: {e}')
    if which in ('all', '5d'):
        print('\n### 3. 新浪 5 分钟线（跨日节点用）')
        probe('getGlobalFutures5MLine GC', SINA_5D)
        print('\n### 4. 新浪日 K / 美股日 K')
        probe('DailyKLine GC', SINA_DAILYK)
        probe('US DailyK .INX', SINA_US)
    if which in ('all', 'tx'):
        print('\n### 5. 腾讯（对比基准）')
        probe('qt.gtimg.cn 无 Referer', TX)
        probe('ifzq 上证分时', TX_MIN)
    print('== 探针结束 ==')
