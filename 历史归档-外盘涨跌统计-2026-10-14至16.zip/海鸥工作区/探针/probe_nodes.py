# -*- coding: utf-8 -*-
"""节点级验证：对每个品种，从分时表里取 ≤10:15 / ≤11:30 / ≤15:00 的最后一笔，
报告"实际取到哪一笔、与节点差多少分钟"。

用途：对应你的 4 个使用场景（10:15 档 / 11:30 档 / 15:00 档 / 夜盘各档），
      逐个检查是否有品种在这些时刻"未开盘或已收盘"，导致取价笔与节点严重偏离。
显式禁用代理。
"""
import json, re, time, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))
ML = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
      'GlobalFuturesService.getGlobalFuturesMinLine?symbol={sym}')

SYMS = [
    ('WTI原油', 'CL'), ('布伦特原油', 'OIL'), ('美黄金', 'GC'), ('美白银', 'SI'), ('伦敦银现货', 'XAG'),
    ('伦铝', 'AHD'), ('伦锌', 'ZSD'), ('伦镍', 'NID'), ('伦锡', 'SND'), ('美铜', 'HG'),
    ('伦铜', 'CAD'), ('伦铅', 'PBD'), ('美燃油', 'HO'), ('美国天然气', 'NG'), ('美大豆', 'S'),
    ('美黄豆粉', 'SM'), ('美黄豆油', 'BO'), ('美原糖', 'RS'), ('美国棉花', 'CT'), ('马棕油', 'FCPO'),
    ('新加坡铁矿石', 'FEF'), ('日橡胶', 'RSS3'),
]
NODES = [('10:15', 615), ('11:30', 690), ('15:00', 900)]


def pts_of(sym):
    try:
        o = json.loads(NOPROXY.open(urllib.request.Request(
            ML.format(sym=sym), headers={'User-Agent': UA}), timeout=25).read().decode('utf-8', 'replace'))
        arr = ((o.get('result') or {}).get('data') or {}).get('minLine_1d') or []
    except Exception:
        return None, []
    out = []
    for i, e in enumerate(arr):
        if i == 0 or not isinstance(e, list) or len(e) < 2:
            continue
        tk = str(e[0])
        if not re.match(r'^\d{2}:\d{2}$', tk):
            continue
        try:
            out.append((int(tk[:2]) * 60 + int(tk[3:5]), float(e[1])))
        except ValueError:
            pass
    return (arr[0][0] if isinstance(arr[0], list) else None), out


print('=' * 126)
print('节点级验证 · 本地时间 %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
print('说明：取"≤ 节点分钟的最后一笔"。差距 0 分 = 那一分钟正好有成交；差距大 = 该时刻附近无成交 / 未开盘 / 已收盘')
print('=' * 126)
print('%-12s %-9s | %-22s | %-22s | %-22s' % ('品种', '表首根', '≤10:15 取到', '≤11:30 取到', '≤15:00 取到'))
print('-' * 126)

big = []
for name, sym in SYMS:
    first, pts = pts_of(sym)
    cells = []
    for label, node in NODES:
        hit = None
        for m, p in pts:
            if m <= node:
                hit = (m, p)
            else:
                break
        if hit is None:
            cells.append('取不到（表已滚出该节点）')
        else:
            gap = node - hit[0]
            cells.append('%s (价 %s，差 %d 分)' % (
                '%02d:%02d' % (hit[0] // 60, hit[0] % 60), hit[1], gap))
            if gap >= 5:
                big.append((name, label, '%02d:%02d' % (hit[0] // 60, hit[0] % 60), gap))
    print('%-12s %-9s | %-22s | %-22s | %-22s' % (name, first or '-', cells[0], cells[1], cells[2]))
    time.sleep(0.35)

print()
print('=' * 126)
print('需要留意的行（取价笔比节点早 ≥5 分钟）')
print('=' * 126)
if big:
    for name, label, at, gap in big:
        print('  %-12s 节点 %s → 实际取到 %s（早 %d 分钟）' % (name, label, at, gap))
else:
    print('  （无）')
