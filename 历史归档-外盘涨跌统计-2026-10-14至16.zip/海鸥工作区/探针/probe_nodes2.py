# -*- coding: utf-8 -*-
"""节点级验证（修正版）：用新浪分时表自带的【完整时间戳】，不用分钟数比较。

上一版用"分钟数取 ≤ 节点"在跨日表上会误判（如马棕油：表含"昨晚 21:00-23:00 + 今天 10:30-17:19"），
本版改用表里每条自带的 `2026-10-16 16:37:00` 时间戳（与 fetch.py 生产代码同一口径）。
"""
import json, re, ssl, time, urllib.request
from datetime import datetime, timedelta

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))
ML = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
      'GlobalFuturesService.getGlobalFuturesMinLine?symbol={sym}')

SYMS = [
    ('WTI原油', 'CL'), ('布伦特原油', 'OIL'), ('美黄金', 'GC'), ('美白银', 'SI'), ('伦敦银现货', 'XAG'),
    ('伦铝', 'AHD'), ('伦锌', 'ZSD'), ('伦镍', 'NID'), ('伦锡', 'SND'), ('美铜', 'HG'),
    ('伦铜', 'CAD'), ('伦铅', 'PBD'), ('美燃油', 'HO'), ('美国天然气', 'NG'), ('美大豆', 'S'),
    ('美黄豆粉', 'SM'), ('美黄豆油', 'BO'), ('美原糖', 'RS'), ('美国棉花', 'CT'), ('马棕油', 'FCPO'),
    ('新加坡铁矿石', 'FEF'), ('日橡胶', 'RSS3'),
]
TS = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}')


def pts_of(sym):
    """→ [(datetime, price)]，用表内自带时间戳"""
    try:
        o = json.loads(NOPROXY.open(urllib.request.Request(
            ML.format(sym=sym), headers={'User-Agent': UA}), timeout=25).read().decode('utf-8', 'replace'))
        arr = ((o.get('result') or {}).get('data') or {}).get('minLine_1d') or []
    except Exception:
        return []
    out = []
    for e in arr:
        if not isinstance(e, list) or len(e) < 2:
            continue
        tsv = e[-1] if isinstance(e[-1], str) else ''
        if not TS.match(tsv):
            continue
        try:
            out.append((datetime.strptime(tsv[:16], '%Y-%m-%d %H:%M'), float(e[1])))
        except ValueError:
            continue
    out.sort(key=lambda x: x[0])
    return out


def ref_price_at(pts, target):
    """取 ≤ target 的最后一笔（与 fetch.py ref_price_from_bars 同逻辑）"""
    best = None
    for dt, p in pts:
        if dt <= target:
            best = (dt, p)
        else:
            break
    return best


now = datetime.now()
today = now.date()
NODES = [('10:15', 10, 15), ('11:30', 11, 30), ('15:00', 15, 0)]

print('=' * 118)
print('节点级验证（修正版，用官方时间戳）· 本地时间 %s' % now.strftime('%Y-%m-%d %H:%M:%S'))
print('=' * 118)
print('%-12s %-19s %-24s %-24s %-24s' % ('品种', '表内区间', '≤10:15', '≤11:30', '≤15:00'))
print('-' * 118)

notice = []
for name, sym in SYMS:
    pts = pts_of(sym)
    if not pts:
        print('%-12s %-19s 无数据' % (name, '-'))
        continue
    span = '%s~%s' % (pts[0][0].strftime('%m-%d %H:%M'), pts[-1][0].strftime('%m-%d %H:%M'))
    cells = []
    for label, hh, mm in NODES:
        tgt = datetime(today.year, today.month, today.day, hh, mm)
        hit = ref_price_at(pts, tgt)
        if hit is None:
            cells.append('该节点早于表起点 → 取不到')
            notice.append((name, label, '取不到', None))
        else:
            gap = int((tgt - hit[0]).total_seconds() // 60)
            cells.append('%s（价 %s，早 %d 分）' % (hit[0].strftime('%m-%d %H:%M'), hit[1], gap))
            if gap >= 5:
                notice.append((name, label, hit[0].strftime('%m-%d %H:%M'), gap))
    print('%-12s %-19s %-24s %-24s %-24s' % (name, span, cells[0], cells[1], cells[2]))
    time.sleep(0.35)

print()
print('=' * 118)
print('需要留意的（取价笔比节点早 ≥5 分钟，或取不到）')
print('=' * 118)
if notice:
    for name, label, at, gap in notice:
        if gap is None:
            print('  %-12s 节点 %-6s → 取不到（表内没有该节点之前的成交）' % (name, label))
        else:
            print('  %-12s 节点 %-6s → 实际取到 %s（早 %d 分钟）' % (name, label, at, gap))
else:
    print('  （无）')
print()
print('提示：取价笔偏早有两种原因 —— ①该品种此处成交稀疏（真实）；②该品种此刻已收盘/未开盘（需判断是否有更权威的收盘价可替代）')
