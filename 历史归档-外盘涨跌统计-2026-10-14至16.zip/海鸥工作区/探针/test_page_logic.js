/* 体检页核心算法自检：从 HTML 抽取脚本，剥离 DOM 调用，用真样本断言。 */
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('E:\\DwnlData\\外盘涨跌统计\\诊断页\\外盘体检.html', 'utf8');
let js = (html.match(/<script>([\s\S]*?)<\/script>/) || [])[1] || '';
js = js.replace(/main\(\);\s*$/, '');            // 去掉自动启动
const ctx = { document: { getElementById: () => null, createElement: () => ({}), body: { appendChild(){} } }, window: {}, fetch: () => Promise.reject(new Error('no net')), setTimeout, clearTimeout };
vm.createContext(ctx);
vm.runInContext(js, ctx);

let pass = 0, fail = 0;
function eq(name, got, want) {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  console.log((ok ? '  PASS ' : '  FAIL ') + name + '  got=' + JSON.stringify(got) + (ok ? '' : '  want=' + JSON.stringify(want)));
  ok ? pass++ : fail++;
}

/* 样本 1：原糖跨日时段（10-15 15:30 → 10-16 00:59），云端 close=21.149 */
const rsArr = [
  ["2026-10-15", "20.840", "nybot", "", "15:30", "20.708"],
  ["15:31", "20.750", "0", "0", "20.700", "2026-10-15 15:31:00"],
  ["23:59", "21.100", "0", "0", "21.000", "2026-10-15 23:59:00"],
  ["00:01", "21.120", "0", "0", "21.050", "2026-10-16 00:01:00"],
  ["00:59", "21.149", "445", "0", "20.997", "2026-10-16 00:59:00"]
];
const rsPts = ctx.buildPoints(rsArr);
eq('RS 点数（跳过首根）', rsPts.length, 4);
eq('RS 跨日后日期推断', rsPts[rsPts.length - 1].date, '2026-10-16');
const rsTgt = ctx.refTarget('10-16 00:59', 2026);
eq('RS 目标解析', rsTgt, { date: '2026-10-16', min: 59, label: '00:59' });
const rsHit = ctx.pick(rsPts, rsTgt);
eq('RS 命中价 = 云端 21.149', rsHit && rsHit.price, 21.149);

/* 样本 2：稀疏品种（美黄豆粉：云端标称 11:30，实际取价笔 10:23） */
const smArr = [
  ["2026-10-16", "346.200", "cme_cbt", "", "08:27", "345.600"],
  ["10:23", "344.800", "0", "0", "344.900", "2026-10-16 10:23:00"],
  ["14:46", "344.800", "0", "0", "344.800", "2026-10-16 14:46:00"]
];
const smTgt = ctx.refTarget('10-16 11:30', 2026);
const smHit = ctx.pick(ctx.buildPoints(smArr), smTgt);
eq('SM 命中价 = 云端 344.8', smHit && smHit.price, 344.8);
eq('SM 实际取价笔 10:23（偏差 67 分）', smTgt.min - smHit.min, 67);

/* 样本 3：LME 稀疏（伦铅标称 11:30，实际 11:14） */
const pbArr = [["2026-10-16", "1890", "lme", "", "08:57", "1888"],
               ["11:14", "1891.225", "0", "0", "1891", "2026-10-16 11:14:00"],
               ["15:05", "1887.5", "0", "0", "1887.5", "2026-10-16 15:05:00"]];
const pbTgt = ctx.refTarget('10-16 11:30', 2026);
const pbHit = ctx.pick(ctx.buildPoints(pbArr), pbTgt);
eq('PB 命中价 = 云端 1891.225', pbHit && pbHit.price, 1891.225);
eq('PB 实际取价笔 11:14', pbTgt.min - pbHit.min, 16);

/* 样本 4：节点早于所有点（时段已滚动 → 不应命中） */
const rolled = [["2026-10-16", "0", "x", "", "20:00", "0"],
                ["20:01", "1.0", "0", "0", "1.0", "2026-10-16 20:01:00"]];
eq('节点已滚动时命中 null', ctx.pick(ctx.buildPoints(rolled), ctx.refTarget('10-16 10:15', 2026)), null);

/* 样本 5：档位判定（周五 15:0x → day） */
eq('15:0x 档位=day', ctx.expectMode(new Date(2026, 9, 16, 15, 5)), 'day');
eq('10:2x 档位=m1015', ctx.expectMode(new Date(2026, 9, 16, 10, 20)), 'm1015');
eq('12:0x 档位=m1130', ctx.expectMode(new Date(2026, 9, 16, 12, 0)), 'm1130');
eq('03:0x 档位=night', ctx.expectMode(new Date(2026, 9, 16, 3, 0)), 'night');
eq('周日 15:0x 档位=night', ctx.expectMode(new Date(2026, 9, 18, 15, 5)), 'night');

console.log('\n自检结果：PASS ' + pass + ' / FAIL ' + fail);
process.exit(fail ? 1 : 0);
