# -*- coding: utf-8 -*-
"""无代理环境下的替代源排查：
  A) 腾讯行情到底覆盖不覆盖那 6 个"新浪独有"品种（若有 → 可替掉失效的 TradingView 兜底）
  B) 新浪分时表末根价 vs 快照价，一致性如何（分时接口可作为最新价兜底吗）
  C) 全网兜底链现状盘点
显式禁用代理。
"""
import json, re, time, urllib.error, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))
SINA_HQ = {'Referer': 'https://finance.sina.com.cn', 'User-Agent': UA}


def get(url, headers=None, timeout=15):
    h = {'User-Agent': UA}
    if headers:
        h.update(headers)
    r = NOPROXY.open(urllib.request.Request(url, headers=h), timeout=timeout)
    return r.read()


# 6 个"新浪独有"品种 + 1 个参考
SIX = [('原糖', 'hf_RS', 'RS'), ('棉花', 'hf_CT', 'CT'), ('马棕油', 'hf_FCPO', 'FCPO'),
       ('铁矿', 'hf_FEF', 'FEF'), ('日橡胶', 'hf_RSS3', 'RSS3'), ('美燃油', 'hf_HO', 'HO')]

print('=' * 100)
print('A. 腾讯行情对这 6 个品种的覆盖（项目结论是"腾讯只有 16 个品种"，此处实测）')
print('=' * 100)
codes = ','.join(c for _, c, _ in SIX)
try:
    body = get('https://qt.gtimg.cn/q=' + codes).decode('gbk', errors='replace')
    got = dict(re.findall(r'v_(\w+)="([^"]*)"', body))
    for nm, code, _ in SIX:
        if code in got and got[code].strip('~, '):
            first = got[code].split('~')[0].split(',')[0]
            print('  %-8s %-9s 有数据   首字段=%s   原始前 70 字=%s' % (nm, code, first, got[code][:70]))
        else:
            print('  %-8s %-9s 无数据（腾讯不覆盖）' % (nm, code))
except Exception as e:
    print('  腾讯请求失败:', type(e).__name__, str(e)[:80])

print()
print('  补充：腾讯 fu 系（延时行情）试查：')
for probe_code in ['fuRS', 'fuCT', 'fuFCPO', 'fuFEF', 'fuRSS3', 'fuHO']:
    try:
        body = get('https://qt.gtimg.cn/q=' + probe_code).decode('gbk', errors='replace')
        m = re.search(r'v_' + probe_code + r'="([^"]*)"', body)
        val = (m.group(1).split('~')[3] if m and m.group(1).count('~') > 3 else None)
        print('    %-8s %s' % (probe_code, ('有数据 最新价=' + str(val)) if val else '无数据'))
    except Exception as e:
        print('    %-8s 失败 %s' % (probe_code, type(e).__name__))
    time.sleep(0.25)

print()
print('=' * 100)
print('B. 新浪分时表末根价 vs 新浪快照价（分时接口能否当最新价用）')
print('=' * 100)
try:
    body = get('https://hq.sinajs.cn/list=' + codes, SINA_HQ).decode('gbk', errors='replace')
    snap = {}
    for m in re.finditer(r'hq_str_(\w+)="([^"]*)"', body):
        f = m.group(2).split(',')
        if len(f) > 12 and f[0]:
            snap[m.group(1)] = (float(f[0]), f[6], f[12])
except Exception as e:
    print('  新浪快照失败:', type(e).__name__, str(e)[:80])
    snap = {}

ML = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
      'GlobalFuturesService.getGlobalFuturesMinLine?symbol=')
print('  %-8s %-12s %-12s %-10s %s' % ('品种', '快照最新价', '分时末根价', '偏差', '说明'))
print('  ' + '-' * 76)
for nm, code, sym in SIX:
    try:
        t = get(ML + sym).decode('utf-8', errors='replace')
        o = json.loads(t)
        arr = ((o.get('result') or {}).get('data') or {}).get('minLine_1d') or []
        last_pt = None
        for e in arr[1:]:
            if isinstance(e, list) and len(e) > 1 and re.match(r'^\d{2}:\d{2}$', str(e[0])):
                try:
                    last_pt = (str(e[0]), float(e[1]))
                except ValueError:
                    pass
        sv = snap.get(code, (None,))[0]
        if last_pt:
            diff = ('%.3f%%' % ((last_pt[1] - sv) / sv * 100)) if sv else '-'
            flag = '可取' if sv and abs(last_pt[1] - sv) / sv < 0.005 else ('差异大' if sv else '快照缺')
            print('  %-8s %-12s %-12s %-10s %s (末根时刻 %s)' % (nm, sv if sv else '-', last_pt[1], diff, flag, last_pt[0]))
        else:
            print('  %-8s %-12s %-12s %-10s 分时表无有效末根' % (nm, sv if sv else '-', '-', '-'))
    except Exception as e:
        print('  %-8s 分时失败: %s %s' % (nm, type(e).__name__, str(e)[:50]))
    time.sleep(0.3)

print()
print('=' * 100)
print('C. 兜底链盘点（无代理环境下）')
print('=' * 100)
print('  新浪快照  需 Referer + 需中转(pages.dev)  ← 中转本身证书链有问题')
print('  腾讯行情  可直连（16 品种实时；美燃油 fuHO 延时 10-15 分钟）')
print('  TradingView 实测超时（国内直连不通）→ 原本的"4 品种延时兜底"实际不存在')
print('  jsDelivr 实测 RST（EXE 的备用数据源不可用，仅剩 GitHub Pages 主源）')
print('  stock2 分时 可直连（73ms）→ 唯一稳定可直连的新浪数据源')
