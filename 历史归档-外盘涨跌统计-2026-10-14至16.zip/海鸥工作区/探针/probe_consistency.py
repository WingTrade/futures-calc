# -*- coding: utf-8 -*-
"""探针 4（关键）：验证「前端现算 = 云端 data.json」一致性。

做法：抓线上 data.json（当前 m1130 档，基准=今日 11:30），
再用新浪分时接口按同样的取价规则（<= 11:30 的最后一根）自己算一遍，逐行比对。
若数字一致 → 「前端现算基准价」方案成立（同源同口径，不引入偏差）。
顺带验证 JSONP 自定义 callback 名（浏览器 script 注入路线）。
"""
import json, re, ssl, urllib.request

ctx = ssl._create_unverified_context()
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'}
OPEN = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
        'GlobalFuturesService.getGlobalFuturesMinLine?symbol={sym}&callback={cb}')
HOUR_KEYS = ['10:15', '11:30']


def get(url, ctx=ctx):
    return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=25, context=ctx).read().decode('utf-8', errors='replace')


def minline(sym, cb='var%20d='):
    txt = get(OPEN.format(sym=sym, cb=cb))
    m = re.search(r'\(\s*(\{.*\})\s*\)', txt, re.S)
    if not m:
        return None, txt[:80]
    obj = json.loads(m.group(1))
    data = (obj.get('result') or {}).get('data') or {}
    return data.get('minLine_1d'), None


def points(arr):
    out = []
    if not isinstance(arr, list):
        return out
    for i, e in enumerate(arr):
        if i == 0 or not isinstance(e, list) or len(e) < 2:
            continue
        tk = str(e[0])
        if not re.match(r'^\d{2}:\d{2}$', tk):
            continue
        try:
            out.append((tk, float(e[1])))
        except (ValueError, IndexError):
            pass
    return out


def ref_at(pts, key, max_gap_min=26 * 60):
    """复刻 fetch.py：取 <= key 的最后一根（分钟粒度字符串比较）"""
    best = None
    for tk, p in pts:
        if tk <= key:
            best = (tk, p)
        else:
            break
    return best


print('== 0. JSONP 自定义 callback 名测试（浏览器 script 注入路线）==')
txt = get(OPEN.format(sym='GC', cb='cbWaiPan123'))
print('   callback=cbWaiPan123 返回前缀:', repr(txt[:60]))
print('   是否以 cbWaiPan123( 开头:', txt.lstrip().startswith('cbWaiPan123(') or 'cbWaiPan123(' in txt[:200])

print('\n== 1. 抓线上 data.json（云端值）==')
d = json.loads(get('https://wingtrade.github.io/futures-calc/data.json'))
print('   generated_at=', d.get('generated_at'), 'mode=', d.get('mode'), 'ref_desc=', d.get('ref_desc'))
remote = {r['name']: r for r in d.get('rows') or []}

print('\n== 2. 前端现算（复刻取价规则）==')
CODE_SYM = {'WTI原油': 'CL', '布伦特原油': 'OIL', '美黄金': 'GC', '美白银': 'SI', '伦敦银现货': 'XAG',
            '伦铝': 'AHD', '伦锌': 'ZSD', '伦镍': 'NID', '伦锡': 'SND', '美铜': 'HG', '伦铜': 'CAD',
            '伦铅': 'PBD', '美燃油': 'HO', '美国天然气': 'NG', '美大豆': 'S', '美黄豆粉': 'SM',
            '美黄豆油': 'BO', '美原糖': 'RS', '美国棉花': 'CT', '马棕油': 'FCPO',
            '新加坡铁矿石': 'FEF', '日橡胶': 'RSS3'}

print(f'{"品种":<12}{"云端 close":>12}{"现算 close":>12}{"云端 ref":>14}{"现算取价笔":>12}   一致?')
print('-' * 78)
same = diff = miss = 0
for name, sym in CODE_SYM.items():
    r = remote.get(name)
    if not r:
        continue
    arr, err = minline(sym)
    pts = points(arr)
    key = '11:30' if r.get('ref', '').endswith('11:30') else '00:59'
    got = ref_at(pts, key)
    c_remote = r.get('close')
    c_local = got[1] if got else None
    ok = (c_remote is not None and c_local is not None and abs(c_remote - c_local) < 1e-6)
    tag = '一致' if ok else ('—' if c_remote is None and c_local is None else '不一致')
    if ok:
        same += 1
    elif c_remote is None or c_local is None:
        miss += 1
    else:
        diff += 1
    print(f'{name:<12}{str(c_remote):>12}{str(c_local):>12}{str(r.get("ref")):>14}{str(got[0] if got else None):>12}   {tag}')

print(f'\n统计：一致 {same}，不一致 {diff}，缺失 {miss}')
print('\n== 3. 结论 ==')
print('   若「一致」占绝大多数，则「前端用 JSONP 现算基准价」与云端 data.json 同源同口径，')
print('   可以在云端轮次迟到时立刻补上准确的节点价，而不引入任何数字偏差。')
