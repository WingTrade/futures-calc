# -*- coding: utf-8 -*-
"""找第二条腿（不依赖中转的数据源）：
  A) 腾讯 fu 系列批量枚举（看外盘期货延时行情覆盖哪些品种）
  B) 新浪 openapi 服务名探测（找一个"只返回最新价"的轻量接口）
显式禁用代理。
"""
import json, re, time, urllib.error, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def get(url, timeout=12, headers=None):
    h = {'User-Agent': UA}
    if headers:
        h.update(headers)
    r = NOPROXY.open(urllib.request.Request(url, headers=h), timeout=timeout)
    return r.status, r.read()


print('=' * 104)
print('A) 腾讯 fu 系列批量枚举（哪些代码有真实数据）')
print('=' * 104)
cand = ['fuHO', 'fuCL', 'fuOIL', 'fuGC', 'fuSI', 'fuNG', 'fuS', 'fuSM', 'fuBO', 'fuSB', 'fuRS', 'fuCT',
        'fuFCPO', 'fuPALM', 'fuFEF', 'fuIO', 'fuRSS3', 'fuRB', 'fuHG', 'fuCAD', 'fuAHD', 'fuZSD',
        'fuNID', 'fuSND', 'fuPBD', 'fuXAG', 'fuSUGAR', 'fuCOTTON', 'fuRUBBER', 'fuIRON', 'fuSPX', 'fuDJI']
found = []
for i in range(0, len(cand), 8):
    batch = cand[i:i + 8]
    try:
        st, body = get('https://qt.gtimg.cn/q=' + ','.join(batch))
        txt = body.decode('gbk', errors='replace')
        for code in batch:
            m = re.search(r'v_' + code + r'="([^"]*)"', txt)
            if m and m.group(1).strip('~, '):
                f = m.group(1).split('~')
                px = f[3] if len(f) > 3 else '?'
                cnt = len(f)
                print('  %-10s 有数据  字段数=%-4s 最新价=%s' % (code, cnt, px))
                found.append(code)
            else:
                print('  %-10s 无' % code)
    except Exception as e:
        print('  批次失败 %s' % type(e).__name__)
    time.sleep(0.3)
print('  → 腾讯有数据的：%s' % (found or '除 fuHO 外均无'))

print()
print('=' * 104)
print('B) 新浪 openapi 服务名探测（找轻量"最新价"接口）')
print('=' * 104)
BASE_O = 'https://stock2.finance.sina.com.cn/futures/api/openapi.php/GlobalFuturesService.'
BASE_J = 'https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/GlobalFuturesService.'
services = ['getGlobalFuturesMinLine', 'getGlobalFutures5MLine', 'getGlobalFuturesDailyKLine',
            'getGlobalFuturesQuote', 'getGlobalFuturesSnapshot', 'getGlobalFuturesLast',
            'getGlobalFuturesLastPrice', 'getGlobalFuturesRealTime', 'getGlobalFuturesTick',
            'getGlobalFuturesInfo', 'getGlobalFuturesMin5Line', 'getGlobalFuturesKLine',
            'getGlobalFuturesTimeLine', 'getGlobalFuturesNewLine', 'getGlobalFuturesPrice']
for s in services:
    url = BASE_O + s + '?symbol=RS'
    try:
        st, body = get(url, timeout=10)
        txt = body.decode('utf-8', errors='replace')
        ok = ('"status":{"code":0}' in txt.replace(' ', '')) or ('minLine' in txt) or ('"' in txt and len(body) > 60)
        print('  %-28s HTTP %s  %6dB  %s' % (s, st, len(body), ('有内容: ' + txt[:72].replace('\n', ' ')) if len(body) > 40 else '空/无效'))
    except urllib.error.HTTPError as e:
        print('  %-28s HTTP %s（不存在）' % (s, e.code))
    except Exception as e:
        print('  %-28s FAIL %s' % (s, type(e).__name__))
    time.sleep(0.25)

print()
print('=' * 104)
print('C) 已知可用接口的体积对比（每轮抓取成本）')
print('=' * 104)
for nm, url in [('分时 MinLine(RS)', BASE_O + 'getGlobalFuturesMinLine?symbol=RS'),
                ('日K DailyKLine(RS)', BASE_J + 'getGlobalFuturesDailyKLine?symbol=RS'),
                ('快照 hq.sinajs.cn(需中转+Referer)', 'https://hq.sinajs.cn/list=hf_RS')]:
    try:
        hd = {'Referer': 'https://finance.sina.com.cn'} if 'hq.sinajs' in url else None
        st, body = get(url, timeout=15, headers=hd)
        print('  %-34s %7d B' % (nm, len(body)))
    except Exception as e:
        print('  %-34s FAIL %s' % (nm, type(e).__name__))
    time.sleep(0.3)
