# -*- coding: utf-8 -*-
"""测新浪分时接口是否支持 Range 请求（只取表尾 → 兜底最新价的流量成本）。
  若支持 206 → 可用 ~2KB 拿到末根价；若不支持 → 每次都要 36KB。
显式禁用代理。
"""
import re, time, urllib.error, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))
URL = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
       'GlobalFuturesService.getGlobalFuturesMinLine?symbol=RS')


def call(headers):
    h = {'User-Agent': UA}
    h.update(headers)
    t0 = time.time()
    try:
        r = NOPROXY.open(urllib.request.Request(URL, headers=h), timeout=15)
        body = r.read()
        return r.status, len(body), body, (time.time() - t0) * 1000, dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, 0, b'', (time.time() - t0) * 1000, dict(e.headers)


print('=' * 92)
print('1) 普通请求（对照）')
st, n, body, ms, hd = call({})
print('   HTTP %s  %d 字节  %.0fms' % (st, n, ms))

print()
print('2) Range: bytes=-3000（只取尾部 3KB）')
st, n, body, ms, hd = call({'Range': 'bytes=-3000'})
print('   HTTP %s  %d 字节  %.0fms  Content-Range=%s  Accept-Ranges=%s' % (
    st, n, ms, hd.get('Content-Range'), hd.get('Accept-Ranges')))
txt = body.decode('utf-8', errors='replace')
print('   尾部 200 字: ...%s' % txt[-200:].replace('\n', ' '))
tail = re.findall(r'\["(\d{2}:\d{2})","([\d.]+)"', txt)
print('   从尾部能否解析出分钟点: %s' % (('是，最后 3 个 = ' + str(tail[-3:])) if tail else '否'))

print()
print('3) Range: bytes=0-2000（只取头部 2KB）')
st, n, body, ms, hd = call({'Range': 'bytes=0-2000'})
print('   HTTP %s  %d 字节  %.0fms  Content-Range=%s' % (st, n, ms, hd.get('Content-Range')))

print()
print('4) 若不支持 Range 的替代：完整拉取 6 个品种的耗时与体积')
total = 0
t0 = time.time()
for sym in ['RS', 'CT', 'FCPO', 'FEF', 'RSS3', 'HO']:
    try:
        r = NOPROXY.open(urllib.request.Request(URL.replace('symbol=RS', 'symbol=' + sym),
                                               headers={'User-Agent': UA}), timeout=15)
        b = r.read()
        total += len(b)
    except Exception as e:
        print('   %s 失败 %s' % (sym, type(e).__name__))
    time.sleep(0.3)
print('   6 个品种合计 %d 字节（%.1f KB），耗时 %.1f 秒' % (total, total / 1024, time.time() - t0))
print('   → 60 秒轮询一次约 %.1f MB/小时；15 秒轮询约 %.1f MB/小时' % (
    total * 60 / 1048576, total * 240 / 1048576))
