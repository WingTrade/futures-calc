# -*- coding: utf-8 -*-
"""无代理环境复测 —— 用户实际使用环境（国内直连）下重新验证所有关键链路。

背景：此前全部实测都走 Clash(127.0.0.1:7897)，代理一关，结论可能不同：
  · 「pages.dev 可用」可能是代理带来的假象
  · 「新浪 stock2 分时可用」是我方案（前端翻表补档）的命门，必须无代理复验
  · 证书报错问题也要重看
本脚本显式禁用代理（不走环境变量/注册表）。
"""
import json, re, socket, ssl, time, urllib.error, urllib.request

TIMEOUT = 15
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def probe(name, url, headers=None, want=None, timeout=TIMEOUT):
    h = {'User-Agent': UA}
    if headers:
        h.update(headers)
    t0 = time.time()
    try:
        r = NOPROXY.open(urllib.request.Request(url, headers=h), timeout=timeout)
        body = r.read()
        ms = (time.time() - t0) * 1000
        hd = {k.lower(): v for k, v in r.headers.items()}
        acao = hd.get('access-control-allow-origin')
        txt = body.decode('gbk', errors='replace') if 'sinajs' in url else body.decode('utf-8', errors='replace')
        tag = ''
        if want is not None:
            tag = '  [内容 OK]' if want in txt else '  [!! 内容异常]'
        print('%-36s HTTP %-4s %6.0fms %7dB  ACAO=%-5s%s' % (name, r.status, ms, len(body), acao or '-', tag))
        return txt
    except urllib.error.HTTPError as e:
        print('%-36s HTTPError %-4s      (%.0fms)' % (name, e.code, (time.time() - t0) * 1000))
        return None
    except Exception as e:
        print('%-36s FAIL %-14s %s  (%.0fms)' % (name, type(e).__name__, str(e)[:60], (time.time() - t0) * 1000))
        return None


def cert_of(host):
    """无代理直连取证书有效期（验证之前"证书过期"是不是代理造成的假象）"""
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, 443), timeout=12) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                c = ss.getpeercert()
                return 'OK  notAfter=%s  issuer=%s' % (c.get('notAfter'), dict((k, v) for t in c.get('issuer', ()) for k, v in t).get('commonName'))
    except Exception as e:
        return 'FAIL %s: %s' % (type(e).__name__, str(e)[:70])


print('=' * 112)
print('无代理环境复测 · 北京时间 %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
print('=' * 112)

print('\n【一】页面与数据文件（用户天天用的主链路）')
probe('GitHub Pages 首页', 'https://wingtrade.github.io/futures-calc/index.html', want='外盘涨跌统计')
probe('GitHub Pages data.json', 'https://wingtrade.github.io/futures-calc/data.json?t=%d' % time.time(), want='"rows"')
probe('jsDelivr 备用源（EXE 用）', 'https://cdn.jsdelivr.net/gh/WingTrade/futures-calc@main/data.json', want='"rows"')

print('\n【二】最新价源')
probe('腾讯 qt.gtimg.cn（16 品种实时）', 'https://qt.gtimg.cn/q=hf_GC,hf_HO', want='hq_str_hf_GC')
probe('腾讯当日分时（上证临时行）', 'https://web.ifzq.gtimg.cn/appstock/app/minute/query?code=sh000001', want='sh000001')
probe('TradingView（4 品种延时兜底）', 'https://scanner.tradingview.com/symbol?symbol=ICEUS%3ASB1!&fields=close&no_404=true', want='close',
      headers={'Origin': 'https://wingtrade.github.io'})

print('\n【三】新浪（6 个独有品种的最新价 + 基准价现算的命门）')
probe('hq.sinajs.cn 不带 Referer（预期 403）', 'https://hq.sinajs.cn/list=hf_GC')
probe('hq.sinajs.cn 带 Referer', 'https://hq.sinajs.cn/list=hf_GC', headers={'Referer': 'https://finance.sina.com.cn'}, want='hq_str_hf_GC')
probe('stock2 分时 JSONP（★补档命门）', 'https://stock2.finance.sina.com.cn/futures/api/openapi.php/GlobalFuturesService.getGlobalFuturesMinLine?symbol=GC&callback=cbNoProxy', want='minLine_1d')
probe('stock2 分时 无 callback', 'https://stock2.finance.sina.com.cn/futures/api/openapi.php/GlobalFuturesService.getGlobalFuturesMinLine?symbol=GC', want='minLine_1d')
probe('stock2 日K（换月检测用）', 'https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/GlobalFuturesService.getGlobalFuturesDailyKLine?symbol=GC', want='"close"')

print('\n【四】Cloudflare 中转双通道（6 品种准实时）')
probe('pages.dev 主通道（★）', 'https://sina-hq.pages.dev/?list=hf_RS,hf_CT', want='hq_str_hf_RS')
probe('pages.dev 首页', 'https://sina-hq.pages.dev/', want='html')
probe('workers.dev 备通道', 'https://forexfutures.jonsen.workers.dev/?list=hf_RS', want='hq_str_hf_RS', timeout=10)

print('\n【五】无代理直连的证书有效性（之前报"已过期"，怀疑是代理假象）')
for h in ['wingtrade.github.io', 'sina-hq.pages.dev', 'hq.sinajs.cn', 'stock2.finance.sina.com.cn', 'qt.gtimg.cn']:
    print('  %-32s %s' % (h, cert_of(h)))
print('  %-32s %s' % ('forexfutures.jonsen.workers.dev', cert_of('forexfutures.jonsen.workers.dev')))

print('\n【六】国内直连延迟参考（决定 15 秒轮询是否够用）')
for nm, u in [('腾讯行情', 'https://qt.gtimg.cn/q=hf_GC'),
              ('stock2 分时', 'https://stock2.finance.sina.com.cn/futures/api/openapi.php/GlobalFuturesService.getGlobalFuturesMinLine?symbol=GC'),
              ('pages.dev 中转', 'https://sina-hq.pages.dev/?list=hf_RS')]:
    ts = []
    for _ in range(3):
        t0 = time.time()
        try:
            NOPROXY.open(urllib.request.Request(u, headers={'User-Agent': UA}), timeout=15).read()
            ts.append((time.time() - t0) * 1000)
        except Exception:
            ts.append(float('nan'))
        time.sleep(0.4)
    print('  %-16s %s' % (nm, '  '.join('%.0fms' % t for t in ts)))
print('\n复测结束')
