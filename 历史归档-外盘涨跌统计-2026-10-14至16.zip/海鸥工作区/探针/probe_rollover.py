# -*- coding: utf-8 -*-
"""换月机制实证：为"更好的换月检测方案"收集证据。

① 拉每个品种的日K（最近 20 根），算相邻跳空 |今开 − 昨收| / 昨收，
   打印 > 0.8% 的位置 —— 这些就是【候选换月点】（主连换月必然留下跳空）。
② 拉快照，打印全部字段 + 与日K今天那根对照，确认哪个字段是"昨结"、哪个是"今开"。
③ 观察：日K在换月处跳空 → 说明新浪主连日K【未做后向调整】，不能用它做连续涨跌幅；
   反之若不跳空（被拼接调整过），那它就是干净的连续源。
"""
import json, re, ssl, time, urllib.request

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
OPENER = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))

DK = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/'
      'GlobalFuturesService.getGlobalFuturesDailyKLine?symbol={sym}')

SYMS = [
    ('WTI原油', 'CL'), ('布伦特原油', 'OIL'), ('美黄金', 'GC'), ('美白银', 'SI'),
    ('美铜', 'HG'), ('美燃油', 'HO'), ('美国天然气', 'NG'), ('美大豆', 'S'),
    ('美豆粕', 'SM'), ('美豆油', 'BO'), ('美原糖', 'RS'), ('美棉花', 'CT'),
    ('马棕油', 'FCPO'), ('新加坡铁矿石', 'FEF'), ('日橡胶', 'RSS3'),
    ('伦铝', 'AHD'), ('伦铜', 'CAD'), ('伦铅', 'PBD'),
]


def get(url, timeout=25, headers=None):
    h = {'User-Agent': UA}
    if headers:
        h.update(headers)
    return OPENER.open(urllib.request.Request(url, headers=h), timeout=timeout).read()


print('=' * 118)
print('① 主连日K的相邻跳空（候选换月点）· 本地时间 %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
print('=' * 118)
print('%-12s %s' % ('品种', '最近 20 根里 |今开 − 昨收| / 昨收 > 0.8% 的位置'))
print('-' * 118)

allgaps = {}
for name, sym in SYMS:
    try:
        t = get(DK.format(sym=sym)).decode('utf-8', 'replace')
        m = re.search(r'\((\[.*\])\)', t, re.S)
        arr = json.loads(m.group(1))[-21:] if m else []
    except Exception as e:
        print('%-12s 失败 %s' % (name, type(e).__name__))
        continue
    hits = []
    for i in range(1, len(arr)):
        try:
            pc = float(arr[i - 1]['close'])
            op = float(arr[i]['open'])
            if pc <= 0:
                continue
            g = (op - pc) / pc
            if abs(g) > 0.008:
                hits.append((arr[i]['date'], '%+.2f%%' % (g * 100), arr[i - 1]['close'], op))
        except Exception:
            pass
    allgaps[name] = hits
    txt = ' ｜ '.join('%s %s (昨收 %s→今开 %s)' % h for h in hits) if hits else '（无 >0.8% 的跳空）'
    print('%-12s %s' % (name, txt))
    time.sleep(0.3)

print()
print('=' * 118)
print('② 快照字段全貌（挑 3 个品种，与日K今天那根对照）')
print('=' * 118)
for name, sym in [('WTI原油', 'CL'), ('美燃油', 'HO'), ('美原糖', 'RS')]:
    try:
        raw = get('https://hq.sinajs.cn/list=hf_%s' % sym,
                  headers={'Referer': 'https://finance.sina.com.cn'}).decode('gbk', 'replace')
        m = re.search(r'"([^"]*)"', raw)
        f = m.group(1).split(',') if m else []
        print('%-10s 快照字段: %s' % (name, json.dumps(f, ensure_ascii=False)))
        t = get(DK.format(sym=sym)).decode('utf-8', 'replace')
        mm = re.search(r'\((\[.*\])\)', t, re.S)
        arr = json.loads(mm.group(1)) if mm else []
        if arr:
            print('%-10s 日K今天: %s' % ('', json.dumps(arr[-1], ensure_ascii=False)))
            if len(arr) > 1:
                print('%-10s 日K昨天close: %s' % ('', arr[-2]['close']))
    except Exception as e:
        print('%-10s 失败 %s %s' % (name, type(e).__name__, str(e)[:60]))
    time.sleep(0.35)
