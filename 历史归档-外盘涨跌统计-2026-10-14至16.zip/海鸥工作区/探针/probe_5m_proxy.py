# -*- coding: utf-8 -*-
"""探针 3：
 A) 逐品种 5MLine 覆盖（能否回溯跨时段历史节点 → 决定基准价能否完全前端现算）
 B) 两条 Cloudflare 中转通道健康巡检
 C) 换月检测所需的日K体积评估
只读、低频。
"""
import json, re, sys, time, urllib.request, urllib.error

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36'
FIVE = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
        'GlobalFuturesService.getGlobalFutures5MLine?symbol={sym}')
DAILYK = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/'
          'GlobalFuturesService.getGlobalFuturesDailyKLine?symbol={sym}')
PROXIES = ['https://sina-hq.pages.dev/?list=hf_RS,hf_CT',
           'https://forexfutures.jonsen.workers.dev/?list=hf_RS,hf_CT']

SYMS = ['CL', 'OIL', 'GC', 'SI', 'XAG', 'AHD', 'ZSD', 'NID', 'SND', 'HG',
        'CAD', 'PBD', 'HO', 'NG', 'S', 'SM', 'BO', 'RS', 'CT', 'FCPO', 'FEF', 'RSS3']


def get(url, timeout=25, headers=None):
    h = {'User-Agent': UA}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), dict(r.headers)


print('== A. 5MLine（1 分钟粒度 × 5 日）覆盖 ==')
print('sym    | 天数 | 每日点数(末3天) | 日期区间 | 能否回溯昨日节点')
print('-' * 100)
ok5 = []
for sym in SYMS:
    try:
        body, _ = get(FIVE.format(sym=sym))
        o = json.loads(body.decode('utf-8', errors='replace'))
        arr = ((o.get('result') or {}).get('data') or {}).get(sym)
        if not isinstance(arr, list) or not arr:
            print(f'{sym:<6} | 无数据')
            continue
        days = []
        sizes = []
        for x in arr:
            if isinstance(x, list) and x and isinstance(x[0], list):
                days.append(x[0][0])
                sizes.append(len(x))
        usable = sizes and max(sizes) > 100
        if usable:
            ok5.append(sym)
        print(f'{sym:<6} | {len(arr):>4} | {sizes[-3:]} | {days[0] if days else "-"} ~ {days[-1] if days else "-"} | '
              f'{"可用" if usable else "不可用"}')
    except Exception as e:
        print(f'{sym:<6} | FAIL {type(e).__name__}: {e}')
    time.sleep(0.35)

print(f'\n5MLine 可用品种({len(ok5)}/{len(SYMS)}): {ok5}')

print('\n== B. 中转通道健康巡检 ==')
for p in PROXIES:
    try:
        body, hd = get(p, timeout=15)
        txt = body.decode('gbk', errors='replace')
        acao = hd.get('Access-Control-Allow-Origin') or hd.get('access-control-allow-origin')
        got = re.findall(r'hq_str_(\w+)="([^"]{0,40})', txt)
        print(f'{p}\n   HTTP200 len={len(body)} ACAO={acao} 数据={got}')
    except urllib.error.HTTPError as e:
        print(f'{p}\n   HTTPError {e.code}')
    except Exception as e:
        print(f'{p}\n   FAIL {type(e).__name__}: {e}')

print('\n== C. 日K 体积（换月检测成本）==')
for sym in ('HO', 'CL', 'GC', 'XAG'):
    try:
        body, _ = get(DAILYK.format(sym=sym))
        print(f'{sym:<4} DailyKLine {len(body)/1024:.0f} KB')
    except Exception as e:
        print(f'{sym:<4} FAIL {type(e).__name__}')
    time.sleep(0.3)
print('== done ==')
