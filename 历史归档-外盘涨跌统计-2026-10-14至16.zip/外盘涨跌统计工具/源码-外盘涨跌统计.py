# -*- coding: utf-8 -*-
"""
外盘期货涨跌统计工具 v1.7
============================
v1.7（2026-10-14）：
  - 富时A50/标准普尔/道琼工业/纳斯达克 四个股指品种：参考时点固定为「最近交易日的 15:00 收盘」，
    不再归入夜盘 23:00 组。国内对应股指期货 9:30 开盘、无夜盘，故只对比 15:00 之后的涨跌幅。
v1.6（2026-10-14）：
  - 随机混合节奏拉取：参考价 K 线由"固定并发"改为"并发 1~2 次 + 串行 1~2 次（间隔 1s + ≤0.5s 随机抖动）"
    随机交替循环直到拉完——打乱固定节拍、模拟人工浏览，规避东财对周期流量的风控。
  - 控制台进度条：运行全过程底部显示 1%~100% 从左往右的进度条，缓解等待感。
v1.5（2026-10-14 早）：
  - 双源容灾 + 状态灯：东财限流时不再闪退，改用"本地缓存K线 → 新浪"逐级兜底，兜不住的标"缺"；
    图片右上角显示东财/新浪两盏状态灯（绿=正常，红=异常）。
  - K线本地缓存：每次成功拉取后落盘 kline_cache.json（exe 同目录），下次运行先读缓存；
    限流时用缓存里的K线算参考价（运行越勤缓存越新、兜底越准）。
  - 恢复限流间隔：并发 4 线程无间隔 → 并发 2 线程 + 每请求 1.0s 间隔，避免再次触发东财限流。
v1.4（2026-10-13 深夜）：
  - 提速：参考价 24 个品种的 5 分钟 K 线由"串行 + 2.2 秒间隔"改为"并发 4 线程、无间隔"，
    单轮从约 65 秒降到约 10 秒。
v1.3（2026-10-13 深夜）：
  - 美铜双源单位修正：新浪 hf_HG 是"美分/磅"、东财 HG00Y 是"美元/磅"，差 100 倍，
    之前双源交叉验证把美铜误判为"偏差>0.5%"标 ※；现已把新浪美铜 ÷100 对齐美元/磅（误报消除）。
v1.2（2026-10-13 晚）：
  - 日橡胶东财源修正：176.5162 实为日股"朝日橡胶"股票（报810），改为 111.JRU00Y（日橡胶当月连续）
  - 日间模式 WTI/布伦特原油合并为单行（原 23:00/02:30 双行仅隔夜模式保留）
  - 图片直接输出到 exe 同目录（不再建"输出"子目录），出图尺寸放大到 1.5x
  - 控制台窗口标题显示版本号
双击运行：按国内商品期货最近的停盘时点（日盘 15:00 收盘，或夜盘 23:00/01:00/02:30 收盘），
取国际期货品种从那时到当前的涨跌幅，生成样图风格的 PNG 表格并自动打开。

模式判定（北京时间）：
  - 交易日 15:00~23:00 → 日间模式（参考 = 当日 15:00）
  - 其余时间（含周末、凌晨、盘中） → 隔夜模式（参考 = 各组最近的夜盘收盘时点）
  - 参数 --day / --night 可强制指定模式

夜盘分组（对应国内商品夜盘收盘时间）：
  02:30 组：美黄金 美白银 伦敦银现货 WTI原油 布伦特原油（沪金沪银、INE原油）
  01:00 组：美铜 伦铜 伦铝 伦镍 伦锡 伦锌 伦铅（沪有色系）
  23:00 组：其余普通商品（农产品/铁矿/橡胶/燃油/天然气/A50）

交易日历与夜盘是否存在：用新浪内盘沪铜主连（CU0）5分钟K线逐日核实，不依赖本地节假日表。
周五夜盘的有色/贵金属参考时点自动落在周六凌晨（夜盘归属哪一晚、收盘就在哪一晚的次日）。

数据通道（每轮总请求 ~26 次，远低于东财 60~70 次/小时限流线）：
  当前价：东财批量快照 1 次 + 新浪批量快照 1 次（双源交叉验证，偏差>0.5% 标注）
  参考价：东财 5 分钟K（每品种 1 次，一次同时覆盖 15:00 与夜盘收盘两个时点）
  特例：  伦敦银现货=新浪5日分时；新加坡铁矿石=新浪当日分时，
          参考点在分时覆盖外（昨晚/周五的23:00）时降级用新浪FEF日K开盘价
          （SGX日界=北京时间20:00，开盘价≈前晚20:00后首笔，口径比23:00早约3小时）
  股指：  标普500/道琼工业/纳斯达克 = 东财全球指数（100.SPX/DJIA/NDX，5分钟K为北京时间）
"""
import os, sys, json, time, re, random
import urllib.request, urllib.parse
from datetime import datetime, timedelta

# ---------------- 控制台中文 ----------------
if os.name == 'nt':
    os.system('chcp 65001 >nul 2>&1')
    os.system('title 外盘涨跌统计工具 v1.7')
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

# ---------------- 品种表 ----------------
# (显示名, 夜盘组, 东财secid, 新浪hf代码)
# 原油双档显示：WTI/布伦特各占两行（23:00 对应燃油/沥青，02:30 对应 INE 原油），用户 2026-10-13 定
VARIETIES = [
    ('WTI原油(23:00)',    'M23',   '102.CL00Y',  'hf_CL'),
    ('WTI原油(02:30)',    'M0230', '102.CL00Y',  'hf_CL'),
    ('布伦特原油(23:00)',  'M23',   '112.B00Y',   'hf_OIL'),
    ('布伦特原油(02:30)',  'M0230', '112.B00Y',   'hf_OIL'),
    ('美黄金',       'M0230', '101.GC00Y',  'hf_GC'),
    ('美白银',       'M0230', '101.SI00Y',  'hf_SI'),
    ('伦敦银现货',    'M0230', None,         'hf_XAG'),
    ('伦铝',        'M01',   '109.LALT',   'hf_AHD'),
    ('伦锌',        'M01',   '109.LZNT',   'hf_ZSD'),
    ('伦镍',        'M01',   '109.LNKT',   'hf_NID'),
    ('伦锡',        'M01',   '109.LTNT',   'hf_SND'),
    ('美铜',        'M01',   '101.HG00Y',  'hf_HG'),
    ('伦铜',        'M01',   '109.LCPT',   'hf_CAD'),
    ('伦铅',        'M01',   '109.LLDT',   None),
    ('美燃油',       'M23',   '102.HO00Y',  'hf_HO'),
    ('美国天然气',    'M23',   '102.NG00Y',  'hf_NG'),
    ('美大豆',       'M23',   '103.ZS00Y',  'hf_S'),
    ('美黄豆粉',     'M23',   '103.ZM00Y',  'hf_SM'),
    ('美黄豆油',     'M23',   '103.ZL00Y',  'hf_BO'),
    ('美原糖',       'M23',   '108.SB00Y',  'hf_RS'),
    ('美国棉花',     'M23',   '108.CT00Y',  'hf_CT'),
    ('马棕油',       'M23',   '110.MPM00Y', 'hf_FCPO'),
    ('新加坡铁矿石',  'M23',   None,         'hf_FEF'),
    ('日橡胶',       'M23',   '111.JRU00Y', 'hf_RSS3'),   # 修正2026-10-13：原176.5162是日股"朝日橡胶"股票，非期货
    ('富时A50',      'M23',   '100.XIN9',   None),
    # 2026-10-13 追加：美股三大股指（东财全球指数，单源，无新浪交叉验证）
    ('标准普尔',     'M23',   '100.SPX',    None),
    ('道琼工业',     'M23',   '100.DJIA',   None),
    ('纳斯达克',     'M23',   '100.NDX',    None),
]
GROUP_CLOSE = {'M23': (23, 0), 'M01': (1, 0), 'M0230': (2, 30)}
GROUPS = ['M23', 'M01', 'M0230']

# 股指品种（富时A50/标普/道琼/纳斯达克）：国内对应股指期货 9:30 开盘、无夜盘，
# 参考时点固定为「最近交易日的 15:00 收盘」，不参与夜盘分组（v1.7）。
INDEX_SECIDS = {'100.XIN9', '100.SPX', '100.DJIA', '100.NDX'}

# ---------------- HTTP ----------------
SINA_HEADERS = {'Referer': 'https://finance.sina.com.cn',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
EM_HEADERS = {'Referer': 'https://quote.eastmoney.com',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

def http_get(url, headers, enc='utf-8', timeout=15):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode(enc, errors='replace')

EM_CALLS = 0
def em_get(url, timeout=15, sleep_sec=2.2):
    """东财请求：默认间隔 2.2s 限流保护；sleep_sec=0 关闭间隔（并发场景用）"""
    global EM_CALLS
    EM_CALLS += 1
    if sleep_sec:
        time.sleep(sleep_sec)
    return http_get(url, EM_HEADERS, timeout=timeout)

def em_get_retry(url, tries=2, sleep_sec=2.2):
    last_err = None
    for i in range(tries):
        try:
            return em_get(url, sleep_sec=sleep_sec)
        except Exception as e:
            last_err = e
            if i < tries - 1:      # 还有重试机会才等待，最后一次失败立即抛出（限流时快速兜底）
                time.sleep(5)
    raise last_err

# ---------------- 快照（当前价） ----------------
def em_snapshot(secids):
    """东财批量快照 → {code: {'last':float|None, 'prev_settle':float|None}}"""
    out = {}
    u = ('https://push2.eastmoney.com/api/qt/ulist.np/get?secids=' + ','.join(secids)
         + '&fields=f2,f12,f14,f18&fltt=2')
    d = json.loads(em_get_retry(u))
    rows = (d.get('data') or {}).get('diff') or []
    for r in rows:
        code = r.get('f12')
        last = r.get('f2')
        prev = r.get('f18')
        out[code] = {
            'last': float(last) if isinstance(last, (int, float)) else None,
            'prev_settle': float(prev) if isinstance(prev, (int, float)) else None,
            'name': r.get('f14'),
        }
    return out

# 新浪 hf_ 报价口径与东财不一致的品种：新浪用"美分/磅"，东财用"美元/磅"，需 ÷100 对齐。
# 实测 2026-10-13：仅美铜一个（新浪 hf_HG=674.66 美分/磅 vs 东财 HG00Y=6.741 美元/磅）。
# 其余品种（大豆/豆油/豆粉/棉/糖 等美分口径）东财同样保持美分，无需换算。
# 注意：sina_snapshot 里 code 带 hf_ 前缀，key 必须写 hf_HG 而非 HG。
SINA_CENT_TO_DOLLAR = {'hf_HG'}

def sina_snapshot(codes):
    """新浪批量快照（GBK）→ {code: {'last':float,'prev_settle':float|None,'time':str}}"""
    out = {}
    if not codes:
        return out
    u = 'https://hq.sinajs.cn/list=' + ','.join(codes)
    txt = http_get(u, SINA_HEADERS, enc='gbk')
    for line in txt.strip().split('\n'):
        m = re.search(r'hq_str_(\w+)="([^"]*)"', line)
        if not m:
            continue
        code, body = m.group(1), m.group(2)
        f = body.split(',')
        if len(f) > 13 and f[0]:
            try:
                prev = float(f[7]) if f[7] else None
            except ValueError:
                prev = None
            last = float(f[0])
            if code in SINA_CENT_TO_DOLLAR:
                last /= 100.0
                if prev is not None:
                    prev /= 100.0
            out[code] = {'last': last, 'prev_settle': prev,
                         'time': f[6], 'date': f[12]}
    return out

# ---------------- K线（参考价） ----------------
def em_kline5(secid, sleep_sec=2.2):
    """东财5分钟K（最近约7天，时间戳=bar结束时刻，北京时间）→ [(datetime, close)]"""
    u = ('https://push2his.eastmoney.com/api/qt/stock/kline/get?secid=' + secid
         + '&fields1=f1,f2,f3&fields2=f51,f52,f53,f54,f55,f56&klt=5&fqt=0'
           '&beg=0&end=20500101&lmt=300')
    d = json.loads(em_get_retry(u, tries=1, sleep_sec=sleep_sec))   # 不重试：失败立即返回，靠缓存/新浪兜底
    ks = (d.get('data') or {}).get('klines') or []
    out = []
    for k in ks:
        p = k.split(',')
        try:
            out.append((datetime.strptime(p[0], '%Y-%m-%d %H:%M'), float(p[2])))
        except (ValueError, IndexError):
            continue
    return out

# K线缓存：原油双行共用同一 secid，只请求一次；启动时预加载本地缓存做限流兜底
KLINE_CACHE = {}

def cache_file_path():
    """K线缓存文件路径（exe 同目录 / 源码同目录）"""
    if getattr(sys, 'frozen', False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, 'kline_cache.json')

def load_kline_cache():
    """读本地缓存 → {secid: [(datetime, close), ...]}，失败返回空 dict"""
    try:
        with open(cache_file_path(), 'r', encoding='utf-8') as f:
            raw = json.load(f)
        out = {}
        for secid, bars in raw.items():
            try:
                out[secid] = [(datetime.strptime(d, '%Y-%m-%d %H:%M'), float(c)) for d, c in bars]
            except (ValueError, TypeError):
                continue
        return out
    except Exception:
        return {}

def save_kline_cache():
    """把 KLINE_CACHE 里非空的 K 线落盘（成功拉取的才写）"""
    try:
        out = {}
        for secid, bars in KLINE_CACHE.items():
            if bars:
                out[secid] = [[dt.strftime('%Y-%m-%d %H:%M'), c] for dt, c in bars]
        with open(cache_file_path(), 'w', encoding='utf-8') as f:
            json.dump(out, f, ensure_ascii=False)
    except Exception:
        pass

def get_kline5(secid):
    if secid not in KLINE_CACHE:
        KLINE_CACHE[secid] = em_kline5(secid)
    return KLINE_CACHE[secid]

def get_klines_concurrent(secids):
    """V1.6：随机混合节奏拉取 5 分钟 K 线。
    每次随机选「并发 1~2 个」或「串行 1~2 个」，串行每请求间隔 1s + ≤0.5s 随机抖动，
    交替循环直到拉完——打乱固定节拍、模拟人工浏览，规避东财对周期流量的风控。
    成功非空 → 覆盖 KLINE_CACHE；失败/空 → 保留旧缓存（无缓存才标空防重复请求）。
    返回失败品种数。"""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    todo = list(secids)
    if not todo:
        return 0
    fail = 0

    def commit(s, bars):
        nonlocal fail
        if bars:
            KLINE_CACHE[s] = bars
        else:
            fail += 1
            if s not in KLINE_CACHE:      # 无缓存才标空，避免 get_kline5 重复请求
                KLINE_CACHE[s] = []

    idx, n = 0, len(todo)
    with ThreadPoolExecutor(max_workers=2) as ex:
        while idx < n:
            batch = min(random.randint(1, 2), n - idx)
            if random.choice((True, False)):
                # 并发 batch 个（1~2 个同时发）
                futs = {ex.submit(em_kline5, s, 0): s for s in todo[idx:idx + batch]}
                idx += batch
                for fut in as_completed(futs):
                    s = futs[fut]
                    try:
                        commit(s, fut.result())
                    except Exception:
                        commit(s, None)
            else:
                # 串行 batch 个，每个间隔 1s + 抖动 0~0.5s
                for _ in range(batch):
                    s = todo[idx]
                    idx += 1
                    time.sleep(1.0 + random.uniform(0, 0.5))
                    try:
                        commit(s, em_kline5(s, sleep_sec=0))
                    except Exception:
                        commit(s, None)
    return fail

def sina_5day_minline(symbol):
    """新浪5日分时（1分钟×5交易日）→ [(datetime, price)] 升序"""
    u = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
         'GlobalFuturesService.getGlobalFutures5MLine?symbol=' + symbol)
    txt = http_get(u, SINA_HEADERS)
    obj = None
    s = txt.lstrip()
    if s.startswith('{'):
        obj = json.loads(s)
    else:
        m = re.search(r'\((\{.*\})\)', txt, re.S)
        if m:
            obj = json.loads(m.group(1))
    data = ((obj or {}).get('result') or {}).get('data') or {}
    days = data.get(symbol) if isinstance(data, dict) else None
    out = []
    if not isinstance(days, list):
        return out
    for day in days:
        if not isinstance(day, list) or not day:
            continue
        try:
            base = datetime.strptime(day[0][0], '%Y-%m-%d')
        except (ValueError, IndexError, TypeError):
            continue
        cur_date, prev_t = base, None
        for i, e in enumerate(day):
            if i == 0:
                # 首行结构不定：找到 HH:MM 形态的时间字段，价格取其下一个字段
                tstr = price = None
                for j, f in enumerate(e):
                    if re.match(r'^\d{2}:\d{2}$', str(f)):
                        tstr = f
                        price = e[j + 1] if j + 1 < len(e) else None
                        break
                if tstr is None or price is None:
                    continue
            elif len(e) >= 2:
                tstr, price = e[0], e[1]
            else:
                continue
            try:
                hh, mm = int(tstr[:2]), int(tstr[3:5])
                p = float(price)
            except (ValueError, IndexError):
                continue
            if prev_t and tstr < prev_t:      # 跨日（23:59 → 00:00）
                cur_date = cur_date + timedelta(days=1)
            prev_t = tstr
            out.append((cur_date.replace(hour=hh, minute=mm), p))
    out.sort(key=lambda x: x[0])
    return out

def sina_minline_today(symbol):
    """新浪当日分时 → [(datetime, price)]（FEF 日间参考用）"""
    u = ('https://stock2.finance.sina.com.cn/futures/api/openapi.php/'
         'GlobalFuturesService.getGlobalFuturesMinLine?symbol=' + symbol
         + '&callback=var%20d=')
    txt = http_get(u, SINA_HEADERS)
    m = re.search(r'\((\{.*\})\)', txt, re.S)
    if not m:
        return []
    obj = json.loads(m.group(1))
    data = (obj.get('result') or {}).get('data') or {}
    arr = data.get('minLine_1d') if isinstance(data, dict) else None
    out = []
    if not isinstance(arr, list) or not arr:
        return out
    day = arr[0][0] if isinstance(arr[0], list) and len(arr[0]) >= 10 else None
    for i, e in enumerate(arr):
        if not isinstance(e, list) or len(e) < 2:
            continue
        # 首元素结构特殊：[日期, 昨结, 代码, '', 时间, 当前价, ...]；其余：[时间, 价, ...]
        pidx = 5 if (i == 0 and len(e) >= 6) else 1
        try:
            p = float(e[pidx])
        except (ValueError, IndexError):
            continue
        # 元素末位一般带完整时间戳；无则用当日 + e[0] 时间
        ts = e[-1] if isinstance(e[-1], str) and re.match(r'^\d{4}-\d{2}-\d{2} ', e[-1]) else None
        if ts:
            out.append((datetime.strptime(ts[:16], '%Y-%m-%d %H:%M'), p))
        elif day and re.match(r'^\d{2}:\d{2}$', str(e[0])):
            hh, mm = int(e[0][:2]), int(e[0][3:5])
            out.append((datetime.strptime(day, '%Y-%m-%d').replace(hour=hh, minute=mm), p))
    out.sort(key=lambda x: x[0])
    return out

FEF_DAILYK_CACHE = None
def sina_fef_dailyk():
    """新浪FEF日K（必须走jsonp主机）→ [{'date','open','high','low','close',...}] 升序。
    当日根实时滚动；open=交易日起点（前一晚20:00后首笔，SGX日界=北京时间20:00）。"""
    global FEF_DAILYK_CACHE
    if FEF_DAILYK_CACHE is None:
        u = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20d=/'
             'GlobalFuturesService.getGlobalFuturesDailyKLine?symbol=FEF')
        txt = http_get(u, SINA_HEADERS)
        m = re.search(r'\((\[.*\])\)', txt, re.S)
        FEF_DAILYK_CACHE = json.loads(m.group(1)) if m else []
    return FEF_DAILYK_CACHE

def fef_ref_from_dailyk(ref_dt):
    """FEF降级基准：找 ref_dt 所属的FEF交易日（区间=[前一交易日date的20:00, 本根date的20:00)），
    返回 (该根开盘价, 实际基准时点=区间起点)。跨周末时区间自动拉长（周五20:00→周一20:00）。
    例：周二白天运行、ref=周一23:00 → 命中交易日"周二"，open=周一20:00后首笔。"""
    dk = sina_fef_dailyk()
    if not dk or ref_dt is None:
        return None, None
    prev_end = None
    for k in dk:
        d = datetime.strptime(k['date'], '%Y-%m-%d')
        end = d.replace(hour=20)
        start = prev_end if prev_end is not None else d - timedelta(days=1)
        if start <= ref_dt < end:
            try:
                return float(k['open']), start
            except (ValueError, KeyError, TypeError):
                return None, None
        prev_end = end
    return None, None

def get_night_calendar():
    """新浪内盘 CU0 5分钟K → (交易日集合, 夜盘日集合)，日期均为 ISO 字符串"""
    u = ('https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20t=/'
         'InnerFuturesNewService.getFewMinLine?symbol=CU0&type=5')
    txt = http_get(u, SINA_HEADERS, enc='gbk')
    m = re.search(r'\((\[.*\])\)', txt, re.S)
    if not m:
        return set(), set()
    arr = json.loads(m.group(1))
    trade_days, night_days = set(), set()
    for e in arr:
        t = e.get('d', '') if isinstance(e, dict) else ''
        if len(t) < 16:
            continue
        day, hm = t[:10], t[11:16]
        if '09:00' <= hm <= '15:05':
            trade_days.add(day)
        if hm >= '21:00':
            night_days.add(day)
    return trade_days, night_days

# ---------------- 参考时点判定 ----------------
def decide_mode(now, trade_days):
    """交易日 15:00~23:00 → 日间；否则隔夜。日历不可用时按星期退化。"""
    today = now.date().isoformat()
    t = now.hour * 60 + now.minute
    if trade_days:
        return 'day' if (today in trade_days and 15 * 60 <= t < 23 * 60) else 'night'
    return 'day' if (now.weekday() < 5 and 15 * 60 <= t < 23 * 60) else 'night'

def night_ref_point(group, now, trade_days, night_days):
    """隔夜模式：该组最近的已收盘时点。
    返回 (datetime, 'night'|'day')；找不到返回 (None, None)。
    逻辑：夜盘收盘时点归属于"开夜盘的那一晚"（01:00/02:30 组收盘在次日凌晨）；
    该晚无夜盘（节假日）→ 回退到当晚（或凌晨时点所在日）的日盘 15:00；再往前逐日回溯。"""
    h, mi = GROUP_CLOSE[group]
    cand = now.replace(hour=h, minute=mi, second=0, microsecond=0)
    if cand > now:
        cand -= timedelta(days=1)
    for _ in range(20):
        night_day = cand.date() if h >= 21 else (cand.date() - timedelta(days=1))
        if night_day.isoformat() in night_days:
            # 该晚夜盘存在：若收盘后已有更近的日盘 15:00 收盘，则用日盘
            if h < 3:
                # 凌晨收盘(01:00/02:30)：当天的日盘 15:00
                day_close = cand.replace(hour=15, minute=0)
                if day_close <= now and cand.date().isoformat() in trade_days:
                    return day_close, 'day'
            else:
                # 当晚 23:00 收盘：次日的日盘 15:00（不是当日！）
                next_day = cand.date() + timedelta(days=1)
                next_day_close = (cand + timedelta(days=1)).replace(hour=15, minute=0)
                if next_day_close <= now and next_day.isoformat() in trade_days:
                    return next_day_close, 'day'
            return cand, 'night'
        # 该晚无夜盘：日盘 15:00 是否为最近停盘点
        day_close = cand.replace(hour=15, minute=0)
        if cand.date().isoformat() in trade_days and day_close <= now:
            return day_close, 'day'
        cand -= timedelta(days=1)
    return None, None

def index_ref_point(now, trade_days):
    """股指（富时A50/标普/道琼/纳斯达克）：最近一个交易日的 15:00 收盘。
    国内对应股指期货 9:30 开盘、无夜盘，故只对比 15:00 之后的涨跌幅。
    15:00~23:00 之间 → 今日 15:00；其余 → 回溯到最近已收盘交易日的 15:00。
    日历不可用时按星期（周一~周五）退化。"""
    cand = now.replace(hour=15, minute=0, second=0, microsecond=0)
    if cand > now:
        cand -= timedelta(days=1)
    for _ in range(20):
        ok = (cand.date().isoformat() in trade_days) if trade_days else (cand.weekday() < 5)
        if ok:
            return cand, 'day'
        cand -= timedelta(days=1)
    return None, None

def ref_price_from_bars(bars, ref_dt, max_gap_hours=14, now=None):
    """从K线取 ≤ref_dt 的最近一根收盘。返回 (price|None, status)
    max_gap_hours=14：容忍"日盘品种提前停盘"（如日橡胶 14:15 停盘后到 23:00 参考约 8.7 小时），
    同时仍能挡住跨日陈旧数据（前一天收盘距今必然超过 20 小时）。"""
    best = None
    for dt, c in bars:
        if now is not None and dt > now:
            break
        if dt <= ref_dt:
            best = (dt, c)
        else:
            break
    if best is None:
        return None, 'missing'
    if (ref_dt - best[0]) > timedelta(hours=max_gap_hours):
        # 数据源仍是活的（最近一根bar就在当下）→ 说明是市场自身休市（假日），
        # 参考时点价格没动过，用最近收盘价是真实值，不算陈旧
        feed_live = bars and (now or datetime.now()) - bars[-1][0] <= timedelta(hours=8)
        if not feed_live:
            return None, 'stale'
    return best[1], 'ok'

# ---------------- 渲染 ----------------
FONT_PATH = r'C:\Windows\Fonts\msyh.ttc'
FONT_BOLD = r'C:\Windows\Fonts\msyhbd.ttc'

C_HEADER_BG = '#1E3A5F'   # 深藏青表头
C_NAME_BG_A = '#E9EEF6'   # 品种列（偶数行）
C_NAME_BG_B = '#DEE6F2'   # 品种列（奇数行）
C_NAME_FG = '#1E3A5F'
C_ROW_A = '#FFFFFF'       # 数据区斑马纹
C_ROW_B = '#F5F8FC'
C_GRID = '#DDE3EC'        # 行分隔线
C_UP = '#D6263B'
C_DOWN = '#0B8043'
C_ZERO = '#555555'
C_MISS = '#999999'
C_TITLE = '#222222'
C_FOOT = '#999999'

def _fmt2(v, signed=False):
    if v is None:
        return '—'
    if abs(v) < 0.005:
        return '0.00'
    return (f'{v:+,.2f}' if signed else f'{v:,.2f}')

def _fmt_pct(v):
    if v is None:
        return '—'
    if abs(v) < 0.005:
        return '0.00%'
    return f'{v:+.2f}%'

def _center_text(d, cx, cy, text, font, fill):
    l, t, r, b = d.textbbox((0, 0), text, font=font)
    d.text((cx - (r - l) / 2 - l, cy - (b - t) / 2 - t), text, font=font, fill=fill)

def render_png(rows, mode, ref_desc_lines, gen_time, out_path, em_ok=True, sina_ok=True):
    from PIL import Image, ImageDraw, ImageFont
    S = 2
    W, ROW_H, HEAD_H, TITLE_H, FOOT_H, MARGIN = 840, 48, 46, 64, 64, 20
    COLS = [190, 130, 130, 124, 118, 108]     # 名称/收盘/最新/涨跌/涨跌幅/时间区间
    n = len(rows)
    H = TITLE_H + HEAD_H + n * ROW_H + FOOT_H
    img = Image.new('RGB', (W * S, H * S), '#FFFFFF')
    dr = ImageDraw.Draw(img)
    f_title = ImageFont.truetype(FONT_BOLD, 21 * S)
    f_head = ImageFont.truetype(FONT_BOLD, 16 * S)
    f_cell = ImageFont.truetype(FONT_PATH, 16 * S)
    f_span = ImageFont.truetype(FONT_PATH, 12 * S)
    f_foot = ImageFont.truetype(FONT_PATH, 11 * S)
    f_lamp = ImageFont.truetype(FONT_PATH, 13 * S)

    xs = [MARGIN]
    for w in COLS:
        xs.append(xs[-1] + w)

    # 标题（v1.5：隔夜标题缩短，为右上角状态灯让位；分组说明脚注已体现）
    title = '对比15:00涨跌统计（日间）' if mode == 'day' else '隔夜涨跌统计'
    _center_text(dr, W * S / 2, TITLE_H * S / 2, title, f_title, C_TITLE)

    # 右上角状态灯：东财 / 新浪 各一盏，绿=正常 红=异常（v1.5）
    lamp_cy = TITLE_H * S // 2
    dot_r = 6 * S
    gap = 16 * S
    x = W * S - 22 * S                       # 从右往左排：新浪● 东财●
    for label, ok in [('新浪', sina_ok), ('东财', em_ok)]:
        l, t, r, b = dr.textbbox((0, 0), label, font=f_lamp)
        tw = r - l
        color = C_DOWN if ok else C_UP        # 绿=正常(C_DOWN) 红=异常(C_UP)
        dot_cx = x - dot_r
        dr.ellipse([dot_cx - dot_r, lamp_cy - dot_r, dot_cx + dot_r, lamp_cy + dot_r], fill=color)
        txt_x = dot_cx - dot_r - 6 * S - tw
        dr.text((txt_x, lamp_cy - (b - t) / 2 - t), label, font=f_lamp, fill='#555555')
        x = txt_x - gap

    heads = ['品种名称', '收盘价', '最新价', '对比涨跌', '涨跌幅', '时间区间']
    hy = TITLE_H * S
    dr.rectangle([xs[0] * S, hy, xs[-1] * S, (TITLE_H + HEAD_H) * S], fill=C_HEADER_BG)
    for i, htxt in enumerate(heads):
        _center_text(dr, (xs[i] + xs[i + 1]) / 2 * S, (TITLE_H + HEAD_H / 2) * S,
                     htxt, f_head, '#FFFFFF')

    for ri, row in enumerate(rows):
        y0 = (TITLE_H + HEAD_H + ri * ROW_H) * S
        y1 = y0 + ROW_H * S
        name_bg = C_NAME_BG_A if ri % 2 == 0 else C_NAME_BG_B
        row_bg = C_ROW_A if ri % 2 == 0 else C_ROW_B
        bgs = [name_bg, row_bg, row_bg, row_bg, row_bg, row_bg]
        for i in range(6):
            dr.rectangle([xs[i] * S, y0, xs[i + 1] * S, y1], fill=bgs[i])
        dr.line([(xs[0] * S, y1 - S), (xs[-1] * S, y1 - S)], fill=C_GRID, width=S)
        # 名称
        _center_text(dr, (xs[0] + xs[1]) / 2 * S, (y0 + y1) / 2, row['name'], f_cell, C_NAME_FG)
        # 收盘/最新
        _center_text(dr, (xs[1] + xs[2]) / 2 * S, (y0 + y1) / 2,
                     _fmt2(row['close']) if row['close'] is not None else '—',
                     f_cell, '#333333' if row['close'] is not None else C_MISS)
        _center_text(dr, (xs[2] + xs[3]) / 2 * S, (y0 + y1) / 2,
                     _fmt2(row['last']) if row['last'] is not None else '—',
                     f_cell, '#333333' if row['last'] is not None else C_MISS)
        # 涨跌 / 涨跌幅
        for col, val, signed in ((3, row['chg'], True), (4, row['pct'], False)):
            cx = (xs[col] + xs[col + 1]) / 2 * S
            txt = (_fmt2(val, signed) if col == 3 else _fmt_pct(val))
            if val is None:
                color, txt = C_MISS, '—'
            elif abs(val) < 0.005:
                color = C_ZERO
            else:
                color = C_UP if val > 0 else C_DOWN
            suffix = ' ※' if (row.get('flag') and col == 4) else ''
            _center_text(dr, cx, (y0 + y1) / 2, txt + suffix, f_cell, color)
        # 时间区间（上行=参考起点，下行=当前时刻）
        cy = (y0 + y1) / 2
        cx6 = (xs[5] + xs[6]) / 2 * S
        rs = row.get('ref_show')
        l1 = f'{rs:%m.%d %H:%M}' if rs else '—'
        l2 = f'{gen_time:%m.%d %H:%M}'
        _center_text(dr, cx6, cy - 10 * S, l1, f_span,
                     '#555555' if rs else C_MISS)
        _center_text(dr, cx6, cy + 10 * S, l2, f_span, '#555555')

    # 脚注
    fy = (TITLE_H + HEAD_H + n * ROW_H) * S
    dr.text((MARGIN * S, fy + 6 * S), '不构成投资建议｜数据可能有延迟或错误，请谨慎参考',
            font=f_foot, fill=C_FOOT)
    dr.text((MARGIN * S, fy + 26 * S), ref_desc_lines, font=f_foot, fill=C_FOOT)
    dr.rectangle([0, 0, W * S - 1, H * S - 1], outline='#B9C4D4', width=S)

    img = img.resize((int(W * 1.5), int(H * 1.5)), Image.LANCZOS)   # 1.5x 出图，打开更大更清晰（2026-10-13）
    img.save(out_path, 'PNG')
    return out_path

# ---------------- 主流程 ----------------
def print_progress(pct, label=''):
    """控制台进度条（\r 刷新同一行）：label [████░░░] 45%（V1.6）"""
    width = 28
    pct = max(0, min(100, int(pct)))
    filled = int(width * pct / 100)
    bar = '█' * filled + '░' * (width - filled)
    sys.stdout.write(f'\r  {label}[{bar}] {pct:3d}%')
    sys.stdout.flush()

def build_rows(now, mode, ref_map, em_last_map, sina_last_map, args_now):
    rows, em_fail_streak, kline_fail = [], 0, 0
    total_em = sum(1 for v in VARIETIES if v[2])
    em_done = 0
    # 随机混合节奏预取参考价 K 线（v1.6：并发1~2+串行1~2随机交替，失败保留旧缓存供兜底，不再中止）
    secids = sorted({v[2] for v in VARIETIES if v[2]})
    n_fail = get_klines_concurrent(secids)
    if n_fail:
        print(f'\n    有 {n_fail} 个品种失败（改用缓存/新浪兜底）')
    total_rows = len(VARIETIES)
    for i, (name, group, secid, sina_code) in enumerate(VARIETIES):
        # 日间模式（对比今日15:00）：国内统一15点收盘，原油不再分23:00/02:30两组，
        # 只保留一行并去掉后缀；夜盘模式仍保留两组（2026-10-13 用户要求）
        if mode == 'day' and name.endswith('(02:30)') and '原油' in name:
            print_progress(30 + int((i + 1) / total_rows * 65), '取参考价')
            continue
        if mode == 'day' and name.endswith('(23:00)') and '原油' in name:
            name = name.split('(')[0]
        if secid in INDEX_SECIDS:
            ref_dt, ref_kind = ref_map.get('IDX', (None, None))
        else:
            ref_dt, ref_kind = ref_map.get(group, (None, None))
        ref_show = ref_dt                    # 时间区间列显示的起点（FEF降级时会被覆盖为实际口径）
        last = None
        flag = False
        # ---- 当前价 ----
        if secid and secid.split('.')[-1] in em_last_map:
            last = em_last_map[secid.split('.')[-1]]['last']
        if sina_code and sina_code in sina_last_map:
            s_last = sina_last_map[sina_code]['last']
            if last is None or (isinstance(last, (int, float)) and last <= 0):
                last = s_last                      # 东财休市/无效 → 新浪接管
            elif last is not None and s_last and abs(last - s_last) / s_last > 0.005:
                flag = True                        # 双源偏差 >0.5%
        # ---- 参考价 ----
        close = None
        note = ''
        if ref_dt is None:
            note = '缺'
        elif name == '伦敦银现货':
            try:
                bars = sina_5day_minline('XAG')
                close, st = ref_price_from_bars(bars, ref_dt, now=args_now)
                if st != 'ok':
                    note = '缺'
            except Exception:
                note = '缺'
        elif name == '新加坡铁矿石':
            # 第一优先：当日分时（覆盖今天07:25起的参考点：日间模式15:00、23点后运行的23:00）
            close = None
            if ref_dt is not None:
                try:
                    bars = sina_minline_today('FEF')
                    close, st = ref_price_from_bars(bars, ref_dt, max_gap_hours=10, now=args_now)
                except Exception:
                    close = None
            # 降级：参考点在昨晚/周五（分时覆盖不到）→ FEF日K开盘价（20:00日界口径）
            if close is None and ref_dt is not None:
                try:
                    close, ref_show = fef_ref_from_dailyk(ref_dt)
                except Exception:
                    close, ref_show = None, None
            if close is None:
                note = '缺'
        elif secid:
            try:
                bars = get_kline5(secid)
                close, st = ref_price_from_bars(bars, ref_dt, now=args_now)
                em_done += 1
                if st != 'ok':
                    note = '缺' if st == 'missing' else '过'
                kline_fail = 0
            except Exception as e:
                kline_fail += 1
                em_done += 1
                note = '缺'
        # ---- 涨跌 ----
        chg = pct = None
        if close is not None and last is not None and close > 0:
            chg = last - close
            pct = chg / close * 100
        rows.append({'name': name, 'close': close, 'last': last,
                     'chg': chg, 'pct': pct, 'flag': flag, 'note': note,
                     'ref_show': ref_show})
        print_progress(30 + int((i + 1) / total_rows * 65), '取参考价')
    return rows, n_fail

def main():
    t0 = time.time()
    real_now = datetime.now()
    args = sys.argv[1:]
    # 测试钩子：--now "YYYY-MM-DD HH:MM" 模拟当前时间
    args_now = real_now
    if '--now' in args:
        i = args.index('--now')
        args_now = datetime.strptime(args[i + 1], '%Y-%m-%d %H:%M')

    print('=' * 56)
    print('外盘期货涨跌统计工具 v1.7（股指15:00参考 / 随机混合节奏防限流 / 双源容灾+状态灯 / K线缓存兜底）')
    print(f'当前时间: {args_now:%Y-%m-%d %H:%M:%S}（{"真实" if args_now == real_now else "模拟"}）')
    print('=' * 56)
    print_progress(3)

    # 预加载本地 K 线缓存（限流时用缓存算参考价）
    cached = load_kline_cache()
    if cached:
        KLINE_CACHE.update(cached)
        print(f'[缓存] 已加载 {len(cached)} 个品种的历史 K 线缓存')

    print('[1/4] 获取国内交易日历（沪铜5分钟K，核实夜盘是否存在）...')
    try:
        trade_days, night_days = get_night_calendar()
        print(f'      近月交易日 {len(trade_days)} 天，夜盘日 {len(night_days)} 天')
    except Exception as e:
        print(f'      日历获取失败({e})，按星期退化判定')
        trade_days, night_days = set(), set()
    print_progress(15, '日历')

    mode = decide_mode(args_now, trade_days)
    if '--day' in args:
        mode = 'day'
    if '--night' in args:
        mode = 'night'
    print(f'[2/4] 模式: {"日间（对比今日15:00）" if mode == "day" else "隔夜"}')

    # 参考时点
    ref_map = {}
    if mode == 'day':
        dc = args_now.replace(hour=15, minute=0, second=0, microsecond=0)
        for g in GROUPS:
            ref_map[g] = (dc, 'day')
        ref_map['IDX'] = (dc, 'day')
        ref_desc = f'参考: 今日 15:00'
    else:
        for g in GROUPS:
            ref_map[g] = night_ref_point(g, args_now, trade_days, night_days)
        ref_map['IDX'] = index_ref_point(args_now, trade_days)
        parts = []
        idx_dt = ref_map['IDX'][0]
        parts.append(f'股指15:00→{idx_dt:%m-%d %H:%M}' if idx_dt else '股指:缺')
        for g in GROUPS:
            dt, kind = ref_map[g]
            parts.append(f'{GROUP_CLOSE[g][0]:02d}:{GROUP_CLOSE[g][1]:02d}→{dt:%m-%d %H:%M}' if dt else f'{g}:缺')
        ref_desc = '参考(股指15:00/有色01:00/贵金属02:30/其他23:00): ' + '  '.join(parts)
        for g in GROUPS:
            dt, _ = ref_map[g]
            print(f'      组 {g}: ' + (f'{dt:%Y-%m-%d %H:%M}' if dt else '缺失'))

    print('[3/4] 拉取当前价（东财批量 + 新浪批量，双源交叉验证）...')
    secids = sorted({v[2] for v in VARIETIES if v[2]})
    em_snap_ok = True
    try:
        em_map = em_snapshot(secids)
    except Exception as e:
        em_map = {}
        em_snap_ok = False
        print(f'      !! 东财快照失败({type(e).__name__})，当前价改用新浪')
    sina_codes = [v[3] for v in VARIETIES if v[3]]
    try:
        sina_map = sina_snapshot(sina_codes)
        sina_ok = bool(sina_map)
    except Exception as e:
        sina_map = {}
        sina_ok = False
        print(f'      !! 新浪快照失败({type(e).__name__})')
    print(f'      东财 {len(em_map)} 品种, 新浪 {len(sina_map)} 品种')
    print_progress(30, '当前价')

    print('[4/4] 逐品种取参考时点价（东财5分钟K，随机混合节奏限流保护，失败用缓存/新浪兜底）...')
    rows, n_fail = build_rows(args_now, mode, ref_map, em_map, sina_map, args_now)
    print_progress(100, '完成')
    print()

    # 数据源健康判定（用于右上角状态灯）
    em_ok = em_snap_ok and n_fail < 3
    if em_ok:
        print('      状态灯：东财 ●绿  新浪 ' + ('●绿' if sina_ok else '●红'))
    else:
        print('      状态灯：东财 ●红（限流，已兜底）  新浪 ' + ('●绿' if sina_ok else '●红'))

    # 成功拉取的 K 线落盘缓存（下次限流时兜底）
    save_kline_cache()

    # 输出
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(sys.executable)
    else:
        exe_dir = os.path.dirname(os.path.abspath(__file__))
    fname = f"外盘涨跌_{args_now:%Y%m%d_%H%M}.png"   # v1.5：文件名统一，不再带"日间/隔夜"字样
    out_path = os.path.join(exe_dir, fname)   # 图片直接放 exe 同目录（2026-10-13 用户要求，不再建"输出"子目录）
    src_desc = '东财+新浪' if em_ok else ('新浪为主+缓存' if sina_ok else '缓存')
    ref_desc_lines = ref_desc + f'｜生成: {args_now:%m-%d %H:%M}｜源: {src_desc}'
    render_png(rows, mode, ref_desc_lines, args_now, out_path, em_ok=em_ok, sina_ok=sina_ok)

    # 控制台摘要
    print('-' * 56)
    print(f'{"品种":<8}{"收盘":>10}{"最新":>10}{"涨跌幅":>9}')
    for r in rows:
        cs = f"{r['close']:,.2f}" if r['close'] is not None else '—'
        ls = f"{r['last']:,.2f}" if r['last'] is not None else '—'
        ps = f"{r['pct']:+.2f}%" if r['pct'] is not None else '—'
        warn = ' ※' if r['flag'] else ''
        print(f"{r['name']:<8}{cs:>12}{ls:>12}{ps:>10}{warn}")
    print('-' * 56)
    print(f'东财请求 {EM_CALLS} 次, 耗时 {time.time() - t0:.0f} 秒')
    print(f'已生成: {out_path}')
    try:
        os.startfile(out_path)
    except Exception:
        pass

if __name__ == '__main__':
    main()
