# -*- coding: utf-8 -*-
"""
外盘实时出图（双击版）· v1.4
================================
双击运行：
  1) 拉取云端缓存的起始价（GitHub Pages 的 data.json；档位逻辑已由云端算好，
     与网页版完全一致：10:15 / 11:30 / 15:00 / 夜盘各档）
  2) 拉取新浪实时价（本机直连 hq.sinajs.cn，不加代理也不限流）
  3) 本地计算涨跌 → 生成表格图片（保存到本程序同目录）
     文件名 = 当前时间，如 20261115-2036.png
  4) 自动打开图片

数据口径：
  起始价 = 云端按节点缓存的价（"起始时间"列即该缓存时点；含云端"昨结 换月"等修正标注）
  最新价 = 新浪准实时（滞后约 8-20 秒）
  美股 3 指数 = 收盘口径（全天固定，不随盘中波动）

v1.4：马棕油（BMD）显示窗口（与网页版 v2.9 一致）——仅工作日 10:30-23:00 显示该行；
      它 23:00 收盘、次日 10:30 才开盘，其余时段的收盘僵值无参考意义。
v1.3 新增「上证指数」临时行（与网页版 v2.7 一致）：
  仅两个窗口出现（商品 10:30 / 13:30 开盘前参考）：
    ① 10:15:00-10:29:59 → 基准 = 当日分时 10:15 点（10:15 后可用）
    ② 11:30:00-13:29:59 → 基准 = 当日分时 11:30 点（上午收盘价；11:30-13:00 休市按 0 显示）
  其余时间不显示该行。基准价走腾讯分时接口，实时价走新浪（本机直连）
"""
import os, sys, json, time, re, urllib.request
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

FONT_PATH = r'C:\Windows\Fonts\msyh.ttc'
FONT_BOLD = r'C:\Windows\Fonts\msyhbd.ttc'

# 配色（与网页版 / 老工具一致）
C_HEADER_BG = '#1E3A5F'
C_NAME_BG_A = '#E9EEF6'
C_NAME_BG_B = '#DEE6F2'
C_NAME_FG = '#1E3A5F'
C_ROW_A = '#FFFFFF'
C_ROW_B = '#F5F8FC'
C_GRID = '#DDE3EC'
C_UP = '#D6263B'
C_DOWN = '#0B8043'
C_ZERO = '#555555'
C_MISS = '#999999'
C_TITLE = '#222222'
C_FOOT = '#999999'

# 起始价数据源（按顺序尝试；取 generated_at 更新的那份，防 CDN 缓存拿到旧档位）
DATA_URLS = [
    'https://wingtrade.github.io/futures-calc/data.json?t={ts}',
    'https://cdn.jsdelivr.net/gh/WingTrade/futures-calc@main/data.json?t={ts}',
]


def app_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def fetch_data_json():
    ts = int(time.time())
    best = None
    last_err = None
    for u in DATA_URLS:
        try:
            req = urllib.request.Request(
                u.format(ts=ts),
                headers={'User-Agent': 'Mozilla/5.0', 'Cache-Control': 'no-cache'})
            with urllib.request.urlopen(req, timeout=15) as r:
                d = json.loads(r.read().decode('utf-8'))
            if not (d.get('rows') or []):
                continue
            if best is None or (d.get('generated_at') or '') > (best.get('generated_at') or ''):
                best = d
        except Exception as e:
            last_err = e
    if best is None:
        raise RuntimeError(f'起始价数据拉取失败（两个源都不通）: {last_err}')
    return best


def fetch_sina(codes):
    url = 'https://hq.sinajs.cn/list=' + ','.join(codes)
    req = urllib.request.Request(url, headers={
        'Referer': 'https://finance.sina.com.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
    with urllib.request.urlopen(req, timeout=15) as r:
        buf = r.read().decode('gbk', errors='replace')
    out = {}
    for m in re.finditer(r'hq_str_(hf_\w+)="([^"]*)"', buf):
        code, body = m.group(1), m.group(2)
        fb = body.split(',')
        if len(fb) > 12 and fb[0]:
            try:
                out[code] = float(fb[0])
            except ValueError:
                pass
    return out


# ---------------- 上证指数（A股大盘）临时行 ----------------
# 仅两个窗口出现：10:15:00-10:29:59（基准=当日 10:15 价）、11:30:00-13:29:59（基准=当日 11:30 价）
# 其余时间不显示。基准价 = 腾讯当日分时；实时价 = 新浪直连。
SSE_MINUTE_URL = 'https://web.ifzq.gtimg.cn/appstock/app/minute/query?code=sh000001'
SSE_SINA_URL = 'https://hq.sinajs.cn/list=sh000001'


def fpo_visible(now_dt):
    """v1.4: 马棕油（BMD FCPO）显示窗口（与网页版 v2.9 一致）：
    仅在工作日 10:30-23:00 显示；它 23:00 收盘、次日 10:30 才开盘，
    其余时段（含周末）的收盘僵值无参考意义。"""
    if now_dt.weekday() >= 5:          # 5=周六, 6=周日
        return False
    t = now_dt.hour * 60 + now_dt.minute
    return 630 <= t < 1380             # 10:30 ≤ t < 23:00


def sse_phase(now):
    """上证指数临时行的显示窗口：'1015' / '1130' / None（北京时间）。"""
    t = now.hour * 3600 + now.minute * 60 + now.second
    if 10 * 3600 + 15 * 60 <= t < 10 * 3600 + 30 * 60:
        return '1015'
    if 11 * 3600 + 30 * 60 <= t < 13 * 3600 + 30 * 60:
        return '1130'
    return None


def fetch_sse(phase, now):
    """上证指数行数据。返回 dict(close/last/chg/pct/ref) 或 None（今日无数据时跳过该行）。"""
    # 1) 基准价：腾讯当日分时，取目标分钟点（10:15 / 11:30）；点未生成时取 <=目标 的最近 3 分钟兜底
    req = urllib.request.Request(SSE_MINUTE_URL, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=15) as r:
        d = json.loads(r.read().decode('utf-8', errors='replace'))
    blk = ((d.get('data') or {}).get('sh000001') or {}).get('data') or {}
    arr = blk.get('data') or []
    date = str(blk.get('date') or '').replace('-', '')
    if date != now.strftime('%Y%m%d') or not arr:
        return None                                   # 周末/节假日或无数据：今天没有 A 股行情
    base, lim = None, int(phase) - 3
    for s in arr:
        p = s.split()
        if len(p) < 2:
            continue
        tk = p[0]
        if tk == phase:
            try:
                base = float(p[1])
            except ValueError:
                pass
            break
        if tk > phase:
            break
        if len(tk) == 4 and int(tk) >= lim:
            try:
                base = float(p[1])
            except ValueError:
                pass
    if base is None:
        return None
    # 2) 实时价：新浪直连（sh000001 全量格式：f[3] = 当前价）
    live = None
    try:
        req = urllib.request.Request(SSE_SINA_URL, headers={
            'Referer': 'https://finance.sina.com.cn',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
        with urllib.request.urlopen(req, timeout=10) as r:
            buf = r.read().decode('gbk', errors='replace')
        m = re.search(r'hq_str_sh000001="([^"]*)"', buf)
        if m:
            fb = m.group(1).split(',')
            if len(fb) > 3 and fb[3]:
                v = float(fb[3])
                if v > 0:
                    live = v
    except Exception:
        pass
    # 3) 11:30-13:00 午休：A 股休市，按基准显示 0
    t = now.hour * 3600 + now.minute * 60 + now.second
    if phase == '1130' and t < 13 * 3600:
        live = base
    chg = pct = None
    if live is not None:
        chg = live - base
        pct = chg / base * 100
    return {'name': '上证指数', 'close': base, 'last': live, 'chg': chg, 'pct': pct,
            'ref': date[4:6] + '-' + date[6:8] + (' 10:15' if phase == '1015' else ' 11:30')}


def _fmt2(v, signed=False):
    if v is None:
        return '—'
    if abs(v) < 0.005:
        return '0.00'
    return (f'{v:+,.2f}' if signed else f'{v:,.2f}')


def _fmt_pct(v):
    if v is None:
        return '—'
    if abs(v) < 0.005:
        return '0.00%'
    return f'{v:+.2f}%'


def _center_text(d, cx, cy, text, font, fill):
    l, t, r, b = d.textbbox((0, 0), text, font=font)
    d.text((cx - (r - l) / 2 - l, cy - (b - t) / 2 - t), text, font=font, fill=fill)


def _left_text(d, x, cy, text, font, fill):
    l, t, r, b = d.textbbox((0, 0), text, font=font)
    d.text((x - l, cy - (b - t) / 2 - t), text, font=font, fill=fill)


def _right_text(d, x, cy, text, font, fill):
    l, t, r, b = d.textbbox((0, 0), text, font=font)
    d.text((x - r, cy - (b - t) / 2 - t), text, font=font, fill=fill)


def render_png(out_rows, title, foot_line, out_path):
    from PIL import Image, ImageDraw, ImageFont
    S = 2
    ROW_H, HEAD_H, TITLE_H, FOOT_H, MARGIN = 30, 34, 52, 58, 20
    heads = ['品种名称', '起始价', '最新价', '对比涨跌', '涨跌幅', '起始时间']

    f_title = ImageFont.truetype(FONT_BOLD, 21 * S)
    f_head = ImageFont.truetype(FONT_BOLD, 16 * S)
    f_cell = ImageFont.truetype(FONT_PATH, 16 * S)
    f_cell_b = ImageFont.truetype(FONT_BOLD, 16 * S)   # 名称/涨跌列加粗（对齐网页 font-weight:600 观感）
    f_foot = ImageFont.truetype(FONT_PATH, 11 * S)

    # 列宽自适应（按实际内容宽度计算，等同网页表格的紧凑度）
    img0 = Image.new('RGB', (10, 10), '#FFFFFF')
    d0 = ImageDraw.Draw(img0)

    def tw(s, f):
        l, t, r, b = d0.textbbox((0, 0), s, font=f)
        return r - l

    def col_w(vals, head, pad, f):
        wpx = max([tw(head, f_head)] + [tw(v, f) for v in vals])
        return int(wpx / S) + pad

    COLS = [
        col_w([r['name'] for r in out_rows], heads[0], 26, f_cell_b),
        col_w([_fmt2(r['close']) for r in out_rows], heads[1], 24, f_cell),
        col_w([_fmt2(r['last']) for r in out_rows], heads[2], 24, f_cell),
        col_w([_fmt2(r['chg'], True) for r in out_rows], heads[3], 30, f_cell_b),
        col_w([_fmt_pct(r['pct']) for r in out_rows], heads[4], 30, f_cell_b),
        col_w([(r.get('ref') or '—') for r in out_rows], heads[5], 28, f_cell),
    ]
    W = MARGIN * 2 + sum(COLS)
    n = len(out_rows)
    H = TITLE_H + HEAD_H + n * ROW_H + FOOT_H
    img = Image.new('RGB', (W * S, H * S), '#FFFFFF')
    dr = ImageDraw.Draw(img)

    xs = [MARGIN]
    for w in COLS:
        xs.append(xs[-1] + w)

    _center_text(dr, W * S / 2, TITLE_H * S / 2, title, f_title, C_TITLE)

    hy = TITLE_H * S
    dr.rectangle([xs[0] * S, hy, xs[-1] * S, (TITLE_H + HEAD_H) * S], fill=C_HEADER_BG)
    for i, htxt in enumerate(heads):
        _center_text(dr, (xs[i] + xs[i + 1]) / 2 * S,
                     (TITLE_H + HEAD_H / 2) * S, htxt, f_head, '#FFFFFF')

    for ri, row in enumerate(out_rows):
        y0 = (TITLE_H + HEAD_H + ri * ROW_H) * S
        y1 = y0 + ROW_H * S
        bgs = [C_NAME_BG_A if ri % 2 == 0 else C_NAME_BG_B] + \
              [C_ROW_A if ri % 2 == 0 else C_ROW_B] * 5
        for i in range(6):
            dr.rectangle([xs[i] * S, y0, xs[i + 1] * S, y1], fill=bgs[i])
        dr.line([(xs[0] * S, y1 - S), (xs[-1] * S, y1 - S)], fill=C_GRID, width=S)
        cy = (y0 + y1) / 2
        # 版式对齐（与网页一致）：名称列左对齐、数值列右对齐、起始时间列居中
        _left_text(dr, (xs[0] + 14) * S, cy, row['name'], f_cell_b, C_NAME_FG)
        _right_text(dr, (xs[2] - 12) * S, cy,
                    _fmt2(row['close']), f_cell,
                    '#333333' if row['close'] is not None else C_MISS)
        _right_text(dr, (xs[3] - 12) * S, cy,
                    _fmt2(row['last']), f_cell,
                    '#333333' if row['last'] is not None else C_MISS)
        for col, val, signed in ((3, row['chg'], True), (4, row['pct'], False)):
            txt = _fmt2(val, signed) if col == 3 else _fmt_pct(val)
            if val is None:
                color, txt = C_MISS, '—'
            elif abs(val) < 0.005:
                color = C_ZERO
            else:
                color = C_UP if val > 0 else C_DOWN
            _right_text(dr, (xs[col + 1] - 12) * S, cy, txt, f_cell_b, color)
        _center_text(dr, (xs[5] + xs[6]) / 2 * S, cy, row.get('ref') or '—', f_cell,
                     '#555555' if row.get('ref') else C_MISS)

    fy = (TITLE_H + HEAD_H + n * ROW_H) * S
    dr.text((MARGIN * S, fy + 8 * S),
            '不构成投资建议｜数据可能有延迟或错误，请谨慎参考', font=f_foot, fill=C_FOOT)
    dr.text((MARGIN * S, fy + 30 * S), foot_line, font=f_foot, fill=C_FOOT)
    dr.rectangle([0, 0, W * S - 1, H * S - 1], outline='#B9C4D4', width=S)

    img = img.resize((int(W * 1.5), int(H * 1.5)), Image.LANCZOS)
    img.save(out_path, 'PNG')
    return out_path


def main():
    t0 = time.time()
    now = time.localtime()
    print(f'外盘实时出图 · {time.strftime("%Y-%m-%d %H:%M:%S", now)}')

    print('[1/3] 拉取云端缓存起始价 ...')
    data = fetch_data_json()
    rows = data.get('rows') or []
    title = data.get('title') or ('对比15:00涨跌统计（日间）' if data.get('mode') == 'day' else '隔夜涨跌统计')
    ref_desc = data.get('ref_desc') or ''
    print(f'      档位: {title} | 缓存时间: {data.get("generated_at")}')

    codes = []
    for r in rows:
        c = r.get('code')
        if c and c.startswith('hf_') and c not in codes:
            codes.append(c)
    print(f'[2/3] 拉取新浪实时价（{len(codes)} 个品种） ...')
    live = {}
    warn = ''
    try:
        live = fetch_sina(codes)
        print(f'      成功 {len(live)}/{len(codes)}')
    except Exception as e:
        warn = f'实时价拉取失败({type(e).__name__})，对应品种显示 —'
        print('      ' + warn)

    SHORT_NAMES = {'新加坡铁矿石': '新加坡铁矿'}   # 与网页版显示一致
    out_rows = []
    n_live = 0
    for r in rows:
        c = r.get('code')
        last = None
        if c:
            last = live.get(c)
            if c == 'hf_HG' and last is not None:
                last = last / 100.0          # 美铜：接口美分/磅 -> 美元/磅（与缓存同口径）
            if last is not None:
                n_live += 1
        else:
            last = r.get('last')             # 美股指数：缓存收盘值（全天固定）
        close = r.get('close')
        chg = pct = None
        if close is not None and last is not None and close > 0:
            chg = last - close
            pct = chg / close * 100
        nm = r.get('name') or '?'
        out_rows.append({'name': SHORT_NAMES.get(nm, nm), 'close': close, 'last': last,
                         'chg': chg, 'pct': pct, 'ref': r.get('ref')})

    # v1.4: 马棕油（BMD）显示窗口（与网页版 v2.9 一致）—— 窗口外不出该行
    now_dt = datetime.now()
    if not fpo_visible(now_dt):
        out_rows = [r for r in out_rows if r['name'] != '马棕油']

    # 上证指数（A股）临时行：仅商品 10:30 / 13:30 开盘前的两个窗口出现（10:15-10:30 / 11:30-13:30）
    ph = sse_phase(now_dt)
    if ph:
        try:
            sse_row = fetch_sse(ph, now_dt)
            if sse_row:
                out_rows.append(sse_row)
                print(f'      [A股] 上证指数 {sse_row["close"]} -> {sse_row["last"]}（窗口 {ph}）')
            else:
                print('      [A股] 今日分时无对应数据，跳过此行')
        except Exception as e:
            print(f'      [A股] 拉取失败，跳过此行: {type(e).__name__}')

    ok = sum(1 for r in out_rows if r['pct'] is not None)
    print(f'[3/3] 生成图片（{ok}/{len(out_rows)} 个品种有涨跌；实时价 {n_live} 个） ...')
    out_name = time.strftime('%Y%m%d-%H%M', now) + '.png'
    out_path = os.path.join(app_dir(), out_name)
    foot = (ref_desc + ' · ' if ref_desc else '') + \
           f'生成 {time.strftime("%Y-%m-%d %H:%M:%S", now)}' + \
           ('（' + warn + '）' if warn else '')
    render_png(out_rows, title, foot, out_path)
    print(f'已保存: {out_path}')
    try:
        os.startfile(out_path)
    except Exception:
        pass
    print(f'完成，耗时 {time.time() - t0:.1f} 秒')
    time.sleep(1.0)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print()
        print('!! 出错了: ' + str(e))
        print('（把本窗口截图发我即可）')
        try:
            input('按回车键关闭 ...')
        except Exception:
            pass
