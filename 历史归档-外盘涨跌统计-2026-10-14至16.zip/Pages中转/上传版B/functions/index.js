// Cloudflare Pages Functions 版（备用方案）：新浪行情转发
// 若「上传版A（_worker.js）」方式不生效，用本方案（functions 目录结构）重新上传
export async function onRequest(context) {
  const { request } = context;
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Max-Age': '86400',
    'Cache-Control': 'no-store',
  };
  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }
  const url = new URL(request.url);
  const list = url.searchParams.get('list') || '';
  if (!/^[A-Za-z0-9_,.]{1,500}$/.test(list)) {
    return new Response('sina hq proxy: ok', { status: 200, headers: cors });
  }
  const resp = await fetch('https://hq.sinajs.cn/list=' + list, {
    headers: {
      'Referer': 'https://finance.sina.com.cn',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36',
    },
  });
  const buf = await resp.arrayBuffer();
  const h = new Headers(cors);
  h.set('Content-Type', 'application/javascript; charset=GBK');
  return new Response(buf, { status: resp.status, headers: h });
}
