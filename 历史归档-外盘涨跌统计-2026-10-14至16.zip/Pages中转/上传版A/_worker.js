// Cloudflare Pages 高级模式（_worker.js）：新浪行情转发
// 逻辑与现有 Worker 完全一致：加 Referer 转发 hq.sinajs.cn + 开启 CORS（解决浏览器跨域与防盗链）
export default {
  async fetch(request, env) {
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Max-Age': '86400',
      'Cache-Control': 'no-store',
    };
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }
    const url = new URL(request.url);
    const list = url.searchParams.get('list') || '';
    if (!/^[A-Za-z0-9_,.]{1,500}$/.test(list)) {
      // 没有 list 参数：返回静态说明页（index.html），失败则回文字
      try {
        if (env && env.ASSETS) return await env.ASSETS.fetch(request);
      } catch (e) {}
      return new Response('sina hq proxy: ok', { status: 200, headers: cors });
    }
    const resp = await fetch('https://hq.sinajs.cn/list=' + list, {
      headers: {
        'Referer': 'https://finance.sina.com.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36',
      },
    });
    const buf = await resp.arrayBuffer();
    const h = new Headers(cors);
    h.set('Content-Type', 'application/javascript; charset=GBK');
    return new Response(buf, { status: resp.status, headers: h });
  },
};
